package lte4;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import java.awt.Image;
/*
Just provide a window for the program to reside in
you can get information about the window from this class
*/
public class MyWindow extends Window
{
    
    
    
    
    
    protected Gui gui;
    public MyWindow(Gui gui)
    {
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        initWindow();
    }
    
    public void initWindow()
    {
        setBounds(0, 0, 1000, 1000);
        uponClosing(()->stop());
    }
    public void add(Component c)
    {
        super.add(c);
        if(c instanceof MyTextBox)
            toggleSize();
    }
    public void setTitle(String title)
    {
        getJavaComponent().setTitle(title);
    }
    public void setIconImage(Image i)
    {
        getJavaComponent().setIconImage(i);
    }
}