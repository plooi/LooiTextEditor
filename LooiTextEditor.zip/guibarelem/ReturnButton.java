package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;

public class ReturnButton extends Button
{
    protected Gui gui;
    public ReturnButton(Gui gui)
    {
        super(10,10,50,50,"|||",new Background(new Color(150,255,150)));
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
    }
    public void action()
    {
        gui.getGuiStateManager().setState("menuState");
    }
    public void activate()
    {
        super.activate();
    }
    public void deactivate()
    {
        super.deactivate();
    }
    public void looiPaint()
    {
        super.looiPaint();
    }
    public boolean touchingMouseAndInFront(){return touchingMouse();}
}