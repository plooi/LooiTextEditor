package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;


public class PopupMenu<DataType> extends Rectangle
{
    //MAIN INTERFACE
    public void activateOpen(DataType d)
    {
        currentData = d;
        setPosition(getX(), getInternalMouseY());
        activate();
    }
    //END MAIN INTERFACE
    
    protected DataType currentData;
    protected double itemHeight;
    
    public PopupMenu()
    {
        super();
        init();
    }
    public void init()
    {
        itemHeight = 35;
        setLayer(-500);
        deactivate();
    }
    public void add(GuiComponent g)
    {
        super.add(g);
        refreshPositions();
    }
    public void remove(GuiComponent g)
    {
        super.remove(g);
        refreshPositions();
    }
    public void refreshPositions()
    {
        double currentItemY = 0;
        for(int i = 0; i < getNumComponents(); i++)
        {
            LooiObject l = getComponent(i);
            if(l instanceof Rectangle)
            {
                Rectangle gui = (Rectangle)l;
                gui.setDimensions(getWidth(), itemHeight);
                gui.setPosition(getX(), getY() + currentItemY);
                currentItemY += itemHeight;
                
            }
        }
        setDimensions(getWidth(), currentItemY);
    }
    public double getItemHeight(){return itemHeight;}
    public void setItemHeight(double d){itemHeight = d;}
    public DataType getCurrentData(){return currentData;}
    public void looiStep()
    {
        super.looiStep();
        if(mouseLeftPressed() && !touchingMouseAndInFront())
        {
            deactivate();
        }
    }
}