package looitexteditorgui;
import static ljs.Obj.*;
import ljs.gui.*;
import javax.swing.JTextArea;
import java.util.ArrayList;
import java.io.File;
import java.util.Comparator;
public class SuggestionMaker
{
	public static final ArrayList<Character> allowed_characters_in_word = new ArrayList<>();
	static
	{
		for(int i : range(48,58))
		{
			allowed_characters_in_word.add((char)i);
		}
		for(int i : range(65,91))
		{
			allowed_characters_in_word.add((char)i);
		}
		for(int i : range(97,123))
		{
			allowed_characters_in_word.add((char)i);
		}
		allowed_characters_in_word.add('_');
		allowed_characters_in_word.add('$');
	}
	private Gui gui;
	private JTextArea jta;
	private LTETextBox textBox;
	private ArrayList<String> preaddedTerms = new ArrayList<>();
	private int minimumTermLength = 3;
	
	public SuggestionMaker(Gui gui, LTETextBox textBox)
	{
		this.gui = gui;
		this.textBox = textBox;
		jta = textBox.getJTextArea();
		if(new File("terms.txt").exists())
		{
			String[] preaddedTermsTextDoc = loadText("terms.txt");
			for(String term : preaddedTermsTextDoc)
			{
				preaddedTerms.add(term);
			}
		}
		
	}
	
	public void suggest()
	{
		
		String current = stringNextToCursor();
		String suggestion = "";
		ArrayList<String> terms = getTermsSmart();
		ArrayList<String> toRemove = new ArrayList<String>();
		for(String s : terms)
		{
			if(s.length() < minimumTermLength || s.equals(current))
			{
				toRemove.add(s);
			}
		}
		terms.removeAll(toRemove);
		for(String term : terms)
		{
			if(term.startsWith(current))
			{
				suggestion = term;
				break;
			}
		}
		if(suggestion.equals(""))
			return;
		String toAdd = suggestion.substring(current.length());
		String before = textBox.getText().substring(0,jta.getCaretPosition());
		String after = textBox.getText().substring(jta.getCaretPosition());
		int oldCaretPosition = jta.getCaretPosition();
		textBox.setText(before + toAdd + after);
		jta.setCaretPosition(oldCaretPosition + toAdd.length());
	}
	public String stringNextToCursor()
	{
		//p("jta.getText().substring("+(previousSpaceToCursor() + 1)+","+jta.getCaretPosition()+");");
		return jta.getText().substring(previousSpaceToCursor() + 1,jta.getCaretPosition());
	}
	public int previousSpaceToCursor()
	{
		String text = jta.getText();
		for(int i = jta.getCaretPosition() - 1; i >= 0; i--)
		{
			if(!contains(allowed_characters_in_word,text.charAt(i)))
			{
				return i;
			}
		}
		return -1;
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<String> getTerms()
	{
		String text = textBox.getText();
		ArrayList<String> ret = (ArrayList<String>)preaddedTerms.clone();
		ret.addAll(splitWith(allowed_characters_in_word,text));
		return ret;
	}
	public ArrayList<String> splitWith(ArrayList<Character> chars, String text)
	{
		ArrayList<String> ret = new ArrayList<>();
		for(int i = 0; i < text.length(); i++)
		{
			if(contains(chars,text.charAt(i)))
			{
				for(int j = i; j < text.length()+1; j++)
				{
					if(j == text.length() || !contains(chars,text.charAt(j)))
					{
						ret.add(text.substring(i,j));
						i = j;
						break;
					}
				}
			}
		}
		return ret;
	}
	public ArrayList<String> getTermsSmart()
	{
		ArrayList<Character> chars = allowed_characters_in_word;
		String text = textBox.getText();
		class Term
		{
			private String term;
			private int index;
			Term(String term, int index)
			{
				this.term = term;
				this.index = index;
			}
			public int getIndex(){return index;}
			public String getString(){return term;}
		}
		ArrayList<Term> terms = new ArrayList<>();
		for(int i = 0; i < text.length(); i++)
		{
			if(contains(chars,text.charAt(i)))
			{
				for(int j = i; j < text.length()+1; j++)
				{
					if(j == text.length() || !contains(chars,text.charAt(j)))
					{
						terms.add(new Term(text.substring(i,j),i));
						i = j;
						break;
					}
				}
			}
		}
		terms.sort(new Comparator<Term>()
		{
			public int compare(Term t1, Term t2)
			{
				int t1Dis = Math.abs(t1.getIndex() - jta.getCaretPosition());
				int t2Dis = Math.abs(t2.getIndex() - jta.getCaretPosition());
				return t1Dis - t2Dis;
			}
			public boolean equals(Term t1, Term t2)
			{
				return compare(t1,t2)==0;
			}
			
		});
		ArrayList<String> termStrings = new ArrayList<String>();
		for(Term t : terms)
		{
			termStrings.add(t.getString());
		}
		
		ArrayList<String> ret = new ArrayList<>();
		ret.addAll(termStrings);
		ret.addAll(preaddedTerms);
		return ret;
	}
	public static boolean contains(ArrayList<Character> chars, char c)
	{
		for(char ch : chars)
		{
			if(ch == c)return true;
		}
		return false;
	}
	//private int suggestionStart = 0;
	//private int suggestionEnd = 0;
	//private int sizeAtTimeOfSuggestion = 0;
	/*public void run()
	{
		boolean firstTime = true;
		while(true)
		{
			if(!firstTime)
				removeOldSuggestion();
			firstTime = false;
			ArrayList<String> terms = getTerms();
			String nextToCursor = stringNextToCursor();
			if(nextToCursor.length() == 0)
				continue;
			String rec = null;
			for(String s : terms)
			{
				if(s.startsWith(nextToCursor))
				{
					rec = s;
					break;
				}
			}
			if(rec == null)
				continue;
			String addOn = rec.substring(nextToCursor.length());
			String oldText = textBox.getText();
			
			String before = oldText.substring(0,jta.getCaretPosition());
			String after = oldText.substring(jta.getCaretPosition());
			int oldCaretPosition = jta.getCaretPosition();
			textBox.setText(before + addOn + after);
			suggestionStart = before.length();
			suggestionEnd = before.length() + addOn.length();
			sizeAtTimeOfSuggestion = textBox.getText().length();
			jta.setCaretPosition(oldCaretPosition);
			try{Thread.sleep(500);}catch(Exception ex){}
		}
	}*/
	
	/*public void removeOldSuggestion()
	{
		int oldCaretPosition = jta.getCaretPosition();
		String text = jta.getText();
		String before = text.substring(0,suggestionStart);
		String after = text.substring(suggestionEnd);
		textBox.setText(before + after);
		
		try{jta.setCaretPosition(oldCaretPosition);}catch(Exception e){}
	}*/
}