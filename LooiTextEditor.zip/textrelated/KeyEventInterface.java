package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;

/*
Defines the interface that is used to execute key events
*/
public interface KeyEventInterface
{
    char getKeyChar();//we should remove this because it's a little useless since most of the key chars are not really valid chars i guess... uh i guess it's fine
    int getKeyCode();
    public static KeyEventInterface NEW(char keyChar, int keyCode)
    {
        return new KeyEventInterface()
        {
            public char getKeyChar(){return keyChar;}
            public int getKeyCode(){return keyCode;}
        };
    }
}