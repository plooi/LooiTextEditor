package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;
import java.lang.StringBuilder;
import state.*;

public class OpenFileButton extends RightClickButton
{
    protected Gui gui;
    protected FileTabHolder fileTabHolder;
    protected OpenFileButtonRightClickMenu o;
    
    public OpenFileButton(Gui gui, FileTabHolder fileTabHolder)
    {
        super(new Background(new Color(150,150,250)));
        init(gui, fileTabHolder);
    }
    public void init(Gui gui, FileTabHolder fileTabHolder)
    {
        this.gui = gui;
        this.fileTabHolder = fileTabHolder;
        initDimensionsOpenFileButton();
        o = new OpenFileButtonRightClickMenu(gui);
    }
    public void initDimensionsOpenFileButton()
    {
        set(60,10,50,50);
        setText("Open");
    }
    public void action()
    {
        ((BrowseState)gui.getGuiStateManager().states().get("browseState")).getFileBrowser().browse(null);
    }
    public boolean touchingMouseAndInFront(){return touchingMouse();}
    
    
    public void rightClick()
    {
        o.activateOpen(null);
    }
    public boolean isTooLong(String s)
    {
        return false;
    }
}