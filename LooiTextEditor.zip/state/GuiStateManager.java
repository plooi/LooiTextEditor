package state;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import lte4.*;
import java.util.ArrayList;


/*
Manages all the states of the GuiBar like
    display open files
    browse
    settings
*/
public class GuiStateManager
{
    //INTERFACE
    public void setState(String stateName)
    {
        GuiState gs = states.get(stateName);
        
        if(gs == null)
            throw new RuntimeException(stateName + " is NOT a state that I know of!!!");
        
        String nextStateName = stateName;//just for clarity
        
        setState(gs, nextStateName, 314159);
        currentStateName = stateName;
    }
    public String getCurrentState(){return currentStateName;}
    public AttributeMap<GuiState> states(){return states;}
    
    //END INTERFACE
    
    protected Gui gui;
    protected GuiBar guiBar;
    protected AttributeMap<GuiState> states = new AttributeMap<>();
    
    protected GuiState current = null;
    protected String currentStateName = "null";
    
    
    public GuiStateManager(Gui gui)
    {
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        this.guiBar = gui.getGuiBar();
        initStates();
        setState("menuState");
    }
    
    public void initStates()
    {
        states.init("selectFontSizeState", new SelectFontSizeState(gui));
        states.init("menuState", new MenuState(gui));
        states.init("fileSelectionState", FileSelectionState.it = new FileSelectionState(gui));
        states.init("browseState", new BrowseState(gui));
        states.init("hotkeyState", new HotkeyState(gui));
        states.init("styleFileState", new StyleFileState(gui));
        states.init("fontSizeState", new FontSizeState(gui));
        
        for(String stateName : states.keySet())
        {
            states.get(stateName).close(gui, "");
        }
    }
    public void setState(GuiState gs, String nextStateName, int THIS_METHOD_IS_NOT_TO_BE_DIRECTLY_CALLED)
    {
        if(THIS_METHOD_IS_NOT_TO_BE_DIRECTLY_CALLED != 314159)
            throw new RuntimeException("You are bad!");
        if(current != null && current == gs)
            return;
        if(current != null)
            current.close(gui, nextStateName);
        gs.open(gui, currentStateName);
        current = gs;
    }
}