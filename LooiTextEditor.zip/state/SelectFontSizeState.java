package state;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import guibarelem.*;

public class SelectFontSizeState implements GuiState
{
    protected Gui gui;
    protected Slider fontSlider;
    protected ReturnButton returnButton;
    public SelectFontSizeState(Gui gui)
    {
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        fontSlider = new Slider(10, 70, 150, 40, Background.DARK_GRAY_BACKGROUND);
        returnButton = new ReturnButton(gui);
    }
    public void open(Gui gui, String previousStateName)
    {
        //show the font size slider
        returnButton.activate();
        fontSlider.activate();
    }
    public void close(Gui gui, String nextStateName)
    {
        fontSlider.deactivate();
        returnButton.deactivate();
    }
    
    
    
    
}