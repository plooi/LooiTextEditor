package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.lang.Process;
import java.util.HashMap;
import java.lang.Runtime;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.File;
import java.awt.Color;
import java.util.HashSet;
import java.lang.StringBuilder;
import static textrelated.Util.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.StyleContext;
import javax.swing.text.StyleConstants;
import javax.swing.JOptionPane;
import java.awt.Font;
/*
Job is to manage the style selection and the implementation of the 
style (the refresh method)
*/
public class StyleManager
{
    
    //INTERFACE
    public static final int maxNumCharsAllowedForRefresh = 40000;
    public void setStyleDoc(File textFileThatNeedsAStyle){_setStyleDoc(textFileThatNeedsAStyle);}
    public void setStyleDoc(String styleDoc)
    {
        this.styleDoc = styleDoc;
        try{loadStyleDoc(styleDoc);}catch(InvalidStyleDocumentException e){JOptionPane.showMessageDialog(null, "Style document " + styleDoc + " has a problem: \n" + e.getProblem());}
    }
    public void refresh()
    {
        _refresh();
    }
    public static StyleManager it;
    public static final String styleFileFolder = "."+File.separator+"StyleFiles";
    
    public HashMap<String, Color> getPatternColors(){return patternColors;}
    
    //END INTERFACE
    
    
    //public static final String DEFAULT_STYLE_DOC = "style.txt";
    public static final char[] PUNCTUATION_ARRAY = new char[]{'&', '<', '>', '"', 
                                                        '!', '@', '#', '$', '%', '^', '*' , '(', ')', '-', '+', '=', 
                                                        '~', '`', '{', '[', ']', '}', '\\', '|', ':', ';', ',', '.', '/',
                                                        '?'}; //DONT USE THIS ARRAY- USE THE HASH SET
    
    public static final HashSet<Character> PUNCTUATION = new HashSet<Character>();
    static { for(char c : PUNCTUATION_ARRAY) { PUNCTUATION.add(c); } }
    
    
    protected Gui gui;
    protected TextBoxMethods methods;
    protected String styleDoc;
    
    /*
    Special Patterns:
        string literal
        default color
        generic brackets
        so on
    */
    protected ArrayList<String> specialPatternTypes = arrayList("numberliteral", "stringliteral", "\"\"\"stringliteral", "'''stringliteral", "'stringliteral", "default", "highlight", "background", "caret", "slashslashcomment", "slashstarcomment", "hashtagcomment");
    protected HashMap<String, Color> patternColors = new HashMap<>();//special patterns
    protected HashMap<String, Color> wordColors = new HashMap<>();
    protected Thread refreshExecutionThread;
    protected int numRefreshesQueued;
    protected Object refreshQueueSynchronizer = new Object();//only one thread can modify int numRefreshesQueued at a time
    protected StyleFileSelector sfs;
    //Whenever you need to read or write to numRefreshesQueued, you have to do the read or write inside a synchronized(refreshQueueSynchronizer)
    
    
    
    public StyleManager(Gui gui, TextBoxMethods tbm)
    {
        init(gui, tbm);
    }
    public void init(Gui gui, TextBoxMethods tbm)
    {
        this.gui = gui;
        methods = tbm;
        refreshExecutionThread = new Thread(()-> 
        {
            while(true)
            {
                boolean canRefresh;
                synchronized(refreshQueueSynchronizer)
                {
                    canRefresh = numRefreshesQueued > 0;
                }
                if(canRefresh)
                {
                    executeRefresh(gui.getTextBox());//DONE
                    synchronized(refreshQueueSynchronizer)
                    {
                        numRefreshesQueued--;
                    }
                }
                sleep(.05);
            }
        });
        refreshExecutionThread.start();
        //loadStyleDoc(DEFAULT_STYLE_DOC);
        
        gui.getTextBox().getPane().setFont(new Font("Courier New", Font.PLAIN, 20));//for testing
        
        sfs = new StyleFileSelector();
        StyleFileSelector.it = sfs;
        
        if(patternColors.get("default") == null)
            patternColors.put("default", Color.BLACK);
    }
    
    public void loadStyleDoc(String styleDoc) throws InvalidStyleDocumentException
    {
        if(styleDoc == null)
        {
            patternColors = new HashMap<>();
            wordColors = new HashMap<>();
            if(patternColors.get("default") == null)
                patternColors.put("default", Color.BLACK);
        }
        
        
        String[] styleDocLines = null;
        try
        {
            styleDocLines = loadText(styleDoc);
        }
        catch(Exception e)
        {
            throw new InvalidStyleDocumentException("Invalid style document file name.");
        }
        
        HashMap<String, Color> patternColors = new HashMap<>();
        HashMap<String, Color> wordColors = new HashMap<>();
        
        
        
        int i = 0;
        for(String line : styleDocLines)
        {
            boolean isWhiteSpace = true;
            for(int a = 0; a < line.length(); a++)
                if(!Character.isSpaceChar(line.charAt(a)))
                {
                    isWhiteSpace = false;
                    break;
                }
            if(isWhiteSpace) continue;
            if(line.startsWith(" "))//it is a special pattern
            {
                line = line.trim();
                ArrayList<String> params = split(line, " ");
                if(params.size() != 4)
                    throw new InvalidStyleDocumentException("Line " + i + " of " + styleDoc + " has invalid number of arguments.");
                if(!specialPatternTypes.contains(params.get(0)))
                    throw new InvalidStyleDocumentException("Line " + i + " of " + styleDoc + " has invalid special pattern \"" + params.get(0) + "\".");
                
                
                addLine(i, params, patternColors, styleDoc);
            }
            else//it is a word
            {
                line = line.trim();
                ArrayList<String> params = split(line, " ");
                
                    
                if(params.size() != 4)
                    throw new InvalidStyleDocumentException("Line " + i + " of " + styleDoc + " has invalid number of arguments.");
                addLine(i, params, wordColors, styleDoc);
                    
            }
            i++;
        }
        
        
        if(patternColors.get("default") == null)
            patternColors.put("default", Color.BLACK);
        
        
        this.patternColors = patternColors;
        this.wordColors = wordColors;
        //this.patternColors = new HashMap<>();
        //this.wordColors = new HashMap<>();
        refreshBackground();
        
    }
    public void refreshBackground()
    {
        gui.getTextBoxMethods().setBackgroundColor(gui.getTextBoxMethods().getSpecialColor("background"));
        gui.getTextBoxMethods().setCaretColor(gui.getTextBoxMethods().getSpecialColor("caret"));
    }
    public void addLine(int line, ArrayList<String> params, HashMap<String, Color> dest, String styleDoc)
    {
        int[] rgb = new int[3];
        int i = line;
        for(int j : range(1, 4))
        {
            try
            {
                rgb[j - 1] = Integer.parseInt(params.get(j));
                require(rgb[j - 1] >= 0);
                require(rgb[j - 1] <= 255);
            }
            catch(Exception e)
            {
                throw new InvalidStyleDocumentException("Bad argument " + params.get(i) + " on line " + i + " of " + styleDoc + ".");
            }
        }
        Color theColor = new Color(rgb[0], rgb[1], rgb[2]);
        String specialPattern = params.get(0);
        dest.put(specialPattern, theColor);
        
    } 
    
    /*
    A word could also represent an entire string literal
    */
    public static class Word
    {
        public Color color;
        public int
            startIndexInEntireText, 
            endIndexInEntireText;
        public Word(){}
    }
    
    protected HashMap<String, AttributeSet> recyclableAttributeSets = new HashMap<>();
    public AttributeSet aset(Color c, int fontSize)
    {
        String description = "COLOR:" + c + " FONTSIZE:" + fontSize;
        AttributeSet recycle = recyclableAttributeSets.get(description);
        
        if(recycle != null) 
        {
            return recycle;
        }
        
        try
        {
            StyleContext cont = StyleContext.getDefaultStyleContext();
            AttributeSet attr = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, c);
            attr = cont.addAttribute(attr, StyleConstants.FontFamily, "Courier New");
            attr = cont.addAttribute(attr, StyleConstants.FontSize, fontSize);
            
            recyclableAttributeSets.put(description, attr);
            
            return attr;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            stop();
            return null;
        }
    }
    private void _refresh()
    {
        synchronized(refreshQueueSynchronizer)
        {
            numRefreshesQueued++;
            if(numRefreshesQueued > 2) numRefreshesQueued = 2;
        }
    }
    
    /*
    This method gets called when the refreshExecutorThread decides that it actually
    wants to execute a refresh
    */
    private void executeRefresh(MyTextBox mtb)
    {
        if(mtb.getText().length() > maxNumCharsAllowedForRefresh)//no style file will be applied on absurdly large files
        {
            mtb.color(0, mtb.getText().length(), aset(patternColors.get("default"), gui.getTextBoxModifier().getFontSize()));
            return;
        } 
        //long start = System.nanoTime();
        String text = mtb.getText();
        Word recyclableWord = new Word();// we will recycle this Word object because we don't want to keep having to allocate more and more memory
        
        ArrayList<Triple<Integer, Integer, AttributeSet>> jobs = new ArrayList<>();
        
        int i = 0;
        int iterationCounter = 0;
        //p("Refresh start");
        
        
        while(i < text.length())
        {
            
            for(int p = 0; p < 1; p++)//this for loop just allows us to break out of it when we want for clarity. At least, I THINK it's clear. Ahahaha...
            {
                if(trySpecialType(i, text, recyclableWord))//if a special type starts at index in text, then it will initialize recyclableWord to that special type and return true, else false
                {
                    break;
                }
                else
                {
                    findActualWordHere(i, text, recyclableWord);  //initializes recyclableWord to the actual word here. An "actual word here" is like a word word, a space word, or a punctuation word.
                    break;
                }
            }
            
            //if(recyclableWord.color == null) recyclableWord.color = patternColors.get("default");
            jobs.add(new Triple<>(recyclableWord.startIndexInEntireText, recyclableWord.endIndexInEntireText, aset(recyclableWord.color, gui.getTextBoxModifier().getFontSize())));
            
            i = recyclableWord.endIndexInEntireText;
            //if(iterationCounter % 100 == 0)
            //    try{Thread.sleep(0, 1000);}catch(Exception exx){}
            iterationCounter++;
        }
        
        
        //execute all the jobs
        for(Triple<Integer, Integer, AttributeSet> job : jobs)
        {
            mtb.color(job.a, job.b, job.c);
        }
        //p("Took " + (System.nanoTime()-start) + " nanoseconds");
    }
    
    /*
    If a special type starts here, completely initialize the word with the information about this
    special type and the return true; Otherwise return false;
    */
    private boolean trySpecialType(int index, String text, Word word)
    {
        if(patternColors.keySet().contains("\"\"\"stringliteral"))
        {
            if(indexEquals(text, index, '\"') && indexEquals(text, index+1, '\"') && indexEquals(text, index+2, '\"'))//check for opening quote
            {
                word.startIndexInEntireText = index;
                int i = index + 1;
                
                boolean foundClosingQuote = false;
                
                checkForClosingQuote:
                while(i < text.length())
                {
                    //check for closing quote
                    if(indexEquals(text, i, '\"') && indexEquals(text, i+1, '\"') && indexEquals(text, i+2, '\"')) //theres a quote here and ...
                    {
                        int previousConsecutiveBackslashes = 0;//count the number of previous consecutive backslashes
                        for(int j = i-1; true; j--)
                        {
                            if(indexEquals(text, j, '\\'))
                                previousConsecutiveBackslashes++;
                            else
                                break;
                        }
                        if(previousConsecutiveBackslashes % 2 == 0) //there's a consecutive even number of backslashes behind me, then it's a real quote
                        {//HEY EVERYBODY! I'VE FOUND THE END OF THE STRING LITERAL!!! WOOHOO!
                            foundClosingQuote = true;
                            i += "\"\"\"".length()-1;
                            break checkForClosingQuote;
                        }
                        
                        
                    }
                    i++;
                }
                //The closing quote is at i... or we've reached the end of the file and we will pretend that the closing quote is at i-1
                //Wherever the closing quote is, we + 1 to it and we get the official ending index.
                if(foundClosingQuote)
                    word.endIndexInEntireText = i+1;
                else
                    word.endIndexInEntireText = i;
                    
                //word.text = text.substring(word.startIndexInEntireText, word.endIndexInEntireText);
                word.color = patternColors.get("\"\"\"stringliteral");
                return true;
            }
            
        }
        //Checking for string
        if(patternColors.keySet().contains("stringliteral"))//only try to check for stringliteral if the user cares about stringliteral
        {
            if(indexEquals(text, index, '\"'))//check for opening quote
            {
                word.startIndexInEntireText = index;
                int i = index + 1;
                
                boolean foundClosingQuote = false;
                
                checkForClosingQuote:
                while(i < text.length())
                {
                    //check for closing quote
                    if(indexEquals(text, i, '\"')) //theres a quote here and ...
                    {
                        int previousConsecutiveBackslashes = 0;//count the number of previous consecutive backslashes
                        for(int j = i-1; true; j--)
                        {
                            if(indexEquals(text, j, '\\'))
                                previousConsecutiveBackslashes++;
                            else
                                break;
                        }
                        if(previousConsecutiveBackslashes % 2 == 0) //there's a consecutive even number of backslashes behind me, then it's a real quote
                        {//HEY EVERYBODY! I'VE FOUND THE END OF THE STRING LITERAL!!! WOOHOO!
                            foundClosingQuote = true;
                            break checkForClosingQuote;
                        }
                        
                        
                    }
                    i++;
                }
                //The closing quote is at i... or we've reached the end of the file and we will pretend that the closing quote is at i-1
                //Wherever the closing quote is, we + 1 to it and we get the official ending index.
                if(foundClosingQuote)
                    word.endIndexInEntireText = i+1;
                else
                    word.endIndexInEntireText = i;
                    
                //word.text = text.substring(word.startIndexInEntireText, word.endIndexInEntireText);
                word.color = patternColors.get("stringliteral");
                return true;
            }
        }
        //Okay, let's assume now that we either don't care or didnt find a string literal
        //Go on to check the rest of the types of special types
        //......
        if(patternColors.keySet().contains("slashslashcomment"))
        {
            if(indexEquals(text, index, '/') && indexEquals(text, index+1, '/'))//check for slash slash
            {
                word.startIndexInEntireText = index;
                
                int end = text.indexOf("\n", index);
                if(end == -1) end = methods.getText().length();
                
                word.endIndexInEntireText = end;
                word.color = patternColors.get("slashslashcomment");
                
                return true;
            }
        }
        
        if(patternColors.keySet().contains("slashstarcomment"))
        {
            if(indexEquals(text, index, '/') && indexEquals(text, index+1, '*'))//check for slash star
            {
                word.startIndexInEntireText = index;
                
                int end = text.indexOf("*/", index);
                if(end == -1) end = methods.getText().length();
                
                word.endIndexInEntireText = end + "*/".length();
                word.color = patternColors.get("slashstarcomment");
                
                return true;
            }
        }
        if(patternColors.keySet().contains("hashtagcomment"))
        {
            if(indexEquals(text, index, '#'))//check for #
            {
                word.startIndexInEntireText = index;
                
                int end = text.indexOf("\n", index);
                if(end == -1) end = methods.getText().length();
                
                word.endIndexInEntireText = end;
                word.color = patternColors.get("hashtagcomment");
                
                return true;
            }
        }
        
        if(patternColors.keySet().contains("'''stringliteral"))
        {
            if(indexEquals(text, index, '\'') && indexEquals(text, index+1, '\'') && indexEquals(text, index+2, '\''))//check for opening quote
            {
                word.startIndexInEntireText = index;
                int i = index + 1;
                
                boolean foundClosingQuote = false;
                
                checkForClosingQuote:
                while(i < text.length())
                {
                    //check for closing quote
                    if(indexEquals(text, i, '\'') && indexEquals(text, i+1, '\'') && indexEquals(text, i+2, '\'')) //theres a quote here and ...
                    {
                        int previousConsecutiveBackslashes = 0;//count the number of previous consecutive backslashes
                        for(int j = i-1; true; j--)
                        {
                            if(indexEquals(text, j, '\\'))
                                previousConsecutiveBackslashes++;
                            else
                                break;
                        }
                        if(previousConsecutiveBackslashes % 2 == 0) //there's a consecutive even number of backslashes behind me, then it's a real quote
                        {//HEY EVERYBODY! I'VE FOUND THE END OF THE STRING LITERAL!!! WOOHOO!
                            foundClosingQuote = true;
                            i += "'''".length()-1;
                            break checkForClosingQuote;
                        }
                        
                        
                    }
                    i++;
                }
                //The closing quote is at i... or we've reached the end of the file and we will pretend that the closing quote is at i-1
                //Wherever the closing quote is, we + 1 to it and we get the official ending index.
                if(foundClosingQuote)
                    word.endIndexInEntireText = i+1;
                else
                    word.endIndexInEntireText = i;
                    
                word.color = patternColors.get("'''stringliteral");
                return true;
            }
            
            
        }
        if(patternColors.keySet().contains("'stringliteral"))
        {
            if(indexEquals(text, index, '\''))
            {
                word.startIndexInEntireText = index;
                int i = index + 1;
                
                boolean foundClosingQuote = false;
                
                checkForClosingQuote:
                while(i < text.length())
                {
                    //check for closing quote
                    if(indexEquals(text, i, '\'')) 
                    {
                        int previousConsecutiveBackslashes = 0;
                        for(int j = i-1; true; j--)
                        {
                            if(indexEquals(text, j, '\\'))
                                previousConsecutiveBackslashes++;
                            else
                                break;
                        }
                        if(previousConsecutiveBackslashes % 2 == 0) //there's a consecutive even number of backslashes behind me, then it's a real quote
                        {//HEY EVERYBODY! I'VE FOUND THE END OF THE STRING LITERAL!!! WOOHOO!
                            foundClosingQuote = true;
                            break checkForClosingQuote;
                        }
                        
                        
                    }
                    i++;
                }
                //The closing quote is at i... or we've reached the end of the file and we will pretend that the closing quote is at i-1
                //Wherever the closing quote is, we + 1 to it and we get the official ending index.
                if(foundClosingQuote)
                    word.endIndexInEntireText = i+1;
                else
                    word.endIndexInEntireText = i;
                    
                word.color = patternColors.get("'stringliteral");
                return true;
            }
        }
        if(patternColors.keySet().contains("numberliteral"))
        {
            
            if(indexEquals(text, index, validNumberLiteralCharacters))
            {
                //p("Num literal" + index);
                word.startIndexInEntireText = index;
                int z = index;
                boolean justSawDot = false;
                while(z < methods.getText().length())
                {
                    
                    char thisChar = methods.getText().charAt(z);
                    if(justSawDot && !Character.isDigit(thisChar))
                        break;
                    if(!(Character.isLetterOrDigit(thisChar)) && !(thisChar == '.'))
                        break;
                        
                    justSawDot = thisChar == '.';
                    z++;
                }
                int end = z;
                if(containsDigits(methods.getText(), index, end))
                {
                    word.endIndexInEntireText = end;
                    word.color = patternColors.get("numberliteral");
                    return true;
                }
                else
                {
                    //not a numberliteral
                }
            }
        }
        //okay, none of the special types matched
        return false;
    }
    public static ArrayList<Character> validNumberLiteralCharacters = arrayList('0','1','2','3','4','5','6','7','8','9','.');
    /*
    returns whether s.charAt(index) == c
    but also returns false if index is out of bounds
    
    */
    public static boolean indexEquals(String s, int index, char c)
    {
        if(index < 0 || index >= s.length()) return false;
        return s.charAt(index) == c;
    }
    public static boolean indexEquals(String s, int index, ArrayList<Character> chars)
    {
        for(char c : chars)
            if(indexEquals(s, index, c)) return true;
        return false;
    }
    public static boolean containsDigits(String s, int start, int end)
    {
        for(int i = start; i < end; i++)if(Character.isDigit(s.charAt(i)))return true;
        return false;
        
    }
    
    /*
    This method finds the actual word here and completely initializes the 
    word object's data members with this actual word here
    */
    private void findActualWordHere(int index, String text, Word word)
    {
        if(PUNCTUATION.contains(text.charAt(index)))//it COULD be just that there's a punctuation right HERE
        {
            word.startIndexInEntireText = index;
            word.endIndexInEntireText = index+1;
        }
        else if(isMyDefininitionOfANormalWordChar(text.charAt(index)))   //We hav  a normal word
        {
            word.startIndexInEntireText = index;
            int i = word.startIndexInEntireText;
            for(; i < text.length(); i++)//Try to find the end, or the end of the file
            {
                if(!isMyDefininitionOfANormalWordChar(text.charAt(i)))//see if we have found the end index
                    break;
            }
            word.endIndexInEntireText = i;
                    
        }
        else if(Character.isSpaceChar(text.charAt(index)))//We have have a space word
        {
            word.startIndexInEntireText = index;
            int i = word.startIndexInEntireText;
            for(; i < text.length(); i++)
            {
                if(!Character.isSpaceChar(text.charAt(i)))break;
            }
            word.endIndexInEntireText = i;
        }
        else//It's probably some other thing
        {
            word.startIndexInEntireText = index;
            word.endIndexInEntireText = index+1;
        }
        
        
        Color customWordColor = wordColors.get(text.substring(word.startIndexInEntireText, word.endIndexInEntireText));
        if(customWordColor == null)
            customWordColor = patternColors.get("default");
        word.color = customWordColor;
        
    }
    private boolean isMyDefininitionOfANormalWordChar(char c)
    {
        return Character.isLetterOrDigit(c) || c == '_';
    }
    public void _setStyleDoc (File textFileThatNeedsAStyle)
    {
        String name = textFileThatNeedsAStyle.getName();
        String fileExtension;
        if(!name.contains("."))fileExtension = null;
        else fileExtension = name.substring(name.indexOf(".")+1);
        
        
        
        
        File styleFile = sfs.getFile(fileExtension);
        if(styleFile == null) styleFile = sfs.getFile(sfs.defaultStyleFileKey);
        
        
        
        if(styleFile == null)//no default file
            setStyleDoc((String)null);
        else
        {
            try
            {
                setStyleDoc(styleFile.getAbsolutePath());
            }
            catch(Exception ex)
            {
                setStyleDoc((String)null);
            }
        }
    }
    
}