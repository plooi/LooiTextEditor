/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;




/**
 *
 * @author peter_000
 */
public class XYZVector extends Vector
    {
        public XYZVector(double xInc, double yInc, double zInc)
            {
                super(new Point3D(0,0,0).getHorizontalDirection(new Point3D(xInc,yInc,zInc)),
                        new Point3D(0,0,0).getVerticalDirection(new Point3D(xInc,yInc,zInc)),
                        new Point3D(0,0,0).get3DDistance(new Point3D(xInc,yInc,zInc)));
            }
        
    }
