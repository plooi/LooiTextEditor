package state;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import lte4.*;
import java.util.ArrayList;

public interface GuiState
{
    void open(Gui gui, String previousStateName);
    void close(Gui gui, String nextStateName);
}