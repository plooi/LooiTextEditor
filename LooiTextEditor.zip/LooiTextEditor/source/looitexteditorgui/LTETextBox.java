package looitexteditorgui;
import static ljs.Obj.*;
import ljs.gui.*;
import ljs.Obj;
import java.awt.event.KeyEvent;
import javax.swing.JTextArea;
import java.awt.event.KeyListener;
import javax.swing.JScrollPane;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.text.BadLocationException;
import java.awt.Font;
import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import javax.swing.text.Highlighter;
import javax.swing.text.DefaultHighlighter.DefaultHighlightPainter;
import java.awt.Color;
public class LTETextBox extends TextBox
{
	public static final String last_font_file = "last_font.txt";
	public static final int ESSAY_MODE = 0;
	public static final int CODING_MODE = 1;
	public static final int default_font_size = 20;
	public static final String default_font = "Courier New";
	public static final Color DEFAULT_SELECTION_COLOR = new Color(200,220,255);
	public static final Color DEFAULT_MATCHING_TEXT_HIGHLIGHT_COLOR = new Color(160,255,160);
	public static final ArrayList<Tuple<String,String>> openClosePairs = new ArrayList<Tuple<String,String>>();
	static
	{
		openClosePairs.add(new Tuple<>("{","}"));
		openClosePairs.add(new Tuple<>("(",")"));
		openClosePairs.add(new Tuple<>("[","]"));
		openClosePairs.add(new Tuple<>("<",">"));
	}
	
	private int fileBarOffset;
	private Window myWindow;
	private Saver saver;
	private Gui gui;
	private long saveMillisecondWait;
	private int mode = CODING_MODE;
	private boolean running = true;
	private long undoRecordMillisecondDelay = 50;
	private UndoManager undoManager;
	private SuggestionMaker suggestionMaker;
	private JTextArea jta;
	private CustomKeyAndMouseListener ckml;
	private Highlighter highlighter;
	private DefaultHighlightPainter matchHighlightPainter,selectionHighlightPainter;
	private Color selectionColor,matchingTextHighlightColor;
	
	
	public LTETextBox(long saveMillisecondWait, int fileBarOffset, Window myWindow, Gui gui)
	{
		wrapAroundWords(true);
		this.fileBarOffset = fileBarOffset;
		this.myWindow = myWindow;
		this.gui = gui;
		jta = getJTextArea();
		this.saveMillisecondWait = saveMillisecondWait;
		setBounds(()->0,()->0,()->myWindow.getWidth(),()->myWindow.getHeight()-fileBarOffset);
		saver = new Saver(gui,saveMillisecondWait,this);
		saver.start();
		ckml = new CustomKeyAndMouseListener();
		jta.addKeyListener(ckml);
		jta.addMouseListener(ckml);
		
		loadLastFont();
		
		highlighter = jta.getHighlighter();
		
		setEditable(false);
		undoManager = new UndoManager();
		undoManager.start();
		setSelectionColor(DEFAULT_SELECTION_COLOR);
		setMatchingTextHighlightColor(DEFAULT_MATCHING_TEXT_HIGHLIGHT_COLOR);
		
	}
	public void goToLine(int lineNumber)
	{
		String text = getText();
		int line = 1;
		int selectionStart = -1,selectionEnd = -1;
		for(int i : range(text.length()))
		{
			if(text.charAt(i) == '\n')
				line++;
			if(line == lineNumber && selectionStart == -1)
			{
				selectionStart = i;
			}
			if(line == lineNumber + 1 && selectionEnd == -1)
			{
				selectionEnd = i;
			}
		}
		if(selectionEnd == -1 && selectionStart != -1)
			selectionEnd = text.length();
		jta.select(selectionStart,selectionEnd);
		jta.requestFocus();
		updateCaretLocation();
	}
	public void setSelectionColor(Color c)
	{
		selectionColor = c;
		jta.setSelectionColor(c);
		selectionHighlightPainter = new DefaultHighlightPainter(c);
	}
	public Color getSelectionColor()
	{
		return selectionColor;
	}
	public void setMatchingTextHighlightColor(Color c)
	{
		matchingTextHighlightColor = c;
		matchHighlightPainter = new DefaultHighlightPainter(c);
	}
	public Color getMatchingTextHighlightColor()
	{
		return matchingTextHighlightColor;
	}
	public void loadLastFont()
	{
		File lastFontFile = new File(last_font_file);
		if(lastFontFile.exists())
		{
			String[] loadedText = loadText(last_font_file);
			setFont(new Font(loadedText[0],Font.PLAIN,Integer.parseInt(loadedText[1])));
		}
		else
		{
			setFont(new Font(default_font,Font.PLAIN,default_font_size));
		}
	}
	
	public SuggestionMaker getSM(){return suggestionMaker;}
	public Saver getSaver(){return saver;}
	public int getMode(){return mode;}
	public void setMode(int i){mode = i;}
	public void setFont(Font font)
	{
		jta.setFont(font);
		saveText(last_font_file,Obj.<Object>array(font.getName(),font.getSize()));
	}
	public UndoManager getUndoManager(){return undoManager;}
	public class UndoManager extends Thread//UndoManager also helps call updateCaretLocation more frequently
	{
		private String lastText = null;
		public void run()
		{
			while(running)
			{
				synchronized(this)
				{
					String currentText = getText();
					if(gui.getViewedTab() != null)
					{
						if(!currentText.equals(lastText) && gui.getViewedTab() instanceof FileTab)
						{
							((FileTab)gui.getViewedTab()).addVersion(currentText);
						}
					}
					lastText = currentText;
				}
				try{Thread.sleep(undoRecordMillisecondDelay);}catch(Exception e){}
				
				
			}
		}
		public void setLastText(String s)
		{
			lastText = s;
		}
	}
	private int lastCaretLocation = 0;
	private int caretLocation = 0;
	
	private int lastSelectionStart,lastSelectionEnd;
	public void moveCaretPos(int position)//to be recorded into the lastCaretLocation variable and caretLocation variable
	{
		jta.moveCaretPosition(position);
		updateCaretLocation();
	}
	public void setCaretPos(int position)//to be recorded into the lastCaretLocation variable and caretLocation variable
	{
		jta.setCaretPosition(position);
		updateCaretLocation();
	}
	public void remove(int start, int end)
	{
		jta.replaceRange("",start,end);
		setCaretPos(start);
		updateCaretLocation();
		
	}
	public void insert(String text, int location)
	{
		String before = getText().substring(0,location);
		String after = getText().substring(location);
		setText(before + text + after);
		getJTextArea().setCaretPosition(location + text.length());
		updateCaretLocation();
	}
	public int insertMultiple(ArrayList<Tuple<String,Integer>> textInsertions)
	{
		textInsertions.sort(new Comparator<Tuple<String,Integer>>()
		{
			public int compare(Tuple<String,Integer> a, Tuple<String,Integer> b)
			{
				return a.b - b.b;
			}
			public boolean equals(Tuple<String,Integer> a, Tuple<String,Integer> b)
			{
				return compare(a,b) == 0;
			}
		});
		int offset = 0;
		int lastInsertion = -1;
		for(Tuple<String,Integer> t : textInsertions)
		{
			insert(t.a,lastInsertion = t.b + offset);
			offset += t.a.length();
		}
		return lastInsertion;
	}
	public int removeMultiple(ArrayList<Tuple<Integer,Integer>> textRemovals)
	{
		textRemovals.sort(new Comparator<Tuple<Integer,Integer>>()
		{
			public int compare(Tuple<Integer,Integer> a, Tuple<Integer,Integer> b)
			{
				return a.a - b.a;
			}
			public boolean equals(Tuple<Integer,Integer> a, Tuple<Integer,Integer> b)
			{
				return compare(a,b) == 0;
			}
		});
		int offset = 0;
		int lastRemoval = -1;
		for(Tuple<Integer,Integer> t : textRemovals)
		{
			remove(lastRemoval = t.a + offset,t.b + offset);
			offset -= t.b - t.a;
		}
		return lastRemoval;
	}
	public void updateScrollPosition()
	{
		if(gui.getViewedTab() != null)
			gui.getViewedTab().update(((JScrollPane)getJavaComponent()).getViewport().getViewPosition().getX(),((JScrollPane)getJavaComponent()).getViewport().getViewPosition().getY());
	}
	public void updateCaretLocation()
	{
		synchronized(ckml)
		{
			lastCaretLocation = caretLocation;
			caretLocation = jta.getCaretPosition();
			lastSelectionStart = jta.getSelectionStart();
			lastSelectionEnd = jta.getSelectionEnd();
			//p("lse " + lastSelectionEnd + " lss " + lastSelectionStart);
			updateHighlights();
		}
	}
	public void updateHighlights()
	{
		highlighter.removeAllHighlights();
		if(lastSelectionEnd != lastSelectionStart)
		{
			String text = getText();
			String selectedText = text.substring(lastSelectionStart,lastSelectionEnd);
			if(!isOpenClosePattern(selectedText))
			{
				//p("DONE");
				//p("not a match: " + selectedText);
				for(int i : range(text.length()))
				{
					if(text.substring(i).indexOf(selectedText) == 0)
					{
						if(i != lastSelectionStart)
						{
							try{highlighter.addHighlight(i,i + selectedText.length(),matchHighlightPainter);}catch(Exception e){}
						}
						else
						{
							try{highlighter.addHighlight(i,i + selectedText.length(),selectionHighlightPainter);}catch(Exception e){}
						}
					}
					
				}
			}
			else
			{
				//p("DONE");
				Tuple<Integer,Integer> match = findMatch(lastSelectionStart,lastSelectionEnd);
				//p(selectedText + " was a MATCH: " + match);
				try{highlighter.addHighlight(match.a,match.b,matchHighlightPainter);}catch(Exception e){}
				try{highlighter.addHighlight(lastSelectionStart,lastSelectionEnd,selectionHighlightPainter);}catch(Exception e){}
			}
		}
	}
	public boolean isOpenClosePattern(String text)
	{
		//p("OKAY.....");
		return findClosePattern(text)!=null || findOpenPattern(text)!=null;
	}
	public String findClosePattern(String open)
	{
		for(Tuple<String,String> t : openClosePairs)
		{
			//p("compare " + t.a + " TO " + open);
			//p("compare " + (int)t.a.charAt(0) + " TO " + (int)open.charAt(0) + " " + t.a.length() + " " + open.length());
			if(t.a.equals(open))
				return t.b;
			//p((t.a + "doesn't equal" + open) + 1/* + "doesn't equala" + ((int)open.charAt(0)) + Math.random()*/);
			//p(t);
		}
		return null;
	}
	public String findOpenPattern(String close)
	{
		for(Tuple<String,String> t : openClosePairs)
		{
			
			if(t.b.equals(close))
				return t.a;
			//p(t.b + "doesn't equal" + close + ((int)t.b.charAt(0)) + "doesn't equal" + ((int)close.charAt(0)) + Math.random());
		}
		return null;
	}
	
	public Tuple<Integer,Integer> findMatch(int start, int end)//start and end of the pattern that we wish to find the match of
	{
		int inputPatternLength = end - start;
		String inputPattern = getText().substring(start,end);
		
		if(findClosePattern(inputPattern) != null)//if its an open
		{
			String targetPattern = findClosePattern(inputPattern);
			int targetPatternLength = targetPattern.length();
			for(int i = start + 1; i < getText().length() - targetPatternLength + 1; i++)
			{
				if(getText().charAt(i) == '\"' && (i == 0 || getText().charAt(i-1) != '\\'))
				{
					i = findCloseQuoteToTheRight(i);
					if(i == -1)break;
					i++;
				}
				try
				{
					if(getText().substring(i,i + inputPatternLength).equals(inputPattern))
						i = findMatch(i,i + inputPatternLength).a + 1;
				}catch(Exception e){}
				try
				{
					if(getText().substring(i,i + targetPatternLength).equals(targetPattern))
						return new Tuple<>(i,i + targetPatternLength);
				}catch(Exception e){}
			}
		}
		else// if its a close
		{
			String targetPattern = findOpenPattern(inputPattern);
			int targetPatternLength = targetPattern.length();
			for(int i = start - 1; i >= 0; i--)
			{
				if(getText().charAt(i) == '\"' && (i == 0 || getText().charAt(i-1) != '\\'))
				{
					i = findOpenQuoteToTheLeft(i);
					if(i == -1)break;
					i--;
				}
				try
				{
					if(getText().substring(i,i + inputPatternLength).equals(inputPattern))
						i = findMatch(i,i + inputPatternLength).a - 1;
				}catch(Exception e){}
				try
				{
					if(getText().substring(i,i + targetPatternLength).equals(targetPattern))
						return new Tuple<>(i,i + targetPatternLength);
				}catch(Exception e){}
			}
		}
		return new Tuple<>(0,0);
	}
	public int findOpenQuoteToTheLeft(int i)
	{
		i--;
		for(;i >= 0; i--)
		{
			if(getText().charAt(i) == '\"')
			{
				if(i == 0 || getText().charAt(i - 1) != '\\')
				{
					return i;
				}
			}
		}
		return -1;
	}
	public int findCloseQuoteToTheRight(int i)
	{
		i++;
		for(;i < getText().length(); i++)
		{
			if(getText().charAt(i) == '\"')
			{
				if(i == 0 || getText().charAt(i - 1) != '\\')
				{
					return i;
				}
			}
		}
		return -1;
	}
	public void removeHighlights()
	{
		highlighter.removeAllHighlights();
	}
	public ArrayList<Integer> removeDuplicates(ArrayList<Integer> ints)
	{
		ArrayList<Integer> ret = new ArrayList<Integer>();
		for(int i : ints)
		{
			if(!ret.contains(i))
			{
				ret.add(i);
			}
		}
		
		return ret;
	}
	
	public class CustomKeyAndMouseListener implements MouseListener,KeyListener
	{
		private String tab = "    ";
		
		public void keyTyped(KeyEvent e){}
		public void enter()
		{
			int lastNewLine = findLastNewLine(jta.getCaretPosition()-1);
			int afterTabs = findNextNonSpaceCharacter(lastNewLine+1);
			String tabsToCopy = jta.getText().substring(lastNewLine+1,Math.min(afterTabs,jta.getCaretPosition()));
			if(jta.getText().length() > afterTabs && jta.getText().charAt(afterTabs) == '{')
			{
				tabsToCopy += tab;
			}
			insert("\n" + tabsToCopy,jta.getCaretPosition());
		}
		public void tab()
		{
			if(jta.getSelectedText() == null)
				insert(tab,jta.getCaretPosition());
			else
			{
				ArrayList<Integer> allNewLinesInTheMiddle = new ArrayList<>();
				for(int i = jta.getSelectionStart(); i < jta.getSelectionEnd(); i++)
				{
					allNewLinesInTheMiddle.add(findLastNewLine(i));
				}
				allNewLinesInTheMiddle = removeDuplicates(allNewLinesInTheMiddle);
				ArrayList<Tuple<String,Integer>> insertions =  new ArrayList<>();
				for(int i : allNewLinesInTheMiddle)
				{
					insertions.add(new Tuple<String,Integer>(tab,i+1));
				}
				int lastInsertion = insertMultiple(insertions);
				jta.select(insertions.get(0).b,lastInsertion);
			}
		}
		public void shiftTab()
		{
			try
			{
				if(jta.getSelectedText() == null)
				{
					int oldCaretPos = jta.getCaretPosition();
					if(jta.getText().substring(oldCaretPos-tab.length(),oldCaretPos).equals(tab))
					{
						remove(oldCaretPos-tab.length(),oldCaretPos);
						jta.setCaretPosition(oldCaretPos - tab.length());
					}
				}
				else
				{
					ArrayList<Integer> allNewLinesInTheMiddle = new ArrayList<>();
					for(int i = jta.getSelectionStart(); i < jta.getSelectionEnd(); i++)
					{
						allNewLinesInTheMiddle.add(findLastNewLine(i));
					}
					allNewLinesInTheMiddle = removeDuplicates(allNewLinesInTheMiddle);
					ArrayList<Tuple<Integer,Integer>> removals =  new ArrayList<>();
					for(int i : allNewLinesInTheMiddle)
					{
						try
						{
							if(getText().substring(i+1,i+1 + tab.length()).equals(tab))
							{
								removals.add(new Tuple<Integer,Integer>(i+1,i+1 + tab.length()));
							}
						}
						catch(Exception ex){}
					}
					int lastRemoval = removeMultiple(removals);
					if(removals.size() > 0)
					{
						jta.select(removals.get(0).a,lastRemoval);
					}
				}
			}
			catch(StringIndexOutOfBoundsException exc)
			{
				
			}
		}
		public void keyPressed(KeyEvent e)
		{
			
			if(getMode() == LTETextBox.CODING_MODE)
			{
				removeHighlights();
				/*if(e.getKeyCode() == KeyEvent.VK_SPACE)
				{
					for(char c : getText().toCharArray())
					{
						p((int)c);
					}
					
				}*/
				if(e.getKeyCode() == KeyEvent.VK_BACK_SPACE)
				{
					if(gui.getViewedTab() instanceof RunTab)
					{
						((RunTab)gui.getViewedTab()).backspaceSystemIn();
						e.consume();
					}
				}
				else if(e.getKeyChar() != '\u0000' && e.getKeyCode() != KeyEvent.VK_SHIFT && e.getKeyCode() != KeyEvent.VK_CONTROL)
				{
					if(gui.getViewedTab() instanceof RunTab)
					{
						if(e.getKeyChar() == '\n')
						{
							((RunTab)gui.getViewedTab()).inputSystemIn();
						}
						else
						{
							((RunTab)gui.getViewedTab()).appendSystemIn(e.getKeyChar()+"");
						}
						
					}
				}
				
				if(e.getKeyCode() == KeyEvent.VK_HOME)
				{
					int lastNewLine = findLastNewLine(jta.getCaretPosition()-1);
					int afterTabs = findNextNonSpaceCharacter(lastNewLine+1);
					int originalCaretPosition = jta.getCaretPosition();
					if(jta.getCaretPosition() != afterTabs)
					{
						if(gui.getAEKL().shiftDown())
						{
							moveCaretPos(afterTabs);
							e.consume();
						}
						else
						{
							setCaretPos(afterTabs);
							e.consume();
						}
					}
				}
				if(e.getKeyCode() == KeyEvent.VK_SHIFT)
				{
					if(gui.getAEKL().controlDown())
					{
						enter();
						insert("{",jta.getCaretPosition());
						enter();
						int targetCaretPosition = jta.getCaretPosition();
						enter();
						shiftTab();
						insert("}",jta.getCaretPosition());
						setCaretPos(targetCaretPosition);
						
						
					}
				}
				if(e.getKeyCode() == KeyEvent.VK_ENTER)
				{
					enter();
					e.consume();
				}
				if(e.getKeyCode() == KeyEvent.VK_TAB)
				{
					if(!gui.getAEKL().shiftDown())
					{
						tab();
					}
					else
					{
						shiftTab();
					}
					e.consume();
				}
				
			}
			if(e.getKeyCode() == KeyEvent.VK_Z)
			{
				if(gui.getAEKL().controlDown())
				{
					undo();
					e.consume();
				}
			}
			if(e.getKeyCode() == KeyEvent.VK_Y)
			{
				if(gui.getAEKL().controlDown())
				{
					redo();
					e.consume();
				}
			}
			if(e.getKeyCode() == KeyEvent.VK_SPACE)
			{
				if(gui.getAEKL().controlDown())
				{
					insert(" ",jta.getCaretPosition());
					e.consume();
				}
			}
			/*if(e.getKeyCode() == KeyEvent.VK_RIGHT)
			{
				if(gui.getAEKL().shiftDown())
				{
					jta.moveCaretPosition(jta.getCaretPosition() + 1);
				}
				else
				{
					jta.setCaretPosition(jta.getCaretPosition() + 1);
				}
				e.consume();
			}
			if(e.getKeyCode() == KeyEvent.VK_LEFT)
			{
				if(gui.getAEKL().shiftDown())
				{
					jta.moveCaretPosition(jta.getCaretPosition() - 1);
				}
				else
				{
					jta.setCaretPosition(jta.getCaretPosition() - 1);
				}
				e.consume();
			}*/
			if(e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_RIGHT)
			{
				new Thread(()->
				{
					try{Thread.sleep(1);}catch(Exception ex){}
					updateCaretLocation();
				}).start();
			}
			updateCaretLocation();
		}
		public void undo()
		{
			int oldCaretPos = jta.getCaretPosition();
			gui.getViewedTab().undo();
			try{jta.setCaretPosition(oldCaretPos);}catch(Exception e){}
		}
		public void redo()
		{
			int oldCaretPos = jta.getCaretPosition();
			gui.getViewedTab().redo();
			try{jta.setCaretPosition(oldCaretPos);}catch(Exception e){}
		}
		public int findLastNewLine(int index)
		{
			for(int i = index; i >= 0; i--)
			{
				try
				{
					if(jta.getText(i,1).equals("\n"))
					{
						return i;
					}
				}
				catch(BadLocationException e)
				{
					System.out.println("Impossible");
				}
				
			}
			return -1;
		}

		public int findNextNonSpaceCharacter(int startIndex)
		{
			for(int i = startIndex; i < jta.getText().length(); i++)
			{
				char currentChar = jta.getText().charAt(i);
				if(currentChar != ' ' && currentChar != '\t')
				{
					return i;
				}
			}
			return jta.getText().length();
		}
		public int previousSpaceToCursor(int cursorLocation)
		{
			String text = jta.getText();
			for(int i = cursorLocation - 1; i >= 0 && i < text.length(); i--)
			{
				if(!SuggestionMaker.contains(SuggestionMaker.allowed_characters_in_word,text.charAt(i)))
				{
					return i;
				}
			}
			return -1;
		}
		public int nextSpaceToCursor(int cursorLocation)
		{
			String text = jta.getText();
			for(int i = cursorLocation - 1; i < text.length() && i >= 0; i++)
			{
				if(!SuggestionMaker.contains(SuggestionMaker.allowed_characters_in_word,text.charAt(i)))
				{
					return i;
				}
			}
			return text.length();
		}
		public String selectedWord(int caretLocation)
		{
			//p("jta.getText().substring("+(previousSpaceToCursor(caretLocation)+1)+","+nextSpaceToCursor(caretLocation)+")");
			int start = previousSpaceToCursor(caretLocation)+1;
			int end = nextSpaceToCursor(caretLocation);
			if(start >= end)
			{
				if(jta.getText().charAt(end) == ' ' || jta.getText().charAt(end) == '\t' || jta.getText().charAt(end) == '\n' )
				{
					return "";
				}
				else
				{
					return jta.getText().charAt(end)+"";
				}
				
			}
			else return jta.getText().substring(start,end);
		}
		public void keyReleased(KeyEvent e)
		{
			updateCaretLocation();
			
		}
		public void mouseClicked(MouseEvent e){}
		public void mouseEntered(MouseEvent e){}
		public void mouseExited(MouseEvent e){}
		public void mouseReleased(MouseEvent e)
		{
			int lastSelectionStart = LTETextBox.this.lastSelectionStart;
			int lastSelectionEnd = LTETextBox.this.lastSelectionEnd;
			updateCaretLocation();
			synchronized(this)
			{
				try
				{
					if(gui.getAEKL().controlDown() && e.getButton() == MouseEvent.BUTTON1)
					{
						String selectedWord;
						if(jta.getSelectedText() == null || (jta.getSelectedText().length() <= 1))
							selectedWord = selectedWord(caretLocation);
						else
							selectedWord = jta.getSelectedText();
						if(lastSelectionStart == lastSelectionEnd)
						{
							insert(selectedWord,lastCaretLocation);
						}
						else
						{
							remove(lastSelectionStart,lastSelectionEnd);
							insert(selectedWord,lastSelectionStart);
						}
						e.consume();
						
					}
					
				}
				catch(Exception exx)
				{
					
				}
				
			}
			
		}
		public void mousePressed(MouseEvent e)
		{
			removeHighlights();
			
		}
		
	}
}