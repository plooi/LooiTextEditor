package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.io.File;
import javax.swing.JOptionPane;



public class SelectFontSizeButton extends RightClickButton
{
    //INTERFACE
    public void set(double x, double y, double w, double h)
    {
        super.set(x, y, w ,h);
    }
    //END INTERFACE
    protected Gui gui;
    public SelectFontSizeButton(Gui gui, Background bg)
    {
        super(bg);
        initSelectFontSizeButton(gui);
    }
    public void initSelectFontSizeButton(Gui gui)
    {
        this.gui = gui;
    }
    public void action()
    {
        String newFontSize = JOptionPane.showInputDialog(null, "Enter font size:", gui.getTextBoxModifier().getFontSize());
        if(newFontSize == null)return;
        try
        {
            int newFontSizeInt = Integer.parseInt(newFontSize);
            gui.getTextBoxModifier().setFontSize(newFontSizeInt);
            gui.getTextBoxMethods().refresh();
        }
        catch(Exception e)
        {
            
        }
    }
    public void rightClick()
    {
        
    }
    
}