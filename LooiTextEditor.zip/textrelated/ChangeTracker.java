package textrelated;
import java.util.ArrayList;
import static ljs.Obj.*;

/*
This class can
    track changes
    undo 
    redo

*/
public class ChangeTracker
{
    protected LimitedStringList versions;
    protected int versionsIndex = 0;
    
    public ChangeTracker(String firstVersion)
    {
        initCT(firstVersion);
    }
    public void initCT(String firstVersion)
    {
        versions = new LimitedStringList();
        addChange(firstVersion);
    }
    public void addChange(String text)
    {
        while(versions.size() > versionsIndex + 1)
        {
            versions.remove(versions.size() - 1);
        }
        versions.add(text);
        versionsIndex = versions.size() - 1;
        //p(versions);
    }
    public String getUndo()
    {
        if(versionsIndex > 0)
        {
            versionsIndex--;
            return versions.get(versionsIndex);
        }
        else if(versionsIndex == 0)//no more undos
        {
            return versions.get(versionsIndex);
        }
        else
        {
            throw new RuntimeException("Bad");
        }
    }
    public String getRedo()
    {
        if(versionsIndex < versions.size()-1)
        {
            versionsIndex++;
            return versions.get(versionsIndex);
        }
        else if(versionsIndex == versions.size()-1)//no more redos
        {
            return versions.get(versionsIndex);
        }
        else
        {
            throw new RuntimeException("Bad");
        }
    }
}