package lte4;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import textrelated.*;
//OMG DUDE USE StyledDocument.setCharacterAttributes(int offset, int length, AttributeSet s, boolean replace)
/*
Contains the high level GUI elements
*/
public class Gui
{
    //INTERFACE
    public MyWindow getWindow(){return window;}
    public MyTextBox getTextBox(){return textBox;}
    public GuiBar getGuiBar(){return guiBar;}
    public int getTopBarHeight(){return topBarHeight;}
    public void setTopBarHeight(int h){topBarHeight = h;}
    public long getLocationThreadIterationWait(){return locationThreadIterationWait;}
    public void setLocationThreadIterationWait(long l){locationThreadIterationWait = l;}
    public void setGuiBarWidth(Component.Getter<Integer> gi){getGuiBarWidth = gi;}
    public GuiBarModeManager getGBMM(){return gbmm;}
    public GuiStateManager getGuiStateManager(){return gsm;}
    public TextBoxModifier getTextBoxModifier(){return tbm;}
    public TextBoxMethods getTextBoxMethods(){return tbm.getMethods();}
    
    //END INTERFACE
    
    public static String stateSaverFolderPath = "state_save_folder";
    
    
    
    protected MyWindow window;
    protected MyTextBox textBox;
    protected GuiBar guiBar;
    protected GuiBarModeManager gbmm;
    protected GuiStateManager gsm;
    protected TextBoxModifier tbm;
    protected WindowModifier wm;
    
    protected StateSaver stateSaver;
    protected Component.Getter<Integer> getGuiBarWidth = ()->0;
    protected int topBarHeight;
    protected long locationThreadIterationWait;
    
    public Gui()
    {
        init();
    }
    public void init()
    {
        initNumbers();
        initComponents();
        
        
    }
    public void initComponents()
    {
        stateSaver = StateSaver.it = new StateSaver(stateSaverFolderPath);
        window = new MyWindow(this)
        {
            public void initWindow()
            {
                setBounds(0, 0, 1000, 1000);
                uponClosing(()->
                {
                    stateSaver.uponClosing();
                    stop();
                });
            }
        };
        textBox = new MyTextBox(this);
        guiBar = new GuiBar(this);
        tbm = new TextBoxModifier(this);
        WindowModifier.it = (wm = new WindowModifier(this));
        window.add(textBox);
        window.add(guiBar);
        guiBar.start();
        initComponents2();
    }
    public void initComponents2()
    {
        //textBox.setBounds(()->0, ()->getTopBarHeight(), ()->window.getWidth() - getGuiBarWidth.get(), ()->window.getHeight() - getTopBarHeight());
        //guiBar.setBounds(()->window.getWidth() - getGuiBarWidth.get(), ()->getTopBarHeight(), ()->getGuiBarWidth.get(), ()->window.getHeight() - getTopBarHeight());
        textBox.setBounds(()->getGuiBarWidth.get(), ()->getTopBarHeight(), ()->window.getWidth() - getGuiBarWidth.get(), ()->window.getHeight() - getTopBarHeight());
        guiBar.setBounds(()->0, ()->getTopBarHeight(), ()->getGuiBarWidth.get(), ()->window.getHeight() - getTopBarHeight());
        gbmm = new GuiBarModeManager(this);
        gbmm.switchToMode(1);
        gsm = new GuiStateManager(this);
    }
    public void initNumbers()
    {
        topBarHeight = 0;
        locationThreadIterationWait = 150;
    }
     
    
}