package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.io.File;
import java.util.HashMap;
import java.util.ArrayList;
//styleFileFolder

public class StyleFileSelector implements StateSaver.Closeable
{
    //INTERFACE
    
    public File getFile(String extension){return langToStyleFile.get(extension);}
    
    /*
    If this file has a "-" in it's name, then
    map it. Otherwise, return false;
    
    If this file has a "-" at the very beginning
    then it gets set to be the default style file
    */
    public boolean tryPut(File styleFile){return _tryPut(styleFile);}
    
    /*
    If new style files have popped up, they may be added
    */
    public void refresh(){_refresh();}
    
    public static StyleFileSelector it;
    public static String defaultStyleFileKey = "*default";
    //END INTERFACE
    protected HashMap<String, File> langToStyleFile = new HashMap<>();
    public StyleFileSelector()
    {
        initStyleFileSelector();
    }
    public void initStyleFileSelector()
    {
        addToStateSaver();
        _refresh();
        loadPreviousState();
    }
    public void addToStateSaver()
    {
        StateSaver.it.addCloseable(this);
    }
    public void closeProgram()
    {
        ArrayList<Object> toSave = arrayList();
        for(String lang : langToStyleFile.keySet())
        {
            toSave.add(lang + "<" + langToStyleFile.get(lang).getAbsolutePath());
        }
        StateSaver.it.save("StyleFileSelector", toSave);
    }
    public void loadPreviousState()
    {
        try
        {
            ArrayList<String> loaded = StateSaver.it.load("StyleFileSelector");
            if(loaded == null || loaded.get(0).equals("*null")) 
                return;
            else
            {
                for(String langLessThanStyleFile : loaded)
                {
                    if(!langLessThanStyleFile.contains("<"))continue;//this shouldn't be possible
                    int indexOfLessThan = langLessThanStyleFile.indexOf("<");
                    String lang = langLessThanStyleFile.substring(0, indexOfLessThan);
                    String file = langLessThanStyleFile.substring(indexOfLessThan+1);
                    langToStyleFile.put(lang, new File(file));
                }
            }
                
        }
        catch(Exception e)
        {
            //JOptionPane.showMessageDialog("Could not load previous hotkey file.");
        }
    }
    public boolean _tryPut(File styleFile)
    {
        File f = styleFile;
        boolean canDoIt;
        if(canDoIt = f.getName().contains("-"))
        {
            String extension = f.getName().substring(0, f.getName().indexOf("-"));
            if(extension.equals("")) extension = defaultStyleFileKey;
            langToStyleFile.put(extension, f);
        }
        return canDoIt;
    }
    public void _refresh()
    {
        String styleFileFolder = StyleManager.styleFileFolder;
        File styleFileFolderFile = new File(styleFileFolder);
        if(!styleFileFolderFile.exists())
        {
            return;
        }
        File[] styleFiles = styleFileFolderFile.listFiles((f)->f.isFile());
        for(File f : styleFiles)
        {
            if(f.getName().contains("-"))
            {
                String targetedExtension = f.getName().substring(0, f.getName().indexOf("-"));
                if(langToStyleFile.get(targetedExtension) == null)
                    tryPut(f);
            }
            
        }
    }
}