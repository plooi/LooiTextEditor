package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.io.File;
import state.*;

/*
This is a button that will not have text overflow off the edge
*/

public abstract class BetterButton extends Button
{
    protected boolean needToCheckTextLength = false;
    public BetterButton(Background bg)
    {
        super(0, 0, 10, 10, "", bg);
    }
    public void setText(String text)
    {
        needToCheckTextLength = true;
        super.setText(text);
    }
    public void possiblyShortenText()
    {
        String text = getText();
        
        //binary search to see how much we have to cut the string
        
        int max = text.length();
        int min = 0;
        int mid;
        while(true)
        {
            mid = (max+min)/2;
            if(isTooLong(text.substring(0, mid)))
            {
                max = mid;
            }
            else
            {
                min = mid;
            }
            if(min + 1 == max)
            {
                if(isTooLong(text.substring(0, max)))
                {
                    setText(text.substring(0, min) + "...");
                }
                else
                {
                    setText(text.substring(0, max));
                }
                return;
            }
            if(max == min)
            {
                setText(text.substring(0, mid));
                return;
            }
            //p(text.substring(0, mid));
        }
        
    }
    public boolean isTooLong(String s)
    {
        int stringWidthOnScreen = getGraphics().getFontMetrics().stringWidth(s);
        double myInternalWidth = getWidth();
        double internalWidthToRealWidthRatio = getInternalWidth()/((double)thisLooiCanvas().getViewWidth());
        double stringInternalWidth = stringWidthOnScreen * internalWidthToRealWidthRatio;
        
        if(stringInternalWidth > myInternalWidth - 20)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public void looiPaint()
    {
        if(needToCheckTextLength)
        {
            possiblyShortenText();
            needToCheckTextLength = false;
        }
        super.looiPaint();
    }
}