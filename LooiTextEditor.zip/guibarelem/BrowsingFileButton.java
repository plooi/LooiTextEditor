package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.io.File;



public class BrowsingFileButton extends RightClickButton
{
    //INTERFACE
    public void set(double x, double y, double w, double h)
    {
        setPosition(x, y);
        setDimensions(w, h);
    }
    public File getMyFile(){return myFile;}
    //END INTERFACE
    protected Gui gui;
    protected File myFile;
    protected ArrayList<BrowsingFileButton> container;
    protected FileBrowser otherContainer;
    public BrowsingFileButton(Gui gui, Background bg, File myFile, ArrayList<BrowsingFileButton> container, FileBrowser otherContainer)
    {
        super(bg);
        init(gui, myFile, container, otherContainer);
    }
    public void init(Gui gui, File myFile, ArrayList<BrowsingFileButton> container, FileBrowser otherContainer)
    {
        this.gui = gui;
        this.myFile = myFile;
        this.container = container;
        this.otherContainer = otherContainer;
        setText(myFile.getName());
    }
    public void action()
    {
        if(getY() + getHeight() > otherContainer.getY() && getY() < otherContainer.getY() + otherContainer.getHeight())
        {
            if(myFile.isDirectory())
            {
                otherContainer.openDir(myFile.getAbsolutePath());
            }
            else
            {
                otherContainer.fulfillBrowsePromise(myFile);
            }
        }
    }
    public void rightClick()
    {
        otherContainer.getBrowsingFileButtonPopup().activateOpen(this);
    }
    public void delete()
    {
        super.delete();
        if(container != null)
            container.remove(this);
        if(otherContainer != null)
            otherContainer.remove(this);
    }
}