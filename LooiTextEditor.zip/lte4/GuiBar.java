package lte4;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;


/*
Provide a generic GuiBar
*/
public class GuiBar extends LooiCanvas
{
    protected Gui gui;
    public GuiBar(Gui gui)
    {
        super(60);
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        setLocationThreadIterationWait(gui.getLocationThreadIterationWait());
    }
    public void fitCanvas()
    {
        setInternalWidth(getWindowWidth());
        setInternalHeight(getWindowHeight());
        super.fitCanvas();
        
    }
}