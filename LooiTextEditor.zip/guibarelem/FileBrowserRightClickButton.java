package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;
import java.io.File;
import state.*;

public class FileBrowserRightClickButton extends RightClickButton
{
    protected FileBrowsingPopupMenu menu;
    protected Gui gui;
    public FileBrowserRightClickButton(Gui gui, Background b)
    {
        super(b);
        initFBRCB(gui);
    }
    public void initFBRCB(Gui gui)
    {
        this.gui = gui;
        menu = makeFileBrowsingPopupMenu();
        
        miscInitFBRCB();
    }
    public FileBrowsingPopupMenu makeFileBrowsingPopupMenu()
    {
        return new FileBrowsingPopupMenu();
    }
    public void miscInitFBRCB()
    {
        updateShadowsAndStuff();
    }
    public void updateShadowsAndStuff()
    {
        setHoverLightUp(0);
        setDepth(0);
        setButtonPressShadow(0);
    }
    public void action()
    {
        
    }
    public void rightClick()
    {
        menu.activateOpen(((BrowseState)gui.getGuiStateManager().states().get("browseState")).getFileBrowser());
    }
    public void setBackground(Background b)
    {
        super.setBackground(b);
        updateShadowsAndStuff();
        setPressedBackground(b);
    }
}