package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.lang.Process;
import java.util.HashMap;
import java.lang.Runtime;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.File;


public class InvalidStyleDocumentException extends RuntimeException
{
    protected String problem;
    public InvalidStyleDocumentException(String problem)
    {
        init(problem);
    }
    public void init(String problem)
    {
        this.problem = problem;
    }
    public String getProblem()
    {
        return problem;
    }
    public String toString()
    {
        return "InvalidStyleDocumentException: " + problem;
    }
}