package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;
import java.io.File;

public class UpDirectoryBtn extends Button
{
    protected Gui gui;
    protected FileBrowser fileBrowser;
    public UpDirectoryBtn(Gui gui, FileBrowser fileBrowser)
    {
        super(110,10,50,50,"<---",new Background(new Color(150,150,250)));
        init(gui, fileBrowser);
    }
    public void init(Gui gui, FileBrowser fileBrowser)
    {
        this.gui = gui;
        this.fileBrowser = fileBrowser;
    }
    public void action()
    {
        //p("up");
        fileBrowser.openDir(oneDirectoryUp(fileBrowser.getCurrentPath()));
        
    }
    public boolean touchingMouseAndInFront(){return touchingMouse();}
    
    
    public static String oneDirectoryUp(String oldPath)
    {
        oldPath = new File(oldPath).getAbsolutePath();
        String separator = File.separator;
        String newPath;
        if(oldPath.endsWith(separator))
            oldPath = oldPath.substring(0, oldPath.length() - 1);
        
        if(!oldPath.contains(separator))//There is no more directories up
            return oldPath + separator;
        newPath = oldPath.substring(0,oldPath.lastIndexOf(separator)+1);
        return newPath;
    }
}
