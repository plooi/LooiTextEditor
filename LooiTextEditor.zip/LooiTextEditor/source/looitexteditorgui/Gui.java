package looitexteditorgui;
import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JFrame;
import javax.swing.JFileChooser;
import java.io.File;
import java.util.ArrayList;
import java.awt.Canvas;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Container;
import java.lang.InterruptedException;
import ljs.gui.looicanvas.gui_essentials.Background;
import ljs.gui.looicanvas.gui_essentials.Font;
import java.awt.Graphics;

public class Gui
{
	public static final String color_file = "color_file.txt";
	private Window mainWindow;
	private LTETextBox textArea;
	private LTEMenuBar menuBar;
	private LTEFileBar fileBar;
	private Executor executor;
	private int fileBarOffset;
	private Tab viewedTab;
	private SuggestionTab suggestionTab;
	private AllEncompassingKeyListener aekl;
	public static final int DEFAULT_WINDOW_WIDTH = 1000;
	public static final int DEFAULT_WINDOW_HEIGHT = 1000;
	private static final String program_name = "Looi Text Editor";
	public Gui(int fileBarOffset, long saveMillisecondWait)
	{
		this.fileBarOffset = fileBarOffset;
		mainWindow = new Window();
		setWindowTitle(program_name);
		mainWindow.uponClosing(()->
		{
			ArrayList<Tab> toDelete = new ArrayList<>();
			for(Tab t : this.fileBar.getTabs())
			{
				if(t instanceof RunTab)
				{
					toDelete.add(t);
				}
			}
			for(Tab t : toDelete)
			{
				((RunTab)t).delete();
			}
			stop();
		});
		mainWindow.add(suggestionTab = new SuggestionTab(fileBarOffset,this));
		mainWindow.setBounds(10,10,DEFAULT_WINDOW_WIDTH,DEFAULT_WINDOW_HEIGHT);
		mainWindow.getJavaComponent().setIconImage(loadImage("icon.png"));
		
		mainWindow.getJavaComponent().setJMenuBar(menuBar = new LTEMenuBar(this));
		mainWindow.add(fileBar = new LTEFileBar(fileBarOffset,this));
		mainWindow.add(textArea = new LTETextBox(saveMillisecondWait, fileBarOffset,mainWindow,this));
		
		aekl = new AllEncompassingKeyListener(this);
		textArea.getJTextArea().addKeyListener(aekl);
		suggestionTab.getJTextArea().addKeyListener(aekl);
		fileBar.getCanvas().addKeyListener(aekl);
		
		executor = new Executor(this);
		
		loadColorFile();
		
		
		fileBar.start();
		
		try{Thread.sleep(50);}catch(InterruptedException e){}
		mainWindow.toggleSize();
	}
	public AllEncompassingKeyListener getAEKL(){return aekl;}
	public LTETextBox getTextArea(){return textArea;}
	public LTEMenuBar getMenuBar(){return menuBar;}
	public LTEFileBar getFileBar(){return fileBar;}
	public Executor getExecutor(){return executor;}
	public int getFileBarOffset(){return fileBarOffset;}
	public SuggestionTab getSuggestionTab(){return suggestionTab;}
	public void setViewedTab(Tab ft)
	{
		if(ft == null)
		{
			textArea.setEditable(false);
			textArea.wrapLine(true);
		}
		else
		{
			if(ft instanceof FileTab)
			{
				textArea.setEditable(true);
				textArea.wrapLine(false);
			}
			else if(ft instanceof RunTab)
			{
				textArea.setEditable(true);
				textArea.wrapLine(true);
			}
		}
		
		viewedTab = ft;
		if(viewedTab == null)
			accountForFile(null);
		else
			accountForFile(viewedTab.getText());
	}
	public Tab getViewedTab(){return viewedTab;}
	public Window getMainWindow(){return mainWindow;}
	public void setWindowTitle(String t){mainWindow.getJavaComponent().setTitle(t);}
	public void accountForFile(String fileName)
	{
		if(fileName == null || fileName.equals(""))
		{
			setWindowTitle(program_name);
		}
		else
		{
			setWindowTitle(program_name + " (" + fileName + ")");
		}
	}
	public Color getBackgroundColor()
	{
		return textArea.getJTextArea().getBackground();
	}
	public void setBackgroundColor(Color c)
	{
		textArea.getJTextArea().setBackground(c);
		suggestionTab.getJTextArea().setBackground(c);
		fileBar.setBackgroundColor(c);
		saveColorFile();
	}
	public void setTextColor(Color c)
	{
		textArea.getJTextArea().setForeground(c);
		suggestionTab.getJTextArea().setForeground(c);
		saveColorFile();
	}
	public Color getTextColor(){return textArea.getJTextArea().getForeground();}
	public void setCaretColor(Color c)
	{
		textArea.getJTextArea().setCaretColor(c);
		saveColorFile();
	}
	public Color getCaretColor()
	{
		return textArea.getJTextArea().getCaretColor();
	}
	public void setSelectionColor(Color c)
	{
		textArea.setSelectionColor(c);
		saveColorFile();
	}
	public void setSelectedTextColor(Color c)
	{
		textArea.getJTextArea().setSelectedTextColor(c);
		saveColorFile();
	}
	public void setMatchingTextHighlightColor(Color c)
	{
		textArea.setMatchingTextHighlightColor(c);
		saveColorFile();
	}
	public void saveColorFile()
	{
		
		Color[] colors = array(getBackgroundColor(),getTextColor(),getCaretColor(),textArea.getSelectionColor(),textArea.getMatchingTextHighlightColor(),textArea.getJTextArea().getSelectedTextColor());
		Object[] save = new Object[colors.length * 3];
		for(int i : range(colors))
		{
			save[i*3+0] = colors[i].getRed();
			save[i*3+1] = colors[i].getGreen();
			save[i*3+2] = colors[i].getBlue();
		}
		saveText(color_file,save);
	}
	public void loadColorFile()
	{
		if(!new File(color_file).exists())
			return;
		String[] load = loadText(color_file);
		int[] rgbs = new int[load.length];
		for(int i : range(load))
		{
			rgbs[i] = Integer.parseInt(load[i]);
		}
		try{setBackgroundColor(new Color(rgbs[0],rgbs[1],rgbs[2]));}catch(ArrayIndexOutOfBoundsException e){}
		try{setTextColor(new Color(rgbs[3],rgbs[4],rgbs[5]));}catch(ArrayIndexOutOfBoundsException e){}
		try{setCaretColor(new Color(rgbs[6],rgbs[7],rgbs[8]));}catch(ArrayIndexOutOfBoundsException e){}
		try{textArea.setSelectionColor(new Color(rgbs[9],rgbs[10],rgbs[11]));}catch(ArrayIndexOutOfBoundsException e){}
		try{textArea.setMatchingTextHighlightColor(new Color(rgbs[12],rgbs[13],rgbs[14]));}catch(ArrayIndexOutOfBoundsException e){}
		try{textArea.getJTextArea().setSelectedTextColor(new Color(rgbs[15],rgbs[16],rgbs[17]));}catch(ArrayIndexOutOfBoundsException e){}
	}
	
}