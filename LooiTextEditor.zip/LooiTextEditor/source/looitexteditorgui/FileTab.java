package looitexteditorgui;
import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.io.File;
import javax.swing.JScrollPane;
import java.io.*;
import java.lang.StringBuilder;
public class FileTab extends ljs.gui.looicanvas.gui_essentials.Button implements Tab
{
	private String path;
	
	private ljs.gui.looicanvas.gui_essentials.Button deleteButton;
	private double virtualX = 0;
	public void setVirtualX(double vx){virtualX = vx;}
	public double getVirtualX(){return virtualX;}
	private Font textFont = new Font("",Font.PLAIN,16);
	private boolean needToSetSize = true;
	private Gui gui;
	private ArrayList<String> versions = new ArrayList<>();
	private int versionIndex = 0;
	private double viewX,viewY;
	public void update(double viewX, double viewY)
	{
		synchronized(gui.getTextArea())
		{
		this.viewX = viewX;
		this.viewY = viewY;
		}
	}
	public String savableString(){return getPath();}
	public FileTab(Gui gui, String path, double fileButtonHeight, double fileBarOffset, double fileButtonCloseButtonWidth)
	{
		super(0,(fileBarOffset - fileButtonHeight)/2.0,100,fileButtonHeight,path,new Background(new Color(235,235,255)));
		this.gui = gui;
		
		this.path = path;
		if(path.indexOf("\\") != -1)
		{
			setText(path.substring(path.lastIndexOf("\\")+1));
		}
		else
		{
			setText(path);
		}
		add(deleteButton = new ljs.gui.looicanvas.gui_essentials.Button(getWidth()-fileButtonCloseButtonWidth,0,fileButtonCloseButtonWidth,getHeight(),"  X",Background.LIGHT_GRAY_BACKGROUND)
		{
			public void action()
			{
				if(gui.getViewedTab() == FileTab.this)
					save();
				FileTab.this.delete();
				this.deactivate();
			}
		});
		
		setFont(textFont);
		
		Graphics g2 = thisLooiCanvas().getGraphics().create();
		g2.setFont(textFont);
		double stringWidth = g2.getFontMetrics().stringWidth(getText());
		//p(stringWidth);
		stringWidth *= getInternalWidth()/thisLooiCanvas().getViewWidth();
		setDimensions(stringWidth+gui.getFileBar().getFileButtonCloseButtonExtraSpaceFromFileButtonText()+fileButtonCloseButtonWidth,getHeight());
		//p(stringWidth);
		//p(stringWidth+gui.getFileBar().getFileButtonCloseButtonExtraSpaceFromFileButtonText()+fileButtonCloseButtonWidth);
		deleteButton.setPosition(getX() + getWidth()-fileButtonCloseButtonWidth,getY());
	}
	public String getPath(){return path;}
	public void save()
	{
		gui.getTextArea().getSaver().save();
	}
	public void delete()
	{
		if(isBeingViewed())
		{
			gui.setViewedTab(null);
			gui.getTextArea().setText("");
		}
		gui.getFileBar().removeTab(this);
		deactivate();
	}
	public void action()
	{
		view();
	}
	public void view()
	{
		synchronized(gui.getTextArea())
		{
			if(!fileExists())
			{
				delete();
				return;
			}
			gui.getTextArea().getSaver().save();
			gui.setViewedTab(this);
			String[] lines = loadText(path);
			String newText = "";
			boolean hasMoreThanZeroLines = false;
			for(String line : lines)
			{
				while(line.endsWith("\r"))
				{
					line = line.substring(0,line.length() - 1);
				}
				newText += line + "\n";
				hasMoreThanZeroLines = true;
				/*p("line length: " + line.length());//////
				for(char c : line.toCharArray())
				{
					p("char: " + (int)c );
				}*/
			}
			if(hasMoreThanZeroLines)
				newText = newText.substring(0,newText.length()-1);
			
			gui.getTextArea().setText(newText);
			((JScrollPane)gui.getTextArea().getJavaComponent()).getViewport().setViewPosition(new java.awt.Point((int)viewX,(int)viewY));
		}
	}
	public static String[] loadText(String path)
	{
		try
        {
            ArrayList<String> text = arrayList();
            FileInputStream fis = new FileInputStream(path);
            InputStreamReader isr = new InputStreamReader(fis);
            StringBuilder entireText = new StringBuilder();
			char read;
			int readInt;
			while((readInt = isr.read()) != -1)
			{
				read = (char)readInt;
				entireText.append(read);
			}
			String entireTextString = entireText.toString();
			while(true)
			{
				int newLineIndex = entireTextString.indexOf("\n");
				if(newLineIndex != -1)
				{
					text.add(entireTextString.substring(0,newLineIndex));
					if(newLineIndex+1 <= entireTextString.length())
					{
						entireTextString = entireTextString.substring(newLineIndex+1,entireTextString.length());
					}
					else
					{
						break;
					}
				}
				else
				{
					text.add(entireTextString);
					break;
				}
			}
            isr.close();
            return toStringArray(text);
        }
        catch(Exception e){throw new RuntimeException(e.toString());}
		
	}
	public boolean isBeingViewed(){return gui.getViewedTab()==this;}
	public void looiStep()
	{
		setPosition(virtualX - gui.getFileBar().getScrollX(),getY());
		super.looiStep();
	}
	public void addVersion(String v)
	{
		while(versions.size() > versionIndex + 1)
		{
			versions.remove(versions.size() - 1);
		}
		versions.add(v);
		versionIndex = versions.size() - 1;
	}
	public void undo()
	{
		synchronized(gui.getTextArea().getUndoManager())
		{
			if(versionIndex > 0)
			{
				versionIndex--;
				gui.getTextArea().setText(versions.get(versionIndex));
				gui.getTextArea().getUndoManager().setLastText(versions.get(versionIndex));
			}
		}
		
	}
	public void redo()
	{
		synchronized(gui.getTextArea().getUndoManager())
		{
			if(versionIndex < versions.size() - 1)
			{
				versionIndex++;
				gui.getTextArea().setText(versions.get(versionIndex));
				gui.getTextArea().getUndoManager().setLastText(versions.get(versionIndex));
			}
		}
		
	}
	public boolean fileExists()
	{
		return new File(path).exists();
	}
}