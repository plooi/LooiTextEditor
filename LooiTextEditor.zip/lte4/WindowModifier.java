package lte4;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;

public class WindowModifier
{
    public static WindowModifier it;
    public static final String defaultTitle = "Looi Text Editor";
    
    
    
    protected Gui gui;
    public WindowModifier(Gui gui)
    {
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        initWindow();
    }
    public void initWindow()
    {
        setTitle(defaultTitle);
        gui.getWindow().setIconImage(loadImage("icon.png"));
    }
    public void changeTitleFor(String fileName)
    {
        setTitle(defaultTitle + " (" + fileName + ")");
    }
    public void setTitle(String title)
    {
        gui.getWindow().setTitle(title);
    }
    
    
}