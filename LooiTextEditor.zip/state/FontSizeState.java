package state;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.util.HashMap;
import guibarelem.*;
import java.awt.Color;

public class FontSizeState implements GuiState
{
    protected Gui gui;
    protected ReturnButton returnButton;
    protected SelectFontSizeButton setFontSizeButton;
    
    public FontSizeState(Gui gui)
    {
        initFontSizeState(gui);
    }
    public void initFontSizeState(Gui gui)
    {
        this.gui = gui;
        returnButton = new ReturnButton(gui);
        setFontSizeButton = initFontSizeButton();
    }
    public SelectFontSizeButton initFontSizeButton()
    {
        SelectFontSizeButton ret = new SelectFontSizeButton(gui, new Background(new Color(255, 255, 200)));
        ret.set(10, 100, 280, 50);
        ret.setText("Select Font Size");
        return ret;
    }
    public void open(Gui gui, String previousStateName)
    {
        returnButton.activate();
        setFontSizeButton.activate();
    }
    public void close(Gui gui, String nextStateName)
    {
        returnButton.deactivate();
        setFontSizeButton.deactivate();
    }
}