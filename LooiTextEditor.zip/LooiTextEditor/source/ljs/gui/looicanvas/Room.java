package ljs.gui.looicanvas;

import java.util.ArrayList;

/**
 * This class represents a "room" in the game that contains various LooiObjects.
 * The program can switch between Rooms, just like a web page can switch 
 * between various sub-pages.
 * @author peter_000
 */
public abstract class Room 
    {
        private static ArrayList<Room> rooms = new ArrayList<>();
        private static ArrayList<Room> roomHistory = new ArrayList<>();
        
        private LooiCanvas myLooiWindow;
        private ArrayList<LooiObject> contents = new ArrayList<>();
        /**
         * Creates a new Room
         */
        public Room()
            {
                this(LooiCanvas.getMainCanvas());
            }
        /**
         * Creates a new Room that exists in myLooiWindow
         * @param myLooiWindow 
         */
        public Room(LooiCanvas myLooiWindow)
            {
                this.myLooiWindow = myLooiWindow;
                rooms.add(this);
                setup();
            }
        /**
         * Override this method. This method is executed upon the creation of 
         * this button. Use this method to add the objects of this Room.
         */
        protected abstract void setup();
        /**
         * Override this method. This method is executed upon the showing of 
         * this room. 
         */
        protected void uponShow(){}
        /**
         * Override this method. This method is executed upon the hiding of 
         * this room. 
         */
        protected void uponHide(){}
        /**
         * Adds obj to this Room
         * @param obj 
         */
        public void add(LooiObject obj)
            {
                contents.add(obj);
                if(getCurrentRoom() == this)
                    {
                        obj.activate();
                    }
            }
        /**
         * Removes obj from this room
         * @param obj 
         */
        public void remove(LooiObject obj)
            {
                contents.remove(obj);
                if(getCurrentRoom() == this)
                    {
                        obj.deactivate();
                    }
            }
        /**
         * Removes all current active LooiObjects, and then activates all of the 
         * contents of this room (1 layer deep).
         */
        public void show()
            {
                if(getCurrentRoom() == this)
                    return;
                if(getCurrentRoom() != null)
                {
                    getCurrentRoom().uponHide();
                }
                while(myLooiWindow.getNumActiveObjects() > 0)
                    {
                        myLooiWindow.getActiveObject(0).deactivate();
                    }
                for(LooiObject l : this.contents)
                    {
                        l.activate();
                        
                    }
                roomHistory.add(this);
                uponShow();
            }
        /**
         * Gets an object at the specified index from this room.
         * @param index
         * @return 
         */
        public LooiObject getObj(int index)
            {
                return contents.get(index);
            }
        /**
         * Gets how many objects there are contained by this Room
         * @return 
         */
        public int getNumObjs()
            {
                return contents.size();
            }
        /**
         * Removes all LooiObjects from this Room
         */
        public void clear()
            {
                contents.clear();
            }
        /**
         * Removes all LooiObjects from this Room and deactivates them
         */
        public void clearAndDeactivate()
            {
                for(LooiObject l : contents)
                    {
                        l.deactivate();
                    }
                clear();
            }
        /**
         * Gets a room from the static ArrayList of Rooms
         * @param index
         * @return 
         */
        public static Room getRoom(int index)
            {
                return rooms.get(index);
            }
        /**
         * Gets the number of Rooms that have been created
         * @return 
         */
        public static int getNumRooms()
            {
                return rooms.size();
            }
        /**
         * Gets a Room from the room history
         * @param index
         * @return 
         */
        public Room getRoomHistory(int index)
        {
            return roomHistory.get(index);
        }
        /**
         * Gets the length of the room history
         * @return 
         */
        public int getRoomHistoryLength()
        {
            return roomHistory.size();
        }
        /**
         * Gets the current room
         * @return 
         */
        public Room getCurrentRoom()
        {
            try
            {
                return getRoomHistory(getRoomHistoryLength()-1);
            }
            catch(IndexOutOfBoundsException e)
            {
                //there have been no rooms shown yet
                return null;
            }
        }
        
    }
