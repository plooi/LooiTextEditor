package looitexteditorgui;
import static ljs.Obj.*;
import ljs.gui.*;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.Font;


public class MenuItem extends JMenuItem
{
	public MenuItem(String name, Action action, Font font)
	{
		super(name);
		addActionListener((e)->action.act());
		setFont(font);
	}
	
	
}