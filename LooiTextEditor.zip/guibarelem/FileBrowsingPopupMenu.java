package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;
import java.io.File;
import javax.swing.JOptionPane;
public class FileBrowsingPopupMenu extends PopupMenu<FileBrowser>
{
    public FileBrowsingPopupMenu()
    {
        initFBPM();
    }
    public void initFBPM()
    {
        setDimensions(260, 100);
        setPosition(20, 0);
        add(new FlatButton(0, 0, 0, 0, "New File", Background.LIGHT_GRAY_BACKGROUND)
        {
            public void action()
            {
                String response = JOptionPane.showInputDialog(null, "Enter file name: ");
                if(response == null)
                {
                    FileBrowsingPopupMenu.this.deactivate();
                    return;
                }
                String fileName = enterDirectory(getCurrentData().getCurrentPath(), response);
                
                if(new File(fileName).exists())
                    if(new File(fileName).isFile())
                        JOptionPane.showMessageDialog(null, "File " + fileName + " already exists.");
                    else
                        JOptionPane.showMessageDialog(null, "Directory " + fileName + " already exists.");
                else
                {
                    boolean success = false;
                    try
                    {
                        new File(getCurrentData().getCurrentPath()).listFiles();
                        success = new File(fileName).createNewFile();
                    }catch(Exception e){}
                    if(!success)
                    {
                        JOptionPane.showMessageDialog(null, "Creation of file was unsuccessful.");
                    }
                }
                    
                //p("Created : " + fileName);
                FileBrowsingPopupMenu.this.deactivate();
                refresh();
                afterCreateNewFile();
            }
        });
        add(new FlatButton(0, 0, 0, 0, "New Directory", Background.LIGHT_GRAY_BACKGROUND)
        {
            public void action()
            {
                String response = JOptionPane.showInputDialog(null, "Enter directory name: ");
                if(response == null)
                {
                    FileBrowsingPopupMenu.this.deactivate();
                    return;
                }
                String directoryName = enterDirectory(getCurrentData().getCurrentPath(), response);
                if(new File(directoryName).exists())
                    if(new File(directoryName).isFile())
                        JOptionPane.showMessageDialog(null, "File " + directoryName + " already exists.");
                    else
                        JOptionPane.showMessageDialog(null, "Directory " + directoryName + " already exists.");
                else
                {
                    boolean success = new File(directoryName).mkdir();
                    if(!success)
                    {
                        JOptionPane.showMessageDialog(null, "Creation of directory was unsuccessful.");
                    }
                }
                
                FileBrowsingPopupMenu.this.deactivate();
                refresh();
            }
        });
    }
    public void refresh()
    {
        getCurrentData().openDir(getCurrentData().getCurrentPath());
    }
    public static String enterDirectory(String directory, String fileWeWishToEnter)
    {
        if(!directory.endsWith(File.separator))
            directory += File.separator;
        return directory + fileWeWishToEnter;
    }
    public void afterCreateNewFile(){}
}