package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;
import state.*;
import javax.swing.JOptionPane;
import java.io.File;

public class OpenFileButtonRightClickMenu extends PopupMenu<Object> implements StateSaver.Closeable
{
    public static OpenFileButtonRightClickMenu it;
    protected Gui gui;
    protected ArrayList<FlatButton> shortcuts = new ArrayList<>();
    protected FlatButton addNewShortcut;
    public OpenFileButtonRightClickMenu(Gui gui)
    {
        init2(gui);
    }
    public void init2(Gui gui)
    {
        this.gui = gui;
        setDimensions(260, 100);
        setPosition(20, 99);
        otherInit();
        loadPreviousState();
        initAsCloseable();
    }
    public void initAsCloseable()
    {
        StateSaver.it.addCloseable(this);
    }
    public void otherInit()
    {
        add(addNewShortcut = new FlatButton(0,0,0,0, "Add new shortcut", Background.LIGHT_GRAY_BACKGROUND)
        {
            public void action()
            {
                String res = JOptionPane.showInputDialog(null, "Enter path name: ");
                if(res == null) return;
                File test = new File(res);
                if(!test.exists())
                {
                    JOptionPane.showMessageDialog(null, "Directory " + res + " doesn't exist.");
                    return;
                }
                if(!test.isDirectory())
                {
                    JOptionPane.showMessageDialog(null, res + " isn't a directory.");
                    return;
                }
                addShortcut(res);
                OpenFileButtonRightClickMenu.this.deactivate();
            }
            
        });
    }
    public void addShortcut(String shortcut)
    {
        remove(addNewShortcut);
        for(FlatButton f : shortcuts)
        {
            remove(f);
        }
        shortcuts.add(0, createShortcut(shortcut));
        for(FlatButton f : shortcuts)
        {
            add(f);
        }
        add(addNewShortcut);
    }
    public void removeShortcut(String shortcut)
    {
        remove(addNewShortcut);
        for(FlatButton f : shortcuts)
        {
            remove(f);
        }
        FlatButton toRemove = null;
        for(FlatButton f : shortcuts)
        {
            if(f instanceof ShortcutButton && ((ShortcutButton)f).getFullPath().equals(shortcut))
            {
                toRemove = f;
                f.deactivate();
            }
        }
        shortcuts.remove(toRemove);
        
        for(FlatButton f : shortcuts)
        {
            add(f);
        }
        add(addNewShortcut);
    }
    
    /*
    This method only creates, it doesn't add
    */
    public ShortcutButton createShortcut(String shortcut)
    {
        return new ShortcutButton(0,0,0,0, shortcut, Background.LIGHT_GRAY_BACKGROUND, this, gui);
    }
    public static class ShortcutButton extends FlatButton
    {
        protected Gui gui;
        protected String fullPath;
        protected OpenFileButtonRightClickMenu container;
        public ShortcutButton(int x, int y, int w, int h, String fullPath, Background b, OpenFileButtonRightClickMenu container, Gui gui)
        {
            super(x, y, w, h, new File(fullPath).getName(), b);
            initShortcutButton(fullPath, container, gui);
        }
        public void initShortcutButton(String fullPath, OpenFileButtonRightClickMenu container, Gui gui)
        {
            this.fullPath = fullPath;
            this.container = container;
            this.gui = gui;
        }
        public String getFullPath()
        {
            return fullPath;
        }
        public void action()
        {
            ((BrowseState)gui.getGuiStateManager().states().get("browseState")).getFileBrowser().browse(fullPath);
            container.deactivate();
        }
        public void rightClick()
        {
            int resp = JOptionPane.showConfirmDialog(null, "Are you sure you want to remove this shortcut?");
            if(resp == JOptionPane.YES_OPTION)
            {
                container.removeShortcut(getFullPath());
                
                container.deactivate();
            }
        }
    }
    
    
    
    
    public void loadPreviousState()
    {
        try
        {
            ArrayList<String> loaded = StateSaver.it.load("OpenFileButtonRightClickMenu");
            if(loaded == null || loaded.get(0).equals("*null")) 
                return;
            else
            {
                for(String pathName : loaded)
                {
                    addShortcut(pathName);
                }
            }
                
        }
        catch(Exception e)
        {
            //JOptionPane.showMessageDialog("Could not load previous hotkey file.");
        }
    }
    public void closeProgram()
    {
        ArrayList<Object> shortcutsObjects = arrayList();
        for(FlatButton shortcut : shortcuts)
        {
            if(shortcut instanceof ShortcutButton)
                shortcutsObjects.add(((ShortcutButton)shortcut).getFullPath());
        }
        StateSaver.it.save("OpenFileButtonRightClickMenu", shortcutsObjects);
    }
}






