/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui;

import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import ljs.gui.Component;
import java.awt.Canvas;
import java.awt.Graphics;

/**
 *
 * @author peter_000
 */
public class Picture extends Component
{
	private Canvas myCanvas;
	private Image img;
    public Picture(Image img)
    {
        super(new Canvas()
		{
			public void paint(Graphics g)
			{
				g.drawImage(img,0,0,getWidth(),getHeight(),null);
			}
		});
		this.img = img;
		myCanvas = (Canvas)super.getJavaComponent();
		myCanvas.repaint();
    }
    public Picture(Color c)
    {
        this(image(c));
    }
	
	public static BufferedImage image(Color c)
	{
		BufferedImage bi = new BufferedImage(1,1,BufferedImage.TYPE_INT_ARGB);
		bi.setRGB(0,0,c.getRGB());
		return bi;
	}
}
