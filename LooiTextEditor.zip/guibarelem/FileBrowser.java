package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;
import java.io.File;
import state.*;

public class FileBrowser extends ScrollBoxList
{
    //INTERFACE
    public void set(double x, double y, double width, double height, Background back)
    {
        setDimensions(width, height);
        setPosition(x, y);
        setBackground(back);
        getScrollBar().setPosition(getX() + getWidth() - getScrollBar().getWidth(), getScrollBar().getY());
        updateFileBrowserRightClickButton();
    }
    public void openDir(String dir){_openDir(dir);}
    
    
    /*input a starting location and a FileAction. The 
    gui bar mode will automatically switch to FileBrowser mode,
    and then the first file that the user selects will be
    passed into the FileAction postAction and that will
    be executed
    */public static interface FileAction{public void act(File f);}
    public void browse(String startFileLocationCanBeNull){_browse(startFileLocationCanBeNull);}
    
    
    
    public String getCurrentPath(){return currentPath;}
    public BrowsingFileButtonPopup getBrowsingFileButtonPopup(){return bfbp;}
    
    //END INTERFACE
    
    protected Gui gui;
    protected String currentPath;
    protected ArrayList<BrowsingFileButton> bfbs = arrayList();
    protected FileBrowserRightClickButton backgroundRightClickBtn;
    protected BrowsingFileButtonPopup bfbp;
    
    
    public FileBrowser(Gui gui)
    {
        super(0, 0, 100, 100, Background.WHITE_BACKGROUND);
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        setMouseWheelScrollingCoefficient(DEFAULT_MOUSE_WHEEL_SCROLLING_COEFFICIENT*3);
        initScrollBar();
        currentPath = getDefaultDirectory();
        miscInit();
        initFileBrowserRightClickButton();
        updateFileBrowserRightClickButton();
        bfbp = new BrowsingFileButtonPopup(gui, this);
        
    }
    public void add(GuiComponent g)
    {
        g.setLayer(getLayer()-20);
        super.add(g);
    }
    public void initFileBrowserRightClickButton()
    {
        addStationary(backgroundRightClickBtn = new FileBrowserRightClickButton(gui, getBackground()));
    }
    public void updateFileBrowserRightClickButton()
    {
        FileBrowserRightClickButton a = backgroundRightClickBtn;
        a.set(getX(), getY(), getWidth(), getHeight());
        a.setLayer(getLayer() - .001);
        
    }
    public void setBackground(Background b)
    {
        super.setBackground(b);
        backgroundRightClickBtn.setBackground(getBackground());
    }
    public void miscInit()
    {
        setSpacingBetweenItems(0);
    }
    public void initScrollBar()
    {
        getScrollBar().setDimensions(20, getScrollBar().getHeight());
    }
    
    /*
    This method basically just makes the program go back to fileSelectionState
    */
    public void fulfillBrowsePromise(File f)
    {
        gui.getGuiStateManager().setState("fileSelectionState");
        ((FileSelectionState)gui.getGuiStateManager().states().get("fileSelectionState")).getFileTabHolder().open(f);
        FileButton fb = ((FileSelectionState)gui.getGuiStateManager().states().get("fileSelectionState")).getFileTabHolder().getFileButton(f);
        
        if(fb != null)
            fb.action();
    }
    public void looiStep()
    {
        checkSelected();
        super.looiStep();
        updateDimensions();
    }
    public void checkSelected()
    {
        if(touchingMouse())
        {
            select();
        }
        else
        {
            deselect();
        }
    }
    public void updateDimensions()
    {
        setDimensions(getWidth(), getInternalHeight() - getY() - 30);
        
        updateFileBrowserRightClickButton();
    }
    protected void _openDir(String dir)
    {
        //System.out.println("Opening " + dir);
        //new Exception().printStackTrace();
        deleteAllBrowsingFileButtons();
        File f = new File(dir);
        if(!f.isDirectory())
        {
            return;
        }
        currentPath = dir;
        File[] files = f.listFiles();
        if(files != null)
            for(File file : files)
            {
                BrowsingFileButton correspondingButton = new BrowsingFileButton(gui, getNewBrowsingFileButtonBackground(file), file, bfbs, this); 
                initBrowsingFileButton(correspondingButton);
                bfbs.add(correspondingButton);
                add(correspondingButton);
            }
    }
    public Background getNewBrowsingFileButtonBackground(File f)
    {
        if(f.isDirectory())
        {
            return new Background(new Color(255, 255, 150));
        }
        else
        {
            return Background.LIGHT_BLUE_BACKGROUND;
        }
    }
    public void initBrowsingFileButton(BrowsingFileButton b)
    {
        b.set(0, 0, getWidth() - getLeftMargin() * 2 - getScrollBar().getWidth(), 30);
        
    }
    @SuppressWarnings("unchecked")
    public void deleteAllBrowsingFileButtons()
    {
        //System.out.println("deleting " + bfbs.size() + " buttons");
        for(BrowsingFileButton b : (ArrayList<BrowsingFileButton>)bfbs.clone())
        {
            b.delete();
        }
    }
    protected void _browse(String start)
    {
        gui.getGuiStateManager().setState("browseState");
        if(start == null)
        {
            start = getDefaultDirectory();
        }
        openDir(start);
    }
    public String getDefaultDirectory()
    {
        return File.listRoots()[0].getAbsolutePath();
    }
    public void deactivate()
    {
        super.deactivate();
        deleteAllBrowsingFileButtons();
    }
}