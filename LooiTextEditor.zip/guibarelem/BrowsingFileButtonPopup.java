package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;
import java.io.File;
import javax.swing.JOptionPane;
import state.*;
public class BrowsingFileButtonPopup extends PopupMenu<BrowsingFileButton>
{
    protected FileBrowser fb;
    protected Gui gui;
    public BrowsingFileButtonPopup(Gui gui, FileBrowser fb)
    {
        initBFBP(gui, fb);
    }
    public void initBFBP(Gui gui, FileBrowser fb)
    {
        this.fb = fb;
        this.gui = gui;
        
        
        
        setDimensions(260, 100);
        setPosition(20, 0);
        add(new FlatButton(0, 0, 0, 0, "View full name", Background.LIGHT_GRAY_BACKGROUND)
        {
            public void action()
            {
                JOptionPane.showMessageDialog(null, getCurrentData().getMyFile().getAbsolutePath());
                BrowsingFileButtonPopup.this.deactivate();
                
            }
        });
        add(new FlatButton(0, 0, 0, 0, "Open and stay", Background.LIGHT_GRAY_BACKGROUND)
        {
            public void action()
            {
                if(getCurrentData().getMyFile().isDirectory())
                {
                    JOptionPane.showMessageDialog(null, "Cannot open a directory.");
                }
                else
                {
                    ((FileSelectionState)gui.getGuiStateManager().states().get("fileSelectionState")).getFileTabHolder().open(getCurrentData().getMyFile());
                }
                
                BrowsingFileButtonPopup.this.deactivate();
                
            }
        });
        add(new FlatButton(0, 0, 0, 0, "Rename", Background.LIGHT_GRAY_BACKGROUND)
        {
            public void action()
            {
                String newName = JOptionPane.showInputDialog(null, "Enter new name: ");
                if(newName == null)
                {
                    BrowsingFileButtonPopup.this.deactivate();
                    return;
                }
                File currentFile = getCurrentData().getMyFile();
                boolean success = currentFile.renameTo(new File(removeLastPathElement(currentFile.getAbsolutePath()) + File.separator + newName));
                if(!success)
                {
                    JOptionPane.showMessageDialog(null, "Rename file was unsuccessful.");
                }
                BrowsingFileButtonPopup.this.deactivate();
                refresh();
            }
        });
        add(new FlatButton(0, 0, 0, 0, "Delete", Background.LIGHT_GRAY_BACKGROUND)
        {
            public void action()
            {
                int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete " + getCurrentData().getMyFile().getName() + "?");
                if(result == JOptionPane.YES_OPTION)
                {
                    boolean success = getCurrentData().getMyFile().delete();
                    if(!success)
                    {
                        JOptionPane.showMessageDialog(null, "Deletion was unsuccessful.");
                        BrowsingFileButtonPopup.this.deactivate();
                        return;
                    }
                    else
                    {
                        BrowsingFileButtonPopup.this.deactivate();
                        refresh();
                        return;
                    }
                }
                BrowsingFileButtonPopup.this.deactivate();
                
                
            }
        });
    }
    public void refresh()
    {
        fb.openDir(fb.getCurrentPath());
    }
    public static String removeLastPathElement(String path)
    {
        try
        {
            if(path.endsWith(File.separator))
            {
                path = path.substring(0, path.length()-File.separator.length());
            }
            path = path.substring(0, path.lastIndexOf(File.separator));
            return path;
        }
        catch(Exception e)
        {
            return path;
        }
    }
}