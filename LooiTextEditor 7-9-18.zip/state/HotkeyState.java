package state;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.util.HashMap;
import guibarelem.*;
import java.awt.Color;

public class HotkeyState implements GuiState
{
    protected Gui gui;
    protected ReturnButton returnButton;
    protected HotkeyFileBrowser hotkeyFileBrowser;
    
    
    public HotkeyState(Gui gui)
    {
        initHotkeyState(gui);
    }
    public void initHotkeyState(Gui gui)
    {
        this.gui = gui;
        returnButton = new ReturnButton(gui);
        hotkeyFileBrowser = new HotkeyFileBrowser(gui);
    }
    public void open(Gui gui, String previousStateName)
    {
        returnButton.activate();
        hotkeyFileBrowser.activate();
        hotkeyFileBrowser.openDir(HotkeyFileBrowser.defaultPath);
    }
    public void close(Gui gui, String nextStateName)
    {
        returnButton.deactivate();
        hotkeyFileBrowser.deactivate();
    }
}