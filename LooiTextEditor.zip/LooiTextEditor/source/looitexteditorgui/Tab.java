package looitexteditorgui;
import static ljs.Obj.*;

public interface Tab
{
	double getVirtualX();
	void setVirtualX(double d);
	double getWidth();
	String savableString();//returns null if not savable
	String getText(); //button text
	void update(double viewX, double viewY);
	void undo();
	void redo();
	
}