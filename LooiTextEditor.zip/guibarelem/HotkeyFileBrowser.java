package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;
import java.io.File;
import state.*;

public class HotkeyFileBrowser extends FileBrowser
{
    public static String defaultPath = "." + File.separator + "HotkeyFiles";
    protected Gui gui;
    
    
    public HotkeyFileBrowser(Gui gui)
    {
        super(gui);
        initHotkeyFileBrowser(gui);
    }
    public void initHotkeyFileBrowser(Gui gui)
    {
        this.gui = gui;
        set(10, 150, 280, 550, Background.DARK_GRAY_BACKGROUND);
    }
    
    public void fulfillBrowsePromise(File f)
    {
        //p("fulfillBrowsePromise: " + f.getAbsolutePath() + " from HotkeyFileBrowser");
        gui.getTextBoxModifier().getKeyActions().acceptHotkeyFile(f.getAbsolutePath());
    }
    public void initFileBrowserRightClickButton()
    {
        addStationary(backgroundRightClickBtn = new FileBrowserRightClickButton(gui, getBackground())
        {
            public void rightClick()
            {
                menu.activateOpen(HotkeyFileBrowser.this);
            }
        });
    }
    protected void _browse(String start)
    {
        if(start == null)
        {
            start = getDefaultDirectory();
        }
        openDir(start);
    }
}