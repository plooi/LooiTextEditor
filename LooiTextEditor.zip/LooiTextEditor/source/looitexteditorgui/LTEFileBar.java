package looitexteditorgui;
import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import java.awt.Color;
import java.util.ArrayList;
import java.lang.InterruptedException;
import java.io.File;


public class LTEFileBar extends LooiCanvas
{
	private int fileBarOffset;
	private Gui gui;
	private double fileTabHeight = 50;
	private double fileButtonCloseButtonWidth = 30;
	private double fileButtonCloseButtonExtraSpaceFromFileButtonText = 10;
	private ArrayList<Tab> tabs = new ArrayList<>();
	private double scrollX = 0,minScrollX = 0,maxScrollX = 0;
	private double fileButtonMargin = 15;
	private ScrollManager sm;
	private long millisecondWait = 500;
	private Thread rebalanceThread;
	private boolean running = true;
	private static final String lastOpenFilesFile = "last_open_files.txt";
	private LooiObject background;
	private Color backgroundColor = Color.WHITE;
	public LTEFileBar(int fileBarOffset, Gui gui)
	{
		this.fileBarOffset = fileBarOffset;
		this.gui = gui;
		setBounds(()->0,()->gui.getMainWindow().getHeight()-fileBarOffset,()->10000,()->fileBarOffset);
		setInternalWidth(10000);
		setInternalHeight(fileBarOffset);
		sm = new ScrollManager(this);
		rebalanceThread = new Thread(()->
		{
			while(running)
			{
				rebalance();
				try{Thread.sleep(millisecondWait);}catch(InterruptedException e){}
			}
			
		});
		rebalanceThread.start();
		new LooiObject()
		{
			int stage = 0;
			public void looiStep()
			{
				if(stage >= 2)
				{
					addLastOpenFiles();
					deactivate();
				}
				stage++;
			}
		};
		background = new LooiObject()
		{
			{
				setLayer(99);
			}
			protected void looiPaint()
			{
				setColor(backgroundColor);
				fillRect(0,0,getInternalWidth(),getInternalHeight());
			}
		};
	}
	public void addLastOpenFiles()
	{
		File theLastOpenFilesFile = new File(lastOpenFilesFile);
		if(theLastOpenFilesFile.exists())
		{
			String[] filesToOpen = loadText(lastOpenFilesFile);
			for(String file : filesToOpen)
			{
				addTab(newTab(file));
			}
			
		}
	}
	public double getFileTabHeight(){return fileTabHeight;}
	public double getFileButtonCloseButtonWidth(){return fileButtonCloseButtonWidth;}
	public ArrayList<Tab> getTabs(){return tabs;}
	public double getFileButtonCloseButtonExtraSpaceFromFileButtonText(){return fileButtonCloseButtonExtraSpaceFromFileButtonText;}
	public double getScrollX(){return scrollX;}
	public void setScrollX(double d){scrollX = d;}
	public void incScrollX(double inc){scrollX+=inc;}
	public double getMaxScrollX(){return maxScrollX;}
	public double getMinScrollX(){return minScrollX;}
	public double getFileButtonMargin(){return fileButtonMargin;}
	public void setFileButtonMargin(double d){fileButtonMargin = d;}
	public RunTab newRunTab(String name, Process p)
	{
		return new RunTab(gui,name,fileTabHeight,fileBarOffset,fileButtonCloseButtonWidth,p);
	}
	public RunTab viewNewRunTab(String name, Process p)
	{
		RunTab rt;
		addTab(rt = newRunTab(name,p));
		rt.view();
		return rt;
	}
	public FileTab newTab(String path)
	{
		return new FileTab(gui,path,fileTabHeight,fileBarOffset,fileButtonCloseButtonWidth);
	}
	public FileTab viewNewTab(String path)
	{
		FileTab ft;
		addTab(ft = newTab(path));
		ft.view();
		return ft;
	}
	public void addTab(Tab ft)
	{
		tabs.add(ft);
		rebalance();
		saveOpenTabs();
	}
	public void removeTab(Tab ft)
	{
		tabs.remove(ft);
		rebalance();
		saveOpenTabs();
	}
	public void saveOpenTabs()
	{
		ArrayList<String> toSaveAl = new ArrayList<>();
		for(int i : range(tabs))
		{
			if(tabs.get(i).savableString() != null)
			{
				toSaveAl.add(tabs.get(i).savableString());
			}
		}
		String[] toSave = toStringArray(toSaveAl);
		saveText(lastOpenFilesFile,toSave);
	}
	public synchronized void rebalance()
	{
		double x = 0;
		for(int i : range(tabs))
		{
			if(i == 0)
			{
				tabs.get(0).setVirtualX(fileButtonMargin);
				x = tabs.get(0).getVirtualX() + tabs.get(0).getWidth() + fileButtonMargin;
			}
			else
			{
				tabs.get(i).setVirtualX(x);
				x = tabs.get(i).getVirtualX() + tabs.get(i).getWidth() + fileButtonMargin;
			}
		}
		double newMaxXScroll = x - gui.getMainWindow().getWidth();
		if(newMaxXScroll < 0)
			newMaxXScroll = 0;
		maxScrollX = newMaxXScroll;
		
	}
	public void setBackgroundColor(Color c){backgroundColor = c;}
}