package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.lang.Process;
import java.lang.Runtime;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.lang.StringBuilder;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import guibarelem.*;
import java.io.File;

/*
Define the actions of every key
*/
public class KeyActions implements StateSaver.Closeable
{
    //INTERFACE
    public static final int DEAD_TIILDE = 192;
    public static final int 
                                                                                NORMAL = 0,
                                                                                CONTROL = 1,
                                                                                SHIFT = 2,
                                                                                CONTROL_SHIFT = 3,
                                                                                ALT = 4;//SHIFT_CO
    
    protected boolean capsLock = false;
    protected int lastIndexOverFromNewLine = -1;
    protected String tab = "    ";
    
    //This is what you call when there is a key event.
    //You can even call this method when you make your own FAKE key events!
    public void execute(KeyEventInterface k, int mode, boolean tf_PressRelease)
    {
        //p("EXE");
        //p("VK DEAD TILDE = " + KeyEvent.VK_DEAD_TILDE + " this is " + k.getKeyCode());
        preExecutionDuties(true, k.getKeyCode());
        KeyAction ka = keyActions.get(k.getKeyCode());
        if(ka != null)
            ka.eventAction(k, mode, tf_PressRelease);
    }
    
    //This is what you call when there is a mouse event.
    //You can even call this method when you make your own FAKE mouse events!
    public void execute(MouseEventInterface m, int mode, boolean tf_PressRelease)
    {
        preExecutionDuties(true, m.getButton());
        MouseAction ma = mouseActions.get(m.getButton());
        if(ma != null)
            ma.eventAction(m, mode, tf_PressRelease);
    }
    
    public void acceptHotkeyFile(String filename)
    {
        _acceptHotkeyFile(filename);
    }
    //END INTERFACE
    
    protected HashMap<Integer, KeyAction> keyActions = new HashMap<>();//key code : key action
    public static interface KeyAction{ void eventAction(KeyEventInterface k, int mode, boolean tf_PressRelease); }
    
    protected HashMap<Integer, MouseAction> mouseActions = new HashMap<>();//mouse event button : mouse action
    public static interface MouseAction{ void eventAction(MouseEventInterface m, int mode, boolean tf_PressRelease); }
    
    protected HashMap<Character, String> controlGroups = new HashMap<>();
    
    protected HashMap<Character, String> resetControlGroups = new HashMap<>();//these are the control groups that you get when you reset
    
    protected HashMap<Character, Command> commands = new HashMap<>();
    public static interface Command{void doIt();}
    
    protected HashMap<String, Command> allPossibleCommands = new HashMap<>();
    
    protected Gui gui;
    protected TextBoxModifier tbm;
    protected TextBoxMethods methods;
    protected String currentHotkeyFileName;
    
    public KeyActions(Gui gui, TextBoxModifier tbm, TextBoxMethods methods)
    {
        init(gui, tbm, methods);
    }
    public void init(Gui gui, TextBoxModifier tbm, TextBoxMethods methods)
    {
        this.gui = gui;
        this.tbm = tbm;
        this.methods = methods;
        addMeToStateSaver();
        createKeyActions();
        createMouseActions();
        initAllPossibleCommands();
        loadPreviousState();
    }
    public void addMeToStateSaver()
    {
        StateSaver.it.addCloseable(this);
    }
    public void closeProgram()
    {
        String toSave;
        //p("currentHotkeyFileName = " + currentHotkeyFileName);
        if(currentHotkeyFileName != null)
            StateSaver.it.save("KeyActions", arrayList(currentHotkeyFileName));
        else
            StateSaver.it.save("KeyActions", arrayList("*null"));
    }
    public void preExecutionDuties(boolean tf_KeyMouse, int theCode)
    {
        capsLock = Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK);
        
        if(tf_KeyMouse == true && (theCode == KeyEvent.VK_UP || theCode == KeyEvent.VK_DOWN))//this is so that if you hit anything but up or down, the lastIndexOverFromNewLine gets cleared
        {
            //okay
        }
        else
        {
            lastIndexOverFromNewLine = -1;
        }
    }
    public void loadPreviousState()
    {
        try
        {
            ArrayList<String> loaded = StateSaver.it.load("KeyActions");
            if(loaded == null || loaded.get(0).equals("*null")) 
                return;
            else
                acceptHotkeyFile(loaded.get(0));
        }
        catch(Exception e)
        {
            //JOptionPane.showMessageDialog("Could not load previous hotkey file.");
        }
    }
    public void createKeyActions()
    {
        
        for(int i = 65; i <= 90; i++)//key presses
        {
            char keyChar = (char)i;
            char lowerCaseKeyChar = (char)(i + 32);
            keyActions.put(i, (k, m, p)-> //KeyEvent k, int m(mode), boolean b(tf_PressRelease)
            {
                if(p)//if pressed
                {
                    if(m == SHIFT)
                    {
                        methods.type(keyChar + "");
                        methods.refresh();
                    }
                    else if(m == NORMAL)
                    {
                        methods.type(lowerCaseKeyChar + "");
                        methods.refresh();
                    }
                    else if(m == ALT)//use control group
                    {
                        useControlGroup(lowerCaseKeyChar);
                    }
                    else if(m == CONTROL)//use command
                    {
                        useCommand(lowerCaseKeyChar);
                    }
                    else if(m == CONTROL_SHIFT)//set control group
                    {
                        setControlGroup(lowerCaseKeyChar);
                        
                        
                    }
                }
            });
        }
        
        HashMap<Integer, Character> keyCodeToChar = keyCodeToChar();
        HashMap<Integer, Character> keyCodeToShiftChar = keyCodeToShiftChar();
        for(int keyCode : keyCodeToChar.keySet())
        {
            int theKeyCode = keyCode;
            char noShift = keyCodeToChar.get(theKeyCode);
            char yesShift = keyCodeToShiftChar.get(theKeyCode);
            
            keyActions.put(keyCode, (k, m, p)->
            {
                if(p)//if pressed
                {
                    //p("Key event");
                    if(m == SHIFT)
                    {
                        methods.type(yesShift + "");
                        methods.refresh();
                    }
                    else if(m == NORMAL)
                    {
                        methods.type(noShift + "");
                        methods.refresh();
                    }
                    else if(noShift >= 48 && noShift <= 57)//is a number [0-9] key, not { or \ or / or -
                    {
                        if(m == ALT)//use control group
                        {
                            useControlGroup(noShift);
                        }
                        else if(m == CONTROL)//use command
                        {
                            useCommand(noShift);
                        }
                        else if(m == CONTROL_SHIFT)
                        {
                            setControlGroup(noShift);
                        }
                    }
                }
                
            });
        }
        keyActions.put(KeyEvent.VK_SPACE, (k, m, p)->
        {
            if(p && (m == NORMAL || m == CONTROL || m == SHIFT))
            {
                methods.type(" ");
                methods.refresh();
            }
        });
        keyActions.put(KeyEvent.VK_BACK_SPACE, (k, m, p)->
        {
            if(p && (m == NORMAL || m == SHIFT))
            {
                if(methods.getSelectionStart() != methods.getSelectionEnd())//there is a selection
                {
                    int oldSelectionStart = methods.getSelectionStart();
                    methods.del(methods.getSelectionStart(), methods.getSelectionEnd());
                    methods.setCaretPosition(oldSelectionStart);
                    methods.refresh();
                }
                else//just delete back one
                {
                    if(methods.getCaretPosition() > 0)
                    {
                        int oldCaretPosition = methods.getCaretPosition();
                        methods.del(methods.getCaretPosition() - 1, methods.getCaretPosition());
                        methods.setCaretPosition(oldCaretPosition - 1);
                        methods.refresh();
                    }
                }
            }
            if(p && (m == CONTROL))
            {
                if(methods.getSelectionStart() != methods.getSelectionEnd())//there is a selection
                {
                    int oldSelectionStart = methods.getSelectionStart();
                    methods.del(methods.getSelectionStart(), methods.getSelectionEnd());
                    methods.setCaretPosition(oldSelectionStart);
                    methods.refresh();
                }
                else//just delete back one word
                {
                    if(methods.getCaretPosition() > 0)
                    {
                        int previousSpace = methods.previousSpace(methods.getCaretPosition() - 1, true);
                        int cl = methods.getCaretPosition();
                        if(previousSpace+1 == methods.getCaretPosition())
                        {
                            methods.del(cl-1, cl);
                            methods.setCaretPosition(cl-1);
                        }
                        else
                        {
                            methods.del(previousSpace+1, cl);
                            methods.setCaretPosition(previousSpace + 1);
                        }
                        
                        methods.refresh();
                    }
                }
            }
        });
        keyActions.put(KeyEvent.VK_DELETE, (k, m, p)->
        {
            if(p && (m == NORMAL || m == SHIFT))
            {
                if(methods.getSelectionStart() != methods.getSelectionEnd())//there is a selection
                {
                    int oldSelectionStart = methods.getSelectionStart();
                    methods.del(methods.getSelectionStart(), methods.getSelectionEnd());
                    methods.setCaretPosition(oldSelectionStart);
                    methods.refresh();
                }
                else//just delete up one
                {
                    if(methods.getCaretPosition() < methods.getTextLength())
                    {
                        methods.del(methods.getCaretPosition(), methods.getCaretPosition() + 1);
                        methods.refresh();
                    }
                }
            }
            if(p && (m == CONTROL))
            {
                if(methods.getSelectionStart() != methods.getSelectionEnd())//there is a selection
                {
                    int oldSelectionStart = methods.getSelectionStart();
                    methods.del(methods.getSelectionStart(), methods.getSelectionEnd());
                    methods.setCaretPosition(oldSelectionStart);
                    methods.refresh();
                }
                else//just delete back one word
                {
                    if(methods.getCaretPosition() < methods.getTextLength())
                    {
                        int cl = methods.getCaretPosition();
                        int nextSpace = methods.nextSpace(cl, true);
                        if(nextSpace == cl)
                        {
                            if(cl != methods.getTextLength())
                                methods.del(methods.getCaretPosition(), methods.getCaretPosition() + 1);
                        }
                        else
                        {
                            methods.del(methods.getCaretPosition(), nextSpace);
                        }
                            
                        
                        methods.refresh();
                    }
                }
            }
        });
        keyActions.put(KeyEvent.VK_ENTER, (k, m, p)->
        {
            if(p)
            {
                if(m == NORMAL)
                {
                    int indent = methods.getIndent(methods.getCaretPosition());
                    int lastNewLine = methods.indexOfLastNewLine(methods.getCaretPosition());
                    int startOfIndentString = lastNewLine + 1;
                    String indentString;
                    if(indent > 0)
                        indentString = methods.substring(startOfIndentString, startOfIndentString + indent);
                    else
                        indentString = "";
                    indentString = indentString.replace("\r", "");
                    methods.type('\n' + indentString);
                    methods.refresh();
                }
                else if(m == SHIFT)
                {
                    methods.type("\n");
                    methods.refresh();
                }
                else if(m == CONTROL_SHIFT)
                {
                    execute(KeyEventInterface.NEW((char)0, KeyEvent.VK_ENTER), NORMAL, true);         //press enter
                    execute(KeyEventInterface.NEW((char)0, KeyEvent.VK_OPEN_BRACKET), SHIFT, true);   //press {
                    execute(KeyEventInterface.NEW((char)0, KeyEvent.VK_ENTER), NORMAL, true);         //press tab
                    execute(KeyEventInterface.NEW((char)0, KeyEvent.VK_TAB), NORMAL, true);           //you get the idea
                    execute(KeyEventInterface.NEW((char)0, KeyEvent.VK_ENTER), NORMAL, true);
                    execute(KeyEventInterface.NEW((char)0, KeyEvent.VK_TAB), SHIFT, true);
                    execute(KeyEventInterface.NEW((char)0, KeyEvent.VK_CLOSE_BRACKET), SHIFT, true);
                    execute(KeyEventInterface.NEW((char)0, KeyEvent.VK_UP), NORMAL, true);
                    execute(KeyEventInterface.NEW((char)0, KeyEvent.VK_END), NORMAL, true);
                }
            }
        });
        keyActions.put(KeyEvent.VK_TAB, (k, m, p)->
        {
            if(p)
            {
                if(methods.getSelectionStart() == methods.getSelectionEnd())
                {
                    if(m == NORMAL)
                    {
                        methods.type(tab);
                        methods.refresh();
                    }
                    else if(m == SHIFT)
                    {
                        if(methods.getCaretPosition() > tab.length())
                        {
                            
                            int start = methods.getCaretPosition() - tab.length();
                            int end = methods.getCaretPosition();
                            
                            String back = methods.substring(start, end);
                            if(back.equals(tab))
                            {
                                methods.del(start, end);
                                methods.setCaretPosition(start);
                                methods.refresh();
                            }
                        }
                    }
                }
                else
                {
                    if(m == NORMAL || m == SHIFT)
                    {
                        int ss = methods.getSelectionStart();
                        int se = methods.getSelectionEnd();
                        
                        int newSS = methods.indexOfLastNewLine(ss);
                        if(newSS == -1) newSS = 0;
                        
                        
                        String selection = methods.getText().substring(newSS, se);
                        
                        String selectionReplace = null;
                        if(m == NORMAL)
                        {
                            selectionReplace = selection.replace("\n", "\n"+tab);
                            if(newSS == 0)
                            {
                                selectionReplace = tab + selectionReplace;
                            }
                        }
                        else if(m == SHIFT)
                        {
                            selectionReplace = selection.replace("\n"+tab, "\n");
                            if(newSS == 0 && selectionReplace.startsWith(tab))
                            {
                                selectionReplace = selectionReplace.substring(tab.length());
                            }
                        }
                        
                        methods.replaceRange(newSS, se, selectionReplace);
                        methods.refresh();
                        
                        int newSE = se + selectionReplace.length() - selection.length();
                        if(newSS == 0)
                            methods.selectAsFarAsPossible(newSS, newSE);
                        else
                            methods.selectAsFarAsPossible(newSS+1, newSE);
                    }
                    
                    
                }
            }
        });
        keyActions.put(KeyEvent.VK_RIGHT, (k, m, p)->
        {
            if(p)
            {
                if(m == NORMAL)
                {
                    methods.setCaretPositionAsFarAsPossible(methods.getCaretPosition() + 1);
                }
                else if(m == SHIFT)
                {
                    methods.moveCaretPositionAsFarAsPossible(methods.getCaretPosition() + 1);
                }
                else if(m == CONTROL)
                {
                    methods.setCaretPositionAsFarAsPossible(methods.nextSpace(methods.getCaretPosition()+1, true));
                }
                else if(m == CONTROL_SHIFT)
                {
                    methods.moveCaretPositionAsFarAsPossible(methods.nextSpace(methods.getCaretPosition()+1, true));
                }
            }
        });
        keyActions.put(KeyEvent.VK_LEFT, (k, m, p)->
        {
            if(p)
            {
                if(m == NORMAL)
                {
                    methods.setCaretPositionAsFarAsPossible(methods.getCaretPosition() - 1);
                }
                else if(m == SHIFT)
                {
                    methods.moveCaretPositionAsFarAsPossible(methods.getCaretPosition() - 1);
                }
                else if(m == CONTROL)
                {
                    int i = methods.previousSpace(methods.getCaretPosition()-1, true);
                    if(i == -1) i = 0;
                    methods.setCaretPositionAsFarAsPossible(i);
                }
                else if(m == CONTROL_SHIFT)
                {
                    int i = methods.previousSpace(methods.getCaretPosition()-1, true);
                    if(i == -1) i = 0;
                    methods.moveCaretPositionAsFarAsPossible(i);
                }
            }
        });
        keyActions.put(KeyEvent.VK_UP, (k, m, p)->
        {
            if(p)
            {
                int indexOfLastNewLine = methods.indexOfLastNewLine(methods.getCaretPosition());//DONE
                int distanceToLastNewLine = lastIndexOverFromNewLine == -1? methods.getCaretPosition() - indexOfLastNewLine : lastIndexOverFromNewLine;
                lastIndexOverFromNewLine = distanceToLastNewLine;
                if(m == NORMAL)
                {
                    methods.setCaretPositionAsFarAsPossible(methods.upDownIndex(methods.getCaretPosition(), true, lastIndexOverFromNewLine));
                }
                else if(m == SHIFT)
                {
                    methods.moveCaretPositionAsFarAsPossible(methods.upDownIndex(methods.getCaretPosition(), true, lastIndexOverFromNewLine));
                }
                
                
                
            }
        });
        keyActions.put(KeyEvent.VK_DOWN, (k, m, p)->
        {
            if(p)
            {
                int indexOfLastNewLine = methods.indexOfLastNewLine(methods.getCaretPosition());//DONE
                int distanceToLastNewLine = lastIndexOverFromNewLine == -1? methods.getCaretPosition() - indexOfLastNewLine : lastIndexOverFromNewLine;
                lastIndexOverFromNewLine = distanceToLastNewLine;
                if(m == NORMAL)
                {
                    methods.setCaretPositionAsFarAsPossible(methods.upDownIndex(methods.getCaretPosition(), false, lastIndexOverFromNewLine));
                }
                else if(m == SHIFT)
                {
                    methods.moveCaretPositionAsFarAsPossible(methods.upDownIndex(methods.getCaretPosition(), false, lastIndexOverFromNewLine));
                }
            }
        });
        keyActions.put(KeyEvent.VK_END, (k, m, p)->
        {
            if(p)
            {
                int indexOfNextNewLine = methods.indexOfNextNewLine(methods.getCaretPosition());
                if(indexOfNextNewLine == -1)  indexOfNextNewLine = methods.getTextLength();
                if(m == NORMAL)
                {
                    methods.setCaretPositionAsFarAsPossible(indexOfNextNewLine);
                }
                else if(m == SHIFT)
                {
                    methods.moveCaretPositionAsFarAsPossible(indexOfNextNewLine);
                }
            }
        });
        keyActions.put(KeyEvent.VK_HOME, (k, m, p)->
        {
            if(p)
            {
                if(m == NORMAL)
                {
                    methods.setCaretPositionAsFarAsPossible(homeIndex(methods.getCaretPosition()));
                }
                else if(m == SHIFT)
                {
                    methods.moveCaretPositionAsFarAsPossible(homeIndex(methods.getCaretPosition()));
                }
            }
        });
        keyActions.put(KeyEvent.VK_PAGE_UP, (k, m, p)->
        {
            if(p)
            {    
                if(m == NORMAL || m == SHIFT)
                {
                    for(int i : range(15))//Basically what this does is it presses the "UP" arrow key 15 times. Simple!
                    {
                        execute(KeyEventInterface.NEW((char)0, KeyEvent.VK_UP), m, true);
                    }
                }
            }
        });
        keyActions.put(KeyEvent.VK_PAGE_DOWN, (k, m, p)->
        {
            if(p)
            {
                if(m == NORMAL || m == SHIFT)
                {
                    for(int i : range(15))//Basically what this does is it presses the "UP" arrow key 15 times. Simple!
                    {
                        execute(KeyEventInterface.NEW((char)0, KeyEvent.VK_DOWN), m, true);
                    }
                }
            }
        });
    }
    
    
    
    public int homeIndex(int index)
    {
        int lastNewLine = methods.indexOfLastNewLine(methods.getCaretPosition());
        int i = lastNewLine + 1;
        int textLength = methods.getTextLength();
        while(i < textLength)
        {
            if(!Character.isSpaceChar(methods.getText().charAt(i)))
                break;
            if(methods.getText().charAt(i) == '\n')    
                break;
            i++;
        }
        if(i != index)
            return i;
        else
            return lastNewLine+1;
    }
    
    public void createMouseActions()
    {
        
    }
    
    private HashMap<Integer, Character> keyCodeToChar()
    {
        HashMap<Integer, Character> map = new HashMap<>();
        map.put(KeyEvent.VK_1,'1');
        map.put(KeyEvent.VK_2,'2');
        map.put(KeyEvent.VK_3,'3');
        map.put(KeyEvent.VK_4,'4');
        map.put(KeyEvent.VK_5,'5');
        map.put(KeyEvent.VK_6,'6');
        map.put(KeyEvent.VK_7,'7');
        map.put(KeyEvent.VK_8,'8');
        map.put(KeyEvent.VK_9,'9');
        map.put(KeyEvent.VK_0,'0');
        map.put(DEAD_TIILDE,'`');
        map.put(KeyEvent.VK_MINUS,'-');
        map.put(KeyEvent.VK_EQUALS,'=');
        map.put(KeyEvent.VK_OPEN_BRACKET,'[');
        map.put(KeyEvent.VK_CLOSE_BRACKET,']');
        map.put(KeyEvent.VK_BACK_SLASH,'\\');
        map.put(KeyEvent.VK_SEMICOLON,';');
        map.put(KeyEvent.VK_QUOTE,'\'');
        map.put(KeyEvent.VK_COMMA,',');
        map.put(KeyEvent.VK_PERIOD,'.');
        map.put(KeyEvent.VK_SLASH,'/');
        return map;
    }
    private HashMap<Integer, Character> keyCodeToShiftChar()
    {
        HashMap<Integer, Character> map = new HashMap<>();
        map.put(KeyEvent.VK_1,'!');
        map.put(KeyEvent.VK_2,'@');
        map.put(KeyEvent.VK_3,'#');
        map.put(KeyEvent.VK_4,'$');
        map.put(KeyEvent.VK_5,'%');
        map.put(KeyEvent.VK_6,'^');
        map.put(KeyEvent.VK_7,'&');
        map.put(KeyEvent.VK_8,'*');
        map.put(KeyEvent.VK_9,'(');
        map.put(KeyEvent.VK_0,')');
        map.put(DEAD_TIILDE,'~');
        map.put(KeyEvent.VK_MINUS,'_');
        map.put(KeyEvent.VK_EQUALS,'+');
        map.put(KeyEvent.VK_OPEN_BRACKET,'{');
        map.put(KeyEvent.VK_CLOSE_BRACKET,'}');
        map.put(KeyEvent.VK_BACK_SLASH,'|');
        map.put(KeyEvent.VK_SEMICOLON,':');
        map.put(KeyEvent.VK_QUOTE,'"');
        map.put(KeyEvent.VK_COMMA,'<');
        map.put(KeyEvent.VK_PERIOD,'>');
        map.put(KeyEvent.VK_SLASH,'?');
        return map;
    }
    
    public void _acceptHotkeyFile(String filename)
    {
        //p("Accepting file: " + filename + " from keyActions");
        try
        {
            String[] lines = loadText(filename);
            int i;
            for(i = 0; i < lines.length; i++) if(lines[i].trim().startsWith("commands")) break;
            for(i = i; i < lines.length; i++) 
            {
                if(lines[i].trim().startsWith("end-commands")) break;
                if(lines[i].length() >= 3 && Character.isLetterOrDigit(lines[i].charAt(0)) && lines[i].charAt(1) == ' ')
                {
                    String commandName = lines[i].substring(2);
                    commands.put(Character.toLowerCase(lines[i].charAt(0)), allPossibleCommands.get(commandName));//allPossibleCommands.get(commandName) might be null, but yolo who cares, I already check for it later
                }
            }
            for(i = i; i < lines.length; i++) if(lines[i].trim().startsWith("defaults")) break;
            for(i = i; i < lines.length; i++) 
            {
                if(lines[i].trim().startsWith("end-defaults")) break;
                if(lines[i].length() >= 3 && Character.isLetterOrDigit(lines[i].charAt(0)) && lines[i].charAt(1) == ' ')
                {
                    String controlGroupText = lines[i].substring(2);
                    controlGroups.put(Character.toLowerCase(lines[i].charAt(0)), controlGroupText);
                    resetControlGroups.put(Character.toLowerCase(lines[i].charAt(0)), controlGroupText);
                }
            }
            currentHotkeyFileName = filename;
        }
        catch(Exception e)
        {
            hkFileErr(filename);
            return;
        }
        
    }
    public void hkFileErr(String filename)
    {
        showMessageDialog("Loading " + filename + " as a hotkey file did not succeed. This is likely due to a syntax error.");
    }
    public void setControlGroup(char theCharacter)
    {
        require(Character.isLowerCase(theCharacter) || Character.isDigit(theCharacter));
        
            
        String word;
        if(methods.getSelectionStart() != methods.getSelectionEnd())
            word = methods.getText().substring(methods.getSelectionStart(), methods.getSelectionEnd());
        else
            word = methods.getWordAt(methods.getCaretPosition());
            
            
        setControlGroup(theCharacter, word);
    }
    public void setControlGroup(char theCharacter, String text)
    {
        controlGroups.put(theCharacter, text);
    }
    public void resetControlGroup(char theCharacter)
    {
        require(Character.isLowerCase(theCharacter) || Character.isDigit(theCharacter));
        controlGroups.put(theCharacter, resetControlGroups.get(theCharacter));
    }
    public void useControlGroup(char theChar)
    {
        String controlGroupText = controlGroups.get(theChar);
        if(controlGroupText != null)
        {
            methods.type(controlGroupText);
            methods.refresh();
        }
    }
    public void useCommand(char c)
    {
        Command command = commands.get(c);
        if(command != null)
            command.doIt();
    }
    public static void showMessageDialog(String msg)
    {
        JOptionPane.showMessageDialog(null, msg);
        MyKeyListener.it.resetModifiers();
    }
    public static String showInputDialog(String message, String defaultInput)
    {
        String ret = JOptionPane.showInputDialog(null, message, defaultInput);
        MyKeyListener.it.resetModifiers();
        return ret;
    }
    public void initAllPossibleCommands()//TODO
    {
        allPossibleCommands.put("copy", this::copy);
        allPossibleCommands.put("paste", this::paste);
        allPossibleCommands.put("cut", this::cut);
        allPossibleCommands.put("undo", this::undo);
        allPossibleCommands.put("redo", this::redo);
        allPossibleCommands.put("selectWord", this::selectWord);
        allPossibleCommands.put("newBlock", this::newBlock);
        allPossibleCommands.put("newPythonBlock", this::newPythonBlock);
        allPossibleCommands.put("findNext", this::findNext);
        allPossibleCommands.put("findPrev", this::findPrev);
        allPossibleCommands.put("selectToNext", this::selectToNext);
        allPossibleCommands.put("selectToPrev", this::selectToPrev);
        allPossibleCommands.put("findNextThis", this::findNextThis);
        allPossibleCommands.put("findPrevThis", this::findPrevThis);
        allPossibleCommands.put("findAll", this::findAll);
        allPossibleCommands.put("findAllThis", this::findAllThis);
        allPossibleCommands.put("replaceAll", this::replaceAll);
        allPossibleCommands.put("displayControlGroups", this::displayControlGroups);
        allPossibleCommands.put("clearHighlights", this::clearHighlights);
        allPossibleCommands.put("runFile", this::runFile);
        allPossibleCommands.put("brackets", this::brackets);
        allPossibleCommands.put("parentheses", this::parentheses);
        allPossibleCommands.put("highlight", this::highlight);
        allPossibleCommands.put("insertFileName", this::insertFileName);
        allPossibleCommands.put("selectAll", this::selectAll);
        allPossibleCommands.put("getChangeLineNumber", this::getChangeLineNumber);
        allPossibleCommands.put("getNumLines", this::getNumLines);
        allPossibleCommands.put("resetControlGroup", this::resetControlGroup);
        allPossibleCommands.put("openLine", this::openLine);
        allPossibleCommands.put("toggleGuiBarSize", this::toggleGuiBarSize);
        allPossibleCommands.put("selectLine", this::selectLine);
        allPossibleCommands.put("quotes", this::quotes);
        allPossibleCommands.put("autofill", this::autofill);
        allPossibleCommands.put("deselect", this::deselect);
        allPossibleCommands.put("selectAutoFill", this::selectAutoFill);
    }
    ///////////////////////////Commands
    public void selectAll()
    {
        methods.selectAsFarAsPossible(0, methods.getTextLength());
    }
    public void copy(){methods.copy(); methods.refresh();}
    public void cut()
    {
        methods.copy(); 
        if(methods.getSelectionStart() != methods.getSelectionEnd())
            methods.replaceRange(methods.getSelectionStart(), methods.getSelectionEnd(), "");
        methods.refresh();
    }
    public void paste(){methods.paste(); methods.refresh();}
    public void undo()
    {
        int caret = methods.getCaretPosition();
        methods.undo(); 
        methods.refresh();
        methods.setCaretPositionAsFarAsPossible(caret);
    }
    public void redo()
    {
        int caret = methods.getCaretPosition();
        methods.redo(); 
        methods.refresh();
        methods.setCaretPositionAsFarAsPossible(caret);
    }
    public void selectWord()
    {
        //p("Next space: " + methods.nextSpace(methods.getCaretPosition(), true));
        //p("Prev space: " + methods.previousSpace(methods.getCaretPosition(), true));
        methods.selectAsFarAsPossible(methods.previousSpace(methods.getCaretPosition()-1, false)+1,methods.nextSpace(methods.getCaretPosition(), false));
        
    }
    public void newBlock()
    {
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_END), NORMAL, true);
        execute(KeyEventInterface.NEW('\n', KeyEvent.VK_ENTER), NORMAL, true);
        execute(KeyEventInterface.NEW('[', KeyEvent.VK_OPEN_BRACKET), SHIFT, true);
        execute(KeyEventInterface.NEW('\n', KeyEvent.VK_ENTER), NORMAL, true);
        execute(KeyEventInterface.NEW('\t', KeyEvent.VK_TAB), NORMAL, true);
        execute(KeyEventInterface.NEW('\n', KeyEvent.VK_ENTER), NORMAL, true);
        execute(KeyEventInterface.NEW('\t', KeyEvent.VK_TAB), SHIFT, true);
        execute(KeyEventInterface.NEW(']', KeyEvent.VK_CLOSE_BRACKET), SHIFT, true);
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_UP), NORMAL, true);
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_END), NORMAL, true);
    }
    public void newPythonBlock()
    {
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_END), NORMAL, true);
        execute(KeyEventInterface.NEW('\n', KeyEvent.VK_SEMICOLON), SHIFT, true);
        execute(KeyEventInterface.NEW('\n', KeyEvent.VK_ENTER), NORMAL, true);
        execute(KeyEventInterface.NEW('\t', KeyEvent.VK_TAB), NORMAL, true);
    }
    
    /*
    Input a string, find the next occurrence
    */
    public void findNext()
    {
        String defaultText = "";
        if(methods.getSelectionStart() != methods.getSelectionEnd())
        {
            defaultText = methods.getText().substring(methods.getSelectionStart(), methods.getSelectionEnd());
        }
        String target = showInputDialog("Enter phrase to search for:", defaultText);
        if(target == null)return;
        if(methods.getSelectionStart() != methods.getSelectionEnd())
            findNext(target, methods.getSelectionStart()+1);
        else
            findNext(target, methods.getCaretPosition()+1);
    }
    public void findPrev()
    {
        String defaultText = "";
        if(methods.getSelectionStart() != methods.getSelectionEnd())
        {
            defaultText = methods.getText().substring(methods.getSelectionStart(), methods.getSelectionEnd());
        }
        String target = showInputDialog("Enter phrase to search for:", defaultText);
        if(target == null)return;
        if(methods.getSelectionStart() != methods.getSelectionEnd())
            findPrev(target, methods.getSelectionStart()-1);
        else
            findPrev(target, methods.getCaretPosition()-1);
    }
    
    /*
    Select to the next occurrence of the
    string that you input in
    */
    public void selectToNext()
    {
        String target = showInputDialog("Enter phrase to select to:", "");
        if(target == null)return;
        if(methods.getSelectionStart() != methods.getSelectionEnd())
            selectToNext(target, methods.getSelectionStart()+1);
        else
            selectToNext(target, methods.getCaretPosition()+1);
    }
    public void selectToPrev()
    {
        String target = showInputDialog("Enter phrase to select to:", "");
        if(target == null)return;
        if(methods.getSelectionStart() != methods.getSelectionEnd())
            selectToPrev(target, methods.getSelectionStart()-1);
        else
            selectToPrev(target, methods.getCaretPosition()-1);
    }
    
    /*
    Find next of the selected string
    */
    public void findNextThis()
    {
        int start = methods.getSelectionStart();
        int end = methods.getSelectionEnd();
        
        if(start >= end)return;
        String target = methods.getText().substring(start, end);
        
        findNext(target, start+1);
    }
    public void findPrevThis()
    {
        int start = methods.getSelectionStart();
        int end = methods.getSelectionEnd();
        
        if(start >= end)return;
        String target = methods.getText().substring(start, end);
        
        findPrev(target, start-1);
    }
    public void findAll()
    {
        String target = showInputDialog("Enter phrase to search for:", "");
        if(target == null)return;
        String text = methods.getText();
        int i = 0;
        
        int textLen = text.length();
        
        while(true)
        {
            i = text.indexOf(target, i);
            if(i != -1) 
                methods.highlightAsFarAsPossible(i, i + target.length());
            else
                break;
            if(i >= textLen) break;
            
            i++;
        }
    }
    public void findAllThis()
    {
        if(methods.getSelectionStart() == methods.getSelectionEnd()) return;
        String text = methods.getText();
        String target = text.substring(methods.getSelectionStart(), methods.getSelectionEnd());
        int i = 0;
        
        int textLen = text.length();
        
        while(true)
        {
            i = text.indexOf(target, i);
            if(i != -1) 
                methods.highlightAsFarAsPossible(i, i + target.length());
            else
                break;
            if(i >= textLen) break;
            
            i++;
        }
    }
    public void replaceAll()
    {
        String target = showInputDialog("Enter phrase to search for:", "");
        String replace = showInputDialog("Enter phrase to replace with:", "");
        if(target == null || replace == null)return;
        String text = methods.getText();
        int ss = methods.getSelectionStart();
        int se = methods.getSelectionEnd();
        if(ss == se)
        {
            methods.setText(text.replace(target, replace));
        }
        else
        {
            String section = text.substring(ss, se);
            section = section.replace(target, replace);
            methods.replaceRange(ss, se, section);
        }
        methods.refresh();
    }
    
    
    public void findNext(String target, int searchStart)
    {
        int indexOfNext = methods.getText().indexOf(target, searchStart);
        if(indexOfNext == -1) {showMessageDialog( "No instances of " + target + " after this point." ); return;}
        methods.select(indexOfNext, indexOfNext + target.length());
    }
    public void findPrev(String target, int searchStart)
    {
        int indexOfPrev = methods.getText().lastIndexOf(target, searchStart);
        if(indexOfPrev == -1) {showMessageDialog("No instances of " + target + " before this point." ); return;}
        methods.select(indexOfPrev, indexOfPrev + target.length());
    }
    public void selectToNext(String target, int searchStart)
    {
        int indexOfNext = methods.getText().indexOf(target, searchStart);
        if(indexOfNext == -1) {showMessageDialog( "No instances of " + target + " after this point." ); return;}
        methods.moveCaretPositionAsFarAsPossible(indexOfNext + target.length());
    }
    public void selectToPrev(String target, int searchStart)
    {
        int indexOfPrev = methods.getText().lastIndexOf(target, searchStart);
        if(indexOfPrev == -1) {showMessageDialog("No instances of " + target + " before this point." ); return;}
        methods.moveCaretPositionAsFarAsPossible(indexOfPrev);
    }
    public void displayControlGroups()
    {
        StringBuilder sb = new StringBuilder();
        for(char key : controlGroups.keySet())
        {
            sb.append("Press alt-");
            sb.append(key);
            sb.append(" for \"");
            sb.append(controlGroups.get(key));
            sb.append("\"\n");
        }
        showMessageDialog(sb.toString());
    }
    public void clearHighlights()
    {
        methods.clearHighlights();
    }
    public void insertFileName()
    {
        File thisFile = FileSelectionState.it.getSelectedButton().getFile();
        methods.type(thisFile.getName());
        methods.refresh();
    }
    /*
    [fileNameWithoutExtension, fileExtension, pathUpToFile]
    */
    public ArrayList<String> getFileParts(File f)
    {
        ArrayList<String> ret = arrayList(null, null, null);
        String name = f.getName();
        int dotIndex = name.indexOf(".");
        if(dotIndex == -1)
        {
            ret.set(0, name);
            ret.set(1, "");
        }
        else
        {
            ret.set(0, name.substring(0, dotIndex));
            ret.set(1, name.substring(dotIndex + 1));
        }
        ret.set(2, UpDirectoryBtn.oneDirectoryUp(f.getAbsolutePath()));
        return ret;
    }
    public void runFile()
    {
        try
        {
            MyKeyListener.it.resetModifiers();
            File thisFile = FileSelectionState.it.getSelectedButton().getFile();
            ArrayList<String> fileParts = getFileParts(thisFile);
            
            String fileNameWithoutExtension = fileParts.get(0);
            String fileExtension = fileParts.get(1);
            String pathUpToFile = fileParts.get(2);
            String fileName = thisFile.getName();
            
            String os = System.getProperty("os.name");
            os = os.toLowerCase();
            if(os.contains("windows"))
            {
                
                if(fileExtension.equals("java"))
                {
                    Runtime.getRuntime().exec("cmd /c start cmd.exe /K \"cd " + pathUpToFile + " && javac " + fileName + " && java " + fileNameWithoutExtension + "\"");
                }
                else if(fileExtension.equals("py"))
                {
                    Runtime.getRuntime().exec("cmd /c start cmd.exe /K \"cd " + pathUpToFile + " && python " + fileName + "\"");
                }
                else if(fileExtension.equals("bat"))
                {
                    Runtime.getRuntime().exec("cmd /c start cmd.exe /K \"cd " + pathUpToFile + " && " + fileName + "\"");
                }
                else
                {
                    showMessageDialog("Cannot run " + fileName + " because its file extension is " + fileExtension + ".");
                }
            }
            
            else if(os.contains("linux") || os.contains("ubuntu") || os.contains("mac"))
            {
                showMessageDialog("I'm really sorry, I don't know how to run programs directly on " + os + ".");
            }
            else
            {
                showMessageDialog("I'm really sorry, " + os + " is not a supported operating system.");
            }
        }
        catch(Exception e)
        {
            showMessageDialog("Error occurred: " + e.toString());
            //e.printStackTrace();
        }
    }
    public void highlight()
    {
        methods.highlightAsFarAsPossible(methods.getSelectionStart(), methods.getSelectionEnd());
    }
    public void parentheses()
    {
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_9), SHIFT, true);
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_0), SHIFT, true);
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_LEFT), NORMAL, true);
    }
    public void brackets()
    {
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_OPEN_BRACKET), NORMAL, true);
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_CLOSE_BRACKET), NORMAL, true);
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_LEFT), NORMAL, true);
    }
    public void quotes()
    {
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_QUOTE), SHIFT, true);
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_QUOTE), SHIFT, true);
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_LEFT), NORMAL, true);
    }
    public void getChangeLineNumber()
    {
        String res = showInputDialog("Enter line number:", methods.getCursorLineNumber()+"");
        
        if(res == null) return;
        try
        {
            String text = methods.getText();
            int newLineNumber = Integer.parseInt(res);
            int lineNumber = 1;
            int i = 0;
            for(; i < text.length(); i++)
            {
                if(text.charAt(i) == '\n') lineNumber++;
                if(lineNumber >= newLineNumber) break;
            }
            
            methods.selectAsFarAsPossible(i+1, i+1);
        }
        catch(Exception e)
        {
            
        }
    }
    public void getNumLines()
    {
        showInputDialog("Number of lines in this file:", ""+methods.getNumLines());
    }
    public void resetControlGroup()
    {
        String hotkey = showInputDialog("Which hotkey do you want to reset?","");
        if(hotkey == null) return;
        if(hotkey.length() != 1)return;
        char hotkeyChar = hotkey.charAt(0);
        if(!Character.isLetterOrDigit(hotkeyChar)) return;
        hotkeyChar = Character.toLowerCase(hotkeyChar);
        resetControlGroup(hotkeyChar);
    }
    public void openLine()
    {
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_END), NORMAL, true);
        execute(KeyEventInterface.NEW('\0', KeyEvent.VK_ENTER), NORMAL, true);
        for(int i = 0; i < 2; i++)
            execute(KeyEventInterface.NEW('\0', KeyEvent.VK_HOME), NORMAL, true);
        
    }
    public void toggleGuiBarSize()
    {
        methods.toggleGuiBarSize();
    }
    public void selectLine()
    {
        int last = methods.indexOfLastNewLine(methods.getCaretPosition());
        int next = methods.indexOfNextNewLine(methods.getCaretPosition());
        if(next == -1)
        {
            next = methods.getText().length();
        }
        methods.selectAsFarAsPossible(last+1, next);
    }
    
    
    protected ArrayList<String> previousCandidates = arrayList();
    protected String lastSearchFor = "";
    protected int lastAutofillSearchStart = -1;
    protected int lastAutofillSearchEnd = -1;
    protected int lastCandidatesIndex = -1;
    
    public void selectAutoFill()
    {
        int searchEnd;//searchEnd is the backwards search for the start of the word
        if(methods.getSelectionStart() != methods.getSelectionEnd())
        {
            searchEnd = methods.getSelectionStart();
        }
        else
        {
            searchEnd = methods.getCaretPosition();
        }
        int searchStart = methods.previousSpace(searchEnd-1, false) + 1;//searchStart is the start of the search term to search for a term to complete the autofill
        
        if(searchStart == searchEnd)
        {
            return;
        }
        
        String searchFor = methods.getText().substring(searchStart, searchEnd);
        ArrayList<String> candidates = findCandidates(searchFor);
        String askString = "";
        for(int i = 0; i < candidates.size() && i < 5; i++)
        {
            askString += i + ": " + candidates.get(i) + "\n";
        }
        String response = showInputDialog(askString, "0");
        if(response == null)return;
        try
        {
            int index = Integer.parseInt(response);
            if(methods.getSelectionStart() != methods.getSelectionEnd()) methods.replaceRange(methods.getSelectionStart(), methods.getSelectionEnd(), "");
            methods.replaceRange(searchStart, searchEnd, candidates.get(index));
        }
        catch(Exception e){}
    }
    public void autofill()
    {
        int searchEnd;//searchEnd is the backwards search for the start of the word
        if(methods.getSelectionStart() != methods.getSelectionEnd())
        {
            searchEnd = methods.getSelectionStart();
        }
        else
        {
            searchEnd = methods.getCaretPosition();
        }
        int searchStart = methods.previousSpace(searchEnd-1, false) + 1;//searchStart is the start of the search term to search for a term to complete the autofill
        
        if(searchStart == searchEnd)
        {
            return;
        }
        
        String searchFor = methods.getText().substring(searchStart, searchEnd);
        
        if(previousCandidates.size() > lastCandidatesIndex+1 && searchFor.equals(lastSearchFor) && searchStart == lastAutofillSearchStart && searchEnd == lastAutofillSearchEnd && lastCandidatesIndex != -1)
        {
            //p(previousCandidates);
            if(methods.getSelectionStart() != methods.getSelectionEnd()) methods.replaceRange(methods.getSelectionStart(), methods.getSelectionEnd(), "");
            lastCandidatesIndex++;
            String toType = previousCandidates.get(lastCandidatesIndex);
            methods.replaceRange(searchStart, searchEnd, toType);
            methods.selectAsFarAsPossible(searchEnd, searchStart + toType.length());
            return;
            
        }
        lastAutofillSearchStart = searchStart;
        lastAutofillSearchEnd = searchEnd;
        lastCandidatesIndex = 0;
        lastSearchFor = searchFor;
        ArrayList<String> candidates = findCandidates(searchFor);
        previousCandidates = candidates;
        
        if(candidates.size() == 0)
        {
            lastCandidatesIndex = -1;
            return;
        }
        //p(previousCandidates);
        if(methods.getSelectionStart() != methods.getSelectionEnd()) methods.replaceRange(methods.getSelectionStart(), methods.getSelectionEnd(), "");
        String toType = candidates.get(0);
        methods.replaceRange(searchStart, searchEnd, toType);
        methods.selectAsFarAsPossible(searchEnd, searchStart + toType.length());
        return;
        
    }
    public ArrayList<String> findCandidates(String searchFor)
    {
        ArrayList<String> candidates = new ArrayList<>();int i = 0;
        while(i < methods.getTextLength())
        {
            int nextIndex = methods.getText().indexOf(searchFor, i);
            if(nextIndex == -1) break;
            int endOfOccurrence = methods.nextSpace(nextIndex, false);
            String candidate = methods.getText().substring(nextIndex, endOfOccurrence);
            char previousChar;
            if(nextIndex == 0)
            {
                previousChar = '\0';
            }
            else
            {
                previousChar = methods.getText().charAt(nextIndex-1);
            }
            if(!candidate.equals(searchFor)&& !candidates.contains(candidate) && (previousChar == '\0' || !Character.isLetterOrDigit(previousChar)))
            {
                candidates.add(candidate);
            }
            i = endOfOccurrence;
        }
        return candidates;
    }
    public void deselect()
    {
        methods.setCaretPosition(methods.getCaretPosition());
    }
        
    
}
