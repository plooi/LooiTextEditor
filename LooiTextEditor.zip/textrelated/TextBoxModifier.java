package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.util.ArrayList;

/*
Keep track of the special additions of the text box
*/
public class TextBoxModifier implements StateSaver.Closeable
{
    //INTERFACE
    public MyKeyListener getMyKeyListener(){return mkl;}
    public StyleManager getStyleManager(){return sm;}
    public TextBoxMethods getMethods(){return tbmethods;}
    public KeyActions getKeyActions(){return ka;}
    public int getFontSize(){return fontSize;}
    public void setFontSize(int i){fontSize = i;}
    //END INTERFACE
    
    protected Gui gui;
    protected MyTextBox textBox;
    protected MyKeyListener mkl;
    protected MyMouseListener mml;
    protected TextBoxMethods tbmethods;
    protected StyleManager sm;
    protected KeyActions ka;
    protected int fontSize = 20;
    
    public TextBoxModifier(Gui gui)
    {
        init(gui);
        
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        textBox = gui.getTextBox();
        tbmethods = TextBoxMethods.it = new TextBoxMethods(gui);
        sm = new StyleManager(gui, tbmethods); StyleManager.it = sm;
        ka = new KeyActions(gui, this, tbmethods);
        initTextBox();
        addMeToStateSaver();
        loadPreviousState();
    }
    public void loadPreviousState()
    {
        try
        {
            ArrayList<String> loaded = StateSaver.it.load("TextBoxModifier");
            if(loaded == null) 
                return;
            else
                setFontSize(Integer.parseInt(loaded.get(0)));
        }
        catch(Exception e)
        {
            //JOptionPane.showMessageDialog("Could not load previous font size.");
        }
    }
    public void addMeToStateSaver()
    {
        StateSaver.it.addCloseable(this);
    }
    public void closeProgram()
    {
        StateSaver.it.save("TextBoxModifier", arrayList(fontSize));
    }
    public void initTextBox()
    {
        textBox.getPane().addKeyListener(mkl = new MyKeyListener(gui, this));
        textBox.getPane().addMouseListener(mml = new MyMouseListener(gui, this));
        
        //TESTING!!!!
        //try{textBox.getPane().getStyledDocument().insertString(0,"a",textBox.attr());}catch(Exception e){}
    }
}
