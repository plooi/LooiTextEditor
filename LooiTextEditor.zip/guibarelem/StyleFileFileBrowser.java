package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;
import java.io.File;
import state.*;
import textrelated.*;

public class StyleFileFileBrowser extends FileBrowser
{
    
    protected Gui gui;
    
    
    public StyleFileFileBrowser(Gui gui)
    {
        super(gui);
        initStyleFileFileBrowser(gui);
    }
    public void initStyleFileFileBrowser(Gui gui)
    {
        this.gui = gui;
        set(10, 150, 280, 550, Background.DARK_GRAY_BACKGROUND);
    }
    
    public void fulfillBrowsePromise(File f)
    {
        StyleFileSelector.it.tryPut(f);
        if(FileSelectionState.it.getSelectedButton() != null)
            FileSelectionState.it.getSelectedButton().styleFileStuff();
        TextBoxMethods.it.refresh();
    }
    public void initFileBrowserRightClickButton()
    {
        addStationary(backgroundRightClickBtn = new FileBrowserRightClickButton(gui, getBackground())
        {
            public void rightClick()
            {
                menu.activateOpen(StyleFileFileBrowser.this);
            }
            public FileBrowsingPopupMenu makeFileBrowsingPopupMenu()
            {
                return new FileBrowsingPopupMenu()
                {
                    public void afterCreateNewFile()
                    {
                        StyleFileSelector.it.refresh();
                    }
                };
            }
        });
    }
    protected void _browse(String start)
    {
        if(start == null)
        {
            start = getDefaultDirectory();
        }
        openDir(start);
    }
}
