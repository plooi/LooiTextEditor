/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;
import java.awt.Color;
import ljs.gui.looicanvas.LooiObject;
import ljs.gui.looicanvas.three_dimensional.Component3D;
import ljs.gui.looicanvas.three_dimensional.Point3D;
import ljs.gui.looicanvas.three_dimensional.Polygon3D;
import ljs.gui.looicanvas.utilities.Supplier;
import ljs.gui.looicanvas.utilities.TwoInsOneOut;

/**
 *
 * @author peter_000
 */
public class Quadrilateral3DGrid extends LooiObject implements Component3D
{
    private Point3D[][] points;
    private Supplier<View> view;
    private TwoInsOneOut<Integer,Integer,Color> color;
    private Polygon3D[][] quadrilaterals;
    private Point3D[] corners;
    public Quadrilateral3DGrid(Point3D p1, Point3D p2, Point3D p3, Point3D p4, double unitSize, double morphContainerSize, Supplier<Double> morphContainerActivationDistance, TwoInsOneOut<Integer,Integer,Color> color, Supplier<View> view)
    {
        this.view = view;
        this.color = color;
        int p1p2Columns = (int)(p1.get3DDistance(p2)/unitSize)+1;
        int p3p4Columns = (int)(p3.get3DDistance(p4)/unitSize)+1; 
        int pointColumns = (int)((p1p2Columns + p3p4Columns)/2);

        int p1p4Rows = (int)(p1.get3DDistance(p4)/unitSize)+1;
        int p2p3Rows = (int)(p2.get3DDistance(p3)/unitSize)+1;
        int pointRows = (int)((p1p4Rows + p2p3Rows)/2);
        points = new Point3D[pointRows][pointColumns];
        quadrilaterals = new Polygon3D[getQuadrilateralRows()][getQuadrilateralColumns()];

        corners = new Point3D[] {p1,p2,p3,p4};


        setPointsConstructor();
        for(int r = 0; r < pointRows-1; r++)
        {

            for(int c = 0; c < pointColumns-1; c++)
            {

                quadrilaterals[r][c] = new Polygon3D(color.make(r,c),view,points[r][c],points[r+1][c],points[r+1][c+1],points[r][c+1]);



            }
        }
    }
    public int getQuadrilateralRows()
    {
        return getPointRows()-1;
    }
    public int getQuadrilateralColumns()
    {
        return getPointColumns()-1;
    }
    public int getPointRows()
    {
        return points.length;
    }
    public int getPointColumns()
    {
        return points[0].length;
    }
    public Point3D[] getCorners()
    {
        return corners.clone();
    }
    public void updateVisual()
    {
        setPoints();
    }
    protected void setPointsConstructor()
    {
        for(int r = 0; r < points.length; r++)
        {

            for(int c = 0; c < points[0].length; c++)//WHY DOES THIS WORK TO VERY SPECIFIC COORDS?
                {
                    Point3D pointOnUpperSide = corners[0].moveTowards3D(corners[1],corners[0].get3DDistance(corners[1])*c*1.0/(points[0].length-1));//2D point
                    Point3D pointOnLowerSide = corners[3].moveTowards3D(corners[2],corners[2].get3DDistance(corners[3])*c*1.0/(points[0].length-1));//2D point 
                    Point3D finalPoint = pointOnUpperSide.moveTowards3D(pointOnLowerSide,pointOnUpperSide.get3DDistance(pointOnLowerSide)*r*1.0/(points.length-1));
                    points[r][c] = finalPoint;
                }
        }
    }
    protected void setPoints()
    {
        for(int r = 0; r < points.length; r++)
        {

            for(int c = 0; c < points[0].length; c++)//WHY DOES THIS WORK TO VERY SPECIFIC COORDS?
                {
                    Point3D pointOnUpperSide = corners[0].moveTowards3D(corners[1],corners[0].get3DDistance(corners[1])*c*1.0/(points[0].length-1));//2D point
                    Point3D pointOnLowerSide = corners[3].moveTowards3D(corners[2],corners[2].get3DDistance(corners[3])*c*1.0/(points[0].length-1));//2D point 
                    Point3D finalPoint = pointOnUpperSide.moveTowards3D(pointOnLowerSide,pointOnUpperSide.get3DDistance(pointOnLowerSide)*r*1.0/(points.length-1));
                    points[r][c].setXYZ(finalPoint);
                }
        }
    }
    protected Color findAvgColor(int startRow, int startCol, int oneAfterEndRow/*in quadrilateral rows*/, int oneAfterEndCol)
    {
        int totalR = 0;
        int totalG = 0;
        int totalB = 0;
        int totalQuadrilaterals = 0;
        for(int r = startRow; r < oneAfterEndRow; r++)
        {
            for(int c = startCol; c < oneAfterEndCol; c++)
            {
                Component3D q = quadrilaterals[r][c];
                totalR += q.getColor().getRed();
                totalG += q.getColor().getGreen();
                totalB += q.getColor().getBlue();
                totalQuadrilaterals++;
            }
        }
        if(totalQuadrilaterals == 0)
        {
            return Color.BLACK;
        }
        int avgR = totalR / totalQuadrilaterals;
        int avgG = totalG / totalQuadrilaterals;
        int avgB = totalB / totalQuadrilaterals;
        return new Color(avgR,avgG,avgB);
    }
    @Override
    public Point3D getCenter() 
    {
        double sumX = 0;
        double sumY = 0;
        double sumZ = 0;
        for(Polygon3D[] ap : quadrilaterals)
        {
            for(Polygon3D pp : ap)
            {
                sumX += pp.getCenter().getX();
                sumY += pp.getCenter().getY();
                sumZ += pp.getCenter().getZ();
            }

        }
            
        int totalPolygons = quadrilaterals.length * quadrilaterals[0].length;
        double avgX = sumX / totalPolygons;
        double avgY = sumY / totalPolygons;
        double avgZ = sumZ / totalPolygons;
        return new Point3D(avgX,avgY,avgZ);
    }

    @Override
    public Color getColor() 
    {
        return findAvgColor(0,0,getQuadrilateralRows(),getQuadrilateralColumns());
    }
}
