package looitexteditorgui;
import static ljs.Obj.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import javax.swing.JTextArea;
import javax.swing.text.BadLocationException;


public class AllEncompassingKeyListener implements KeyListener
{
	private Gui gui;
	private boolean shift = false;
	private boolean control = false;
	public boolean controlDown(){return control;}
	public boolean shiftDown(){return shift;}
	public AllEncompassingKeyListener(Gui gui)
	{
		this.gui = gui;
	}
	public void keyTyped(KeyEvent e){}
	public void keyPressed(KeyEvent e)
	{
		if(e.getKeyCode() == KeyEvent.VK_SHIFT)
		{
			shift = true;
		}
		if(e.getKeyCode() == KeyEvent.VK_CONTROL)
		{
			control = true;
			gui.getSuggestionTab().setVisible(true);
		}
	}
	
	public void keyReleased(KeyEvent e)
	{
		if(e.getKeyCode() == KeyEvent.VK_SHIFT)
		{
			shift = false;
		}
			
		
		if(e.getKeyCode() == KeyEvent.VK_CONTROL)
		{
			control = false;
			gui.getSuggestionTab().setVisible(false);
		}
	}
	
	
}