/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JFrame;
import javax.swing.JPanel;

import ljs.Obj;
import ljs.gui.looicanvas.LooiCanvas;

/**
 *
 * @author peter_000
 */
public class Window extends Obj
{
    public static final int 
            default_width = 750,
            default_height = 600;
    private JFrame frame;
    private JPanel jp;
    public Window()
    {
        frame = new JFrame();
        frame.setSize(default_width,default_height);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.add(jp = new JPanel());
        jp.setLayout(null);
        
    }
    public void setBounds(int x, int y, int width, int height)
    {
        frame.setBounds(x,y,width,height);
    }
    public void setVisible(boolean visible)
    {
        frame.setVisible(visible);
    }
    public boolean isVisible(){return frame.isVisible();}
    public int getX(){return frame.getX();}
    public int getY(){return frame.getY();}
    public int getWidth(){return frame.getContentPane().getWidth();}
    public int getHeight(){return frame.getContentPane().getHeight();}
    public int getWindowWidth() {return frame.getWidth();}
    public int getWindowHeight() {return frame.getHeight();}
    public JFrame getJavaComponent(){return frame;}
    public void add(Component c)
    {
        jp.add(c.getJavaComponent()); 
        if(c instanceof TextBox || c instanceof Picture)
            toggleSize();
        if(c instanceof LooiCanvas)
        	((LooiCanvas)c).setParentWindow(this);
    }
    public void toggleSize()
    {
        frame.setSize(frame.getWidth() + 1,frame.getHeight());
        frame.setSize(frame.getWidth() - 1,frame.getHeight());
    }
    public void remove(Component c)
    {
    	jp.remove(c.getJavaComponent()); 
    }
    public void addWindowListener(WindowListener w)
    {
        frame.addWindowListener(w);
    }
    public void uponClosing(Action a)
    {
        addWindowListener(new WindowListener()
        {
            public void windowOpened(WindowEvent we) {}
            public void windowClosing(WindowEvent we) {a.act();}
            public void windowClosed(WindowEvent we) {}
            public void windowIconified(WindowEvent we) {}
            public void windowDeiconified(WindowEvent we) {}
            public void windowActivated(WindowEvent we) {}
            public void windowDeactivated(WindowEvent we) {}
        });
    }
}
