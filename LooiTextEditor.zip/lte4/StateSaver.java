package lte4;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import java.util.ArrayList;
import java.io.File;

/*
Allows cleanup to be run when the window closes

*/
public class StateSaver
{
    public static StateSaver it;
    public static interface Closeable{public void closeProgram();}
    protected ArrayList<Closeable> closeables = new ArrayList<>();
    protected String stateSaveFolder;
    public StateSaver(String stateSaveFolder)
    {
        init(stateSaveFolder);
    }
    public void init(String stateSaveFolder)
    {
        if(!stateSaveFolder.endsWith(File.separator)) stateSaveFolder = stateSaveFolder + File.separator;
        this.stateSaveFolder = stateSaveFolder;
    }
    public void uponClosing()
    {
        for(Closeable c : closeables)
        {
            c.closeProgram();
        }
    }
    public void addCloseable(Closeable c)
    {
        closeables.add(c);
    }
    public void save(String fileName, ArrayList<Object> lines)
    {
        if(!new File(stateSaveFolder).exists())
        {
            new File(stateSaveFolder).mkdir();
        }
        saveText(stateSaveFolder + fileName, lines.toArray());
    }
    public ArrayList<String> load(String fileName)
    {
        try
        {
            String[] text = loadText(stateSaveFolder + fileName);
            ArrayList<String> ret = new ArrayList<>();
            for(int i : range(text))
                ret.add(text[i]);
            return ret;
        }
        catch(Exception e)
        {
            return null;
        }
    }
}