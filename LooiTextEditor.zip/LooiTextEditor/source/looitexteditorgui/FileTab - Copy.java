package looitexteditorgui;
import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.io.File;
import javax.swing.JScrollPane;
import java.io.*;
import java.lang.StringBuilder;
public class RunTab extends ljs.gui.looicanvas.gui_essentials.Button implements Tab
{
	private Process process;
	private String allText = "";
	private String systemIn = "";
	private ljs.gui.looicanvas.gui_essentials.Button killButton;
	private double virtualX = 0;
	public void setVirtualX(double vx){virtualX = vx;}
	public double getVirtualX(){return virtualX;}
	private Font textFont = new Font("",Font.PLAIN,16);
	private boolean needToSetSize = true;
	private Gui gui;
	private double viewX,viewY;
	private boolean running = true;
	public void update(double viewX, double viewY)
	{
		synchronized(gui.getTextArea())
		{
			this.viewX = viewX;
			this.viewY = viewY;
		}
	}
	public String savableString(){return null;}
	public RunTab(Gui gui, String name, double fileButtonHeight, double fileBarOffset, double fileButtonCloseButtonWidth, Process process)
	{
		super(0,(fileBarOffset - fileButtonHeight)/2.0,100,fileButtonHeight,name,Background.RED_BACKGROUND);
		this.gui = gui;
		this.process = process;
		
		add(killButton = new ljs.gui.looicanvas.gui_essentials.Button(getWidth()-fileButtonCloseButtonWidth,0,fileButtonCloseButtonWidth,getHeight(),"  X",Background.LIGHT_GRAY_BACKGROUND)
		{
			public void action()
			{
				if(running)
				{
					process.destroy();
					running = false;
					RunTab.this.setBackground(Background.DARK_GRAY_BACKGROUND);
					RunTab.this.setBottomShadow(DEFAULT_BOTTOM_SHADOW);
					RunTab.this.setRightShadow(DEFAULT_RIGHT_SHADOW);
					RunTab.this.setHoverLightUp(getHoverLightUp());
					RunTab.this.setButtonPressShadow(RunTab.this.getButtonPressShadow());
					RunTab.this.setPressedBackground(new Background(RunTab.this.applyShadow(RunTab.this.getBackground().getColor(),RunTab.this.getButtonPressShadow())));
				}
				else
				{
					kill();
				}
			}
		});
		
		setFont(textFont);
		
		Graphics g2 = thisLooiCanvas().getGraphics().create();
		g2.setFont(textFont);
		double stringWidth = g2.getFontMetrics().stringWidth(getText());
		stringWidth *= getInternalWidth()/thisLooiCanvas().getViewWidth();
		setDimensions(stringWidth+gui.getFileBar().getFileButtonCloseButtonExtraSpaceFromFileButtonText()+fileButtonCloseButtonWidth,getHeight());
		killButton.setPosition(getX() + getWidth()-fileButtonCloseButtonWidth,getY());
	}
	public void kill()
	{
		RunTab.this.delete();
		killButton.deactivate();
	}
	public void delete()
	{
		if(isBeingViewed())
		{
			gui.setViewedTab(null);
			gui.getTextArea().setText("");
		}
		gui.getFileBar().removeTab(this);
		deactivate();
	}
	public void action()
	{
		view();
	}
	public void view()
	{
		synchronized(gui.getTextArea())
		{
			gui.getTextArea().getSaver().save();
			gui.setViewedTab(this);
			gui.getTextArea().setText(allText);
			((JScrollPane)gui.getTextArea().getJavaComponent()).getViewport().setViewPosition(new java.awt.Point((int)viewX,(int)viewY));
			gui.getTextArea().setEditable(false);
		}
	}
	
	public boolean isBeingViewed(){return gui.getViewedTab()==this;}
	public void looiStep()
	{
		setPosition(virtualX - gui.getFileBar().getScrollX(),getY());
		super.looiStep();
	}
	public void undo(){}
	public void redo(){}
	public void appendText(String text)
	{
		allText += text;
		if(isBeingViewed())
		{
			gui.getTextArea().setText(allText);
			gui.getTextArea().scrollTo(Integer.MAX_VALUE);
		}
	}
	public void appendSystemIn(String text)
	{
		systemIn += text;
		allText += text;
		if(isBeingViewed())
		{
			gui.getTextArea().setText(allText);
			gui.getTextArea().scrollTo(Integer.MAX_VALUE);
		}
	}
	public void inputSystemIn()
	{
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(process.getOutputStream()));
		try{bw.write(systemIn);}catch(Exception e){}
		systemIn = "";
		appendText("");
		try{bw.close();}catch(Exception e){}
	}
	public void backspaceSystemIn()
	{
		if(systemIn.length() > 0)
		{
			systemIn = systemIn.substring(0,systemIn.length() - 1);
			allText = allText.substring(0,allText.length() - 1);
			if(isBeingViewed())
			{
				gui.getTextArea().setText(allText);
				gui.getTextArea().scrollTo(Integer.MAX_VALUE);
			}
	
		}
	}
}