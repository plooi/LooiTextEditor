package lte4;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import java.awt.Color;
import javax.swing.text.BadLocationException;
import javax.swing.KeyStroke;
import javax.swing.InputMap;
import javax.swing.text.AttributeSet;
import java.util.HashMap;
import java.awt.Dimension;
import javax.swing.text.*;

/*
The only goal is to provide a generic, innocent text box on the screen
and to provide a primitive ability to add text of a certain style
*/
public class MyTextBox extends Component
{
    //INTERFACE
    
    
    
    public JTextPane getPane(){return pane;}
    
    //By the way, most of these methods are synchronized because only one thread should be able to read or write to the text pane at a time! Even if one is reading or writing, I would like the reading thread to not have to deal with the garbage that exists WHILE the other thread is trying to write!
    public synchronized void setDefaultTextColor(Color c){pane.setForeground(c);}
    public synchronized int getTextLength(){return pane.getStyledDocument().getLength();}
    public synchronized String getText(){try{return pane.getStyledDocument().getText(0, pane.getStyledDocument().getLength());}catch(Exception e){e.printStackTrace();return null;}}
    public synchronized void setText(String text){if(pane.isEditable())pane.setText(text);}
    public synchronized int getCaretPosition(){return pane.getCaretPosition();}
    public synchronized void setCaretPosition(int i){try{if(pane.isEditable())pane.setCaretPosition(i);}catch(Exception e){throw new RuntimeException(e);}}
    public synchronized void insertString(String s, int index){try{if(pane.isEditable()) pane.getStyledDocument().insertString(index, s, null);}catch(Exception e){e.printStackTrace();}}
    public synchronized void remove(int start, int stop){try{if(pane.isEditable())pane.getStyledDocument().remove(start, stop - start);}catch(Exception e){e.printStackTrace();}}
    public synchronized void replaceRange(int start, int stop, String replace)
    {
        if(pane.isEditable())
        {
            remove(start, stop);
            insertString(replace, start);
        }
    }
    /*
    This method actually forms a selection
    */
    public synchronized void moveCaretPosition(int i){try{pane.moveCaretPosition(i);}catch(Exception e){throw new RuntimeException(e);}}
    
    
    public synchronized int getSelectionStart(){return pane.getSelectionStart();}
    public synchronized int getSelectionEnd(){return pane.getSelectionEnd();}
    public synchronized void setSelectionStart(int i){pane.setSelectionStart(i);}
    public synchronized void setSelectionEnd(int i){pane.setSelectionEnd(i);}
    
    protected HashMap<Integer, AttributeSet> attributesOfIndicies = new HashMap<>();
    public synchronized void color(int start, int stop, AttributeSet aset)
    {
        boolean mustChange = false;
        for(int i = start; i < stop; i++)
        {
            AttributeSet asetAt_i = pane.getStyledDocument().getCharacterElement(i).getAttributes();
            if(asetAt_i != null && aset.isEqual(asetAt_i))
            {
                //good, no change needed
            }
            else
            {
                //we must change the attributes
                mustChange = true;
            }
        }
        if(mustChange)
        {
            try
            {
                getPane().getStyledDocument().setCharacterAttributes(start, stop - start, aset, true);
            }
            catch(Exception e)
            {
                //okay well let's pretend like that exception didn't happen
            }
        }
    }
    public synchronized void copy(){pane.copy();}
    public synchronized void paste(){pane.paste();}
    public synchronized void setEditable(boolean b){pane.setEditable(b);}
    //END INTERFACE
    
    
    
    protected Gui gui;
    protected MyJTextPane pane;
    protected JScrollPane scrollPane;
    
    public MyTextBox(Gui gui)
    {
        super(new JScrollPane(new MyJTextPane()));
        
        init(gui);
    }
    public void init(Gui gui)
    {
        
        this.gui = gui;
        pane = (MyJTextPane)(( javax.swing.JViewport)((JScrollPane)getJavaComponent()).getComponent(0)).getComponents()[0];
        scrollPane = (JScrollPane)getJavaComponent();
        setLocationThreadIterationWait(gui.getLocationThreadIterationWait());
        disableKeyBindings();
        //initLineNumbers();
    }
    /*public void initLineNumbers()
    {
        TextLineNumber tln = new TextLineNumber(pane);
        scrollPane.setRowHeaderView( tln );
    }*/
    public void disableKeyBindings()
    {
        InputMap im = pane.getInputMap();
        for(int i : range(32, 128))//lowercase
            im.put(KeyStroke.getKeyStroke((char)i), "none");
    }
    public static class MyJTextPane extends JTextPane
    {
        public boolean wrap = false;
        public MyJTextPane()
        {
            //setPreferredSize(new Dimension(9999999,9999999));
            setEditorKit(new ExtendedStyledEditorKit());
        }
        public boolean getScrollableTracksViewportWidth()
        {
            //if(1 == 1)return false;
            if(wrap == false)
                return getUI().getPreferredSize(this).width <= getParent().getSize().width;
            else
                return super.getScrollableTracksViewportWidth();
        }
        /*public void setBounds(int x, int y,int width, int height)
        {
            Dimension size = this.getPreferredSize();
            super.setBounds(x
                            ,y
                            ,Math.max(size.width, width)
                            ,height
                            );
        }*/
    }
    
    public int checkDisplayedTextLength()
    {
        int i = 0;
        while(true)
        {
            i += 1000000;
            if(!checkGoodIndexInDisplayedText(i))
                break;
        }
        //now i is the first bad index
        int high = i;
        int low = i - 1000000;
        
        while(true)
        {
            if(high - 1 == low)
            {
                //p("HI: " + high + " LOW: " + low);
                return low-1;
            }
            int mid = (high+low)/2;
            if(checkGoodIndexInDisplayedText(mid))//mid is good, search from mid to high for the boundary
                low = mid;
            else//if mid is bad, seach from low to mid
                high = mid;
            //this way, high is always bad, and low is always good
        }
    }
    
        //start section not made by me
        //code from https://stackoverflow.com/questions/23149512/how-to-disable-wordwrap-in-java-jtextpane 
        static class ExtendedStyledEditorKit extends StyledEditorKit {
        private static final long serialVersionUID = 1L;
    
        private static final ViewFactory styledEditorKitFactory = (new StyledEditorKit()).getViewFactory();
    
        private static final ViewFactory defaultFactory = new ExtendedStyledViewFactory();
    
        public Object clone() {
            return new ExtendedStyledEditorKit();
        }
    
        public ViewFactory getViewFactory() {
            return defaultFactory;
        }
    
        /* The extended view factory */
        static class ExtendedStyledViewFactory implements ViewFactory {
            public View create(Element elem) {
                String elementName = elem.getName();
                if (elementName != null) {
                    if (elementName.equals(AbstractDocument.ParagraphElementName)) {
                        return new ExtendedParagraphView(elem);
                    }
                }
    
                // Delegate others to StyledEditorKit
                return styledEditorKitFactory.create(elem);
            }
        }
    
    }
    
    static class ExtendedParagraphView extends ParagraphView {
        public ExtendedParagraphView(Element elem) {
            super(elem);
        }
    
        @Override
        public float getMinimumSpan(int axis) {
            return super.getPreferredSpan(axis);
        }
    }
    
    //end section not made by me
    
    
    
    /*
    Note, the index at the length of the text is ALSO considered a valid index
    */
    private boolean checkGoodIndexInDisplayedText(int index)
    {
        try
        {
            String s = pane.getText(0, index);
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
        
    }
    
    
    
    
    
    
    
}
