package looitexteditorgui;
import static ljs.Obj.*;
import ljs.gui.*;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JFileChooser;
import java.io.File;
import java.util.ArrayList;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.JOptionPane;
import java.io.IOException;
import java.io.FileNotFoundException;
import javax.swing.JColorChooser;
import java.awt.Color;
import java.util.Arrays;
import java.awt.GraphicsEnvironment;

public class LTEMenuBar extends JMenuBar
{
	private static final String[] default_font_strings = {"Courier","Courier New","Arial","Default","Times New Roman","Comic Sans MS"};
	static
	{
		Arrays.sort(default_font_strings);
	}
	private static final Font default_menu_font = new Font("Arial",Font.PLAIN,16);
	private JMenu documentMenu;
	private MenuItem accept,create;
	private JMenu styleMenu;
	private JMenu fontSize,font,lineWrap;
	private MenuItem otherFont,backgroundColor,textColor,caretColor,selectedTextHighlight,matchingTextHighlight,noneLineWrap,wrapLine,wrapWords;
	private JMenu suggestionsMenu;
	private JMenu selectSuggestion,editSuggestion;
	private MenuItem addSuggestion;
	private ArrayList<MenuItem> suggestionsButtons = new ArrayList<>();
	private ArrayList<MenuItem> suggestionsEditButtons = new ArrayList<>();
	private ArrayList<MenuItem> 
		fontSizes = new ArrayList<>(),
		fonts = new ArrayList<>();
	private JMenu navigateMenu;
	private MenuItem goToLine;
	private JMenu runMenu;
	private MenuItem runButton;
	
	
	
	private JFileChooser jfc,createPathChooser;
	
	private String[] fontStrings;
	private Gui gui;
	private Font menuFont;
	
	public LTEMenuBar(Gui gui)
	{
		this(gui,default_font_strings,default_menu_font);
	}
	public LTEMenuBar(Gui gui, String[] fontStrings, Font menuFont)
	{
		this.gui = gui;
		this.fontStrings = fontStrings;
		this.menuFont = menuFont;
		init();
	}
	public void init()
	{
		class JMenu extends javax.swing.JMenu
		{
			public JMenu(String s)
			{
				super(s);
				setFont(menuFont);
			}
		}
		add(documentMenu = new JMenu("Document"));
		jfc = new JFileChooser();
		jfc.setCurrentDirectory(new File("documents")); 
		jfc.setDialogTitle("Accept");
		documentMenu.add(accept = new MenuItem("Accept",()->
		{
            if(gui.getViewedTab() != null && (gui.getViewedTab() instanceof FileTab))
			{
				String viewedFilePath = ((FileTab)gui.getViewedTab()).getPath();
				jfc.setCurrentDirectory(new File(viewedFilePath.substring(0,viewedFilePath.lastIndexOf("\\"))));
				jfc.setSelectedFile(new File(""));
			}
			if(jfc.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
			{
				FileTab ft;
				gui.getFileBar().addTab(ft = new FileTab(gui,jfc.getSelectedFile().getPath(),gui.getFileBar().getFileTabHeight(),gui.getFileBarOffset(),gui.getFileBar().getFileButtonCloseButtonWidth()));
				ft.view();
			}
			
		},menuFont));
		createPathChooser = new JFileChooser();
		createPathChooser.setCurrentDirectory(new File("documents")); 
		createPathChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY); 
		createPathChooser.setDialogTitle("Select Directory");
		documentMenu.add(create = new MenuItem("Create",()->
		{
			if(gui.getViewedTab() != null && (gui.getViewedTab() instanceof FileTab))
			{
				String viewedFilePath = ((FileTab)gui.getViewedTab()).getPath();
				createPathChooser.setCurrentDirectory(new File(viewedFilePath.substring(0,viewedFilePath.lastIndexOf("\\"))));
				createPathChooser.setSelectedFile(new File(""));
			}
			if(createPathChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
			{
				String name = JOptionPane.showInputDialog(null,"Enter name:","",JOptionPane.PLAIN_MESSAGE);
				if(name == null)return;
				String totalPath = createPathChooser.getSelectedFile().getPath()+"\\"+name;
				saveText(totalPath,array(""));
				gui.getFileBar().viewNewTab(totalPath);
			}
			
		},menuFont));
		add(styleMenu = new JMenu("Style"));
		styleMenu.add(fontSize = new JMenu("Font Size"));
		for(int i : range(8,66,2))
		{
			MenuItem mi = new MenuItem(i + " pt", ()->
			{
				JTextArea jta = gui.getTextArea().getJTextArea();
				setFontSize(i);
			},menuFont);
			
			fontSize.add(mi);
			fontSizes.add(mi);
		}
		styleMenu.add(font = new JMenu("Font Type"));
		
		for(String s : fontStrings)
		{
			MenuItem mi = new MenuItem(s, ()->
			{
				JTextArea jta = gui.getTextArea().getJTextArea();
				setFontType(s);
			},menuFont);
			
			font.add(mi);
			fonts.add(mi);
		}
		styleMenu.add(otherFont = new MenuItem("Other Font...",()->
		{
			String name = JOptionPane.showInputDialog(null,"Enter font name:","",JOptionPane.PLAIN_MESSAGE);
			if(name == null)return;
			setFontType(name);
		},menuFont));
		
		styleMenu.add(backgroundColor = new MenuItem("Set Background Color",()->
		{
			Color newBackgroundColor = JColorChooser.showDialog(null,"Set Background Color",gui.getBackgroundColor());
			if(newBackgroundColor == null)return;
			gui.setBackgroundColor(newBackgroundColor);
		},menuFont));
		styleMenu.add(textColor = new MenuItem("Set Text Color",()->
		{
			Color newTextColor = JColorChooser.showDialog(null,"Set Text Color",gui.getTextColor());
			if(newTextColor == null)return;
			gui.setTextColor(newTextColor);
		},menuFont));
		styleMenu.add(caretColor = new MenuItem("Set Caret Color",()->
		{
			Color newCaretColor = JColorChooser.showDialog(null,"Set Caret Color",gui.getTextArea().getJTextArea().getCaretColor());
			if(newCaretColor == null)return;
			gui.setCaretColor(newCaretColor);
		},menuFont));
		styleMenu.add(selectedTextHighlight = new MenuItem("Set Selected Text Highlight Color",()->
		{
			Color cc = JColorChooser.showDialog(null,"Set Selected Text Highlight Color",gui.getTextArea().getSelectionColor());
			if(cc == null)return;
			gui.setSelectionColor(cc);
		},menuFont));
		styleMenu.add(matchingTextHighlight = new MenuItem("Set Matching Word Highlight Color",()->
		{
			Color cc = JColorChooser.showDialog(null,"Set Matching Word Highlight Color",gui.getTextArea().getMatchingTextHighlightColor());
			if(cc == null)return;
			gui.setMatchingTextHighlightColor(cc);
		},menuFont));
		styleMenu.add(matchingTextHighlight = new MenuItem("Set Selected Text Text Color",()->
		{
			Color cc = JColorChooser.showDialog(null,"Set Selected Text Text Color",gui.getTextArea().getJTextArea().getSelectedTextColor());
			if(cc == null)return;
			gui.setSelectedTextColor(cc);
		},menuFont));
		styleMenu.add(lineWrap = new JMenu("Line Wrap"));
		lineWrap.add(noneLineWrap = new MenuItem("None",()->
		{
			gui.getTextArea().wrapLine(false);
			gui.getTextArea().wrapAroundWords(false);
		},menuFont));
		lineWrap.add(wrapLine = new MenuItem("Wrap Line",()->
		{
			gui.getTextArea().wrapLine(true);
			gui.getTextArea().wrapAroundWords(false);
		},menuFont));
		lineWrap.add(noneLineWrap = new MenuItem("Wrap Words",()->
		{
			gui.getTextArea().wrapLine(true);
			gui.getTextArea().wrapAroundWords(true);
		},menuFont));
		
		add(suggestionsMenu = new JMenu("Suggestions"));
		suggestionsMenu.add(selectSuggestion = new JMenu("Select Suggestion"));
		suggestionsMenu.add(editSuggestion = new JMenu("Edit Suggestion"));
		refreshSuggestionsMenu();
		suggestionsMenu.add(addSuggestion = new MenuItem("Add Suggestion File",()->
		{
			String name = JOptionPane.showInputDialog(null,"Enter name:","",JOptionPane.PLAIN_MESSAGE);
			if(name == null)return;
			name += ".sg";
			saveText(name,array(""));
			gui.getFileBar().viewNewTab(name);
			refreshSuggestionsMenu();
		},menuFont));
		add(navigateMenu = new JMenu("Navigate"));
		navigateMenu.add(goToLine = new MenuItem("Go To Line",()-> 
		{
			String in = JOptionPane.showInputDialog(null,"Enter line number:","",JOptionPane.PLAIN_MESSAGE);
			int lineNumber;
			try
			{
				lineNumber = Integer.parseInt(in);
				gui.getTextArea().goToLine(lineNumber);
			}
			catch(NumberFormatException ex){}
		},menuFont));
		add(runMenu = new JMenu("Run"));
		runMenu.add(runButton = new MenuItem("Run This File",()->
		{
			gui.getExecutor().execute();
		},menuFont));
		
	}
	public void refreshSuggestionsMenu()
	{
		
		selectSuggestion.removeAll();
		editSuggestion.removeAll();
		File here = new File(".");
		File[] suggestionFiles = here.listFiles((f)->f.getPath().endsWith(".sg"));
		for(File f : suggestionFiles)//select
		{
			File ff = f;
			MenuItem suggestionSelection = new MenuItem(f.getName(),()->
			{
				try
				{
					gui.getSuggestionTab().loadSuggestions(ff.getName());
				}
				catch(RuntimeException exc)
				{
					refreshSuggestionsMenu();
					return;
				}
			},menuFont);
			suggestionsButtons.add(suggestionSelection);
			selectSuggestion.add(suggestionSelection);
		}
		for(File f : suggestionFiles)//edit
		{
			File ff = f;
			MenuItem suggestionSelection = new MenuItem(f.getName(),()->
			{
				try
				{
				gui.getFileBar().viewNewTab(ff.getPath());
				}
				catch(RuntimeException exc)
				{
					refreshSuggestionsMenu();
					return;
				}
			},menuFont);
			suggestionsButtons.add(suggestionSelection);
			editSuggestion.add(suggestionSelection);
		}
	}
	public void setFontSize(int size)
	{
		JTextArea jta = gui.getTextArea().getJTextArea();
		gui.getTextArea().setFont(new Font(jta.getFont().getName(),jta.getFont().getStyle(),size));
	}
	public void setFontType(String type)
	{
		JTextArea jta = gui.getTextArea().getJTextArea();
		gui.getTextArea().setFont(new Font(type,jta.getFont().getStyle(),jta.getFont().getSize()));
	}
}