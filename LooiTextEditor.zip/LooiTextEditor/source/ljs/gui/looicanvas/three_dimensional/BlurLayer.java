/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;


import java.util.ArrayList;
import ljs.gui.looicanvas.LooiObject;
import ljs.gui.looicanvas.utilities.Supplier;

/**
 *
 * @author peter_000
 */
public class BlurLayer extends ArrayList<LooiObject>
{
    private double 
            minDistance,
            maxDistance;
    private Supplier<View> view;
    private boolean shown = false;
    private Point3D center;
    
    public double getMinDistance(){return minDistance;}
    public double getMaxDistance(){return maxDistance;}
    public void setMaxDistance(double d){maxDistance = d;}
    public void setMinDistance(double d){minDistance = d;}
    public BlurLayer(Point3D center, double minDistance, double maxDistance, Supplier<View> view)
    {
        super();
        this.minDistance = minDistance;
        this.maxDistance = maxDistance;
        this.view = view;
        this.center = center;
    }
    public boolean showOrHide()
    {
        
        if(showCondition())
        {
            if(shown == false)
            {
                for(LooiObject c : this)
                {
                    c.activate();
                }
                shown = true;
            }
            
        }
        else
        {
            if(shown == true)
            {
                
                for(LooiObject c : this)
                {
                    c.deactivate();
                }
                shown = false;
            }
            
        }
        return shown;
    }
    protected boolean showCondition()
    {
        double distance = center.getHorizontalDistance(view.get());
        return distance < maxDistance && distance >= minDistance;
    }
    public boolean isShowing(){return shown;}
    public void show()
    {
        for(LooiObject c : this)
        {
            c.activate();
        }
        shown = true;
    }
    public void hide()
    {
        for(LooiObject c : this)
        {
            c.deactivate();
        }
        shown = false;
    }
    void update(LooiObject l)
    {
        if(shown)
        {
            l.activate();
        }
        else
        {
            l.deactivate();
        }
    }
    
    
}
