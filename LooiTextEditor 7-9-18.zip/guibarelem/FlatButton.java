package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;

public abstract class FlatButton extends RightClickButton
{
    public FlatButton(double x, double y, double width, double height, String text, Background background) 
    {
        super(background);
        initFl(x, y, width, height, text);
    }
    public void initFl(double x, double y, double width, double height, String text)
    {
        setDepth(0);
        set(x, y, width, height);
        setText(text);
    }
    public void rightClick(){}
}