package looitexteditorgui;
import static ljs.Obj.*;
import ljs.gui.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JTextArea;
import java.util.Arrays;
import java.util.HashMap;
import java.util.ArrayList;
import java.awt.Font;
import java.io.File;
public class SuggestionTab extends TextBox
{
	private static String default_sepatator = "   \u00A0   ";
	
	private Gui gui;
	private int fileBarOffset;
	private JTextArea jta; 
	private HashMap<String,String> replacements = new HashMap<>();
	private ArrayList<Suggestion> suggestions = new ArrayList<>();
	private String text;
	private String separator;
	public SuggestionTab(int fileBarOffset, Gui gui)
	{
		this(fileBarOffset,gui,default_sepatator);
	}
	public SuggestionTab(int fileBarOffset, Gui gui, String separator)
	{
		this.separator = separator;
		setVisible(false);
		initializeReplacements();
		this.gui = gui;
		jta = getJTextArea();
		this.fileBarOffset = fileBarOffset;
		setEditable(true);
		if(new File("default_suggestions.sg").exists())
			loadSuggestions("default_suggestions.sg");
		jta.addMouseListener(new MouseListener()
		{
			public void mouseClicked(MouseEvent e){}
			public void mouseEntered(MouseEvent e){}
			public void mouseExited(MouseEvent e){}
			public void mouseReleased(MouseEvent e)
			{
				synchronized(this)
				{
					int caretLocation = jta.getCaretPosition();
					if(gui.getAEKL().controlDown())
					{
						String selectedWord;
						if(jta.getSelectedText() == null || (jta.getSelectedText().length() <= 1))
							selectedWord = selectedWord(caretLocation);
						else
							selectedWord = jta.getSelectedText();
						if(selectedWord.equals(""))
						{
							return;
						}
						Suggestion s = null;
						for(int i : range(SuggestionTab.this.suggestions))
						{
							if(SuggestionTab.this.suggestions.get(i).getWord().equals(selectedWord))
							{
								s = SuggestionTab.this.suggestions.get(i);
								break;
							}
						}
						for(String original : replacements.keySet())
						{
							String replacement = replacements.get(original);
							selectedWord = selectedWord.replaceAll(original,replacement);
						}
						gui.getTextArea().insert(selectedWord,gui.getTextArea().getJTextArea().getCaretPosition());
						gui.getTextArea().getJTextArea().grabFocus();
						try{gui.getTextArea().setCaretPos(gui.getTextArea().getJTextArea().getCaretPosition() + s.getNegativeIndex());}catch(Exception ex){}
					}
					setText(text);
				}
			}
			public void mousePressed(MouseEvent e)
			{
				
			}
			
			
		});
		setBounds(()->0,()->gui.getMainWindow().getHeight()-fileBarOffset,()->gui.getMainWindow().getWidth(),()->fileBarOffset);
		jta.setFont(new Font("",Font.PLAIN,16));
		wrapLine(true);
		wrapAroundWords(true);
	}
	public void initializeReplacements()
	{
		replacements.put("<n>","\n");
		replacements.put("<t>","\t");
		replacements.put("<Space>"," ");
		replacements.put("<Comma>",",");
		replacements.put("<Dot>",".");
		replacements.put("<Period>",".");
		
	}
	public void loadSuggestions(String fileName)
	{
		setText("");
		this.suggestions.clear();
		String[] suggestions = loadText(fileName);
		Arrays.sort(suggestions);
		for(String suggestion : suggestions)
		{
			int negativeIndex = 0;
			String coreSuggestion;
			if(suggestion.contains("~"))
			{
				coreSuggestion = suggestion.substring(0,suggestion.indexOf("~"));
				negativeIndex = Integer.parseInt(suggestion.substring(suggestion.indexOf("~")+1));
			}
			else
				coreSuggestion = suggestion;
			this.suggestions.add(new Suggestion(coreSuggestion,negativeIndex));
			setText(getText() + coreSuggestion + separator);
		}
		text = getText();
	}
	/*public String replaceAll(String body, String original, String replacement)
	{
		for(int i = 0; i < body.length(); i++)
		{
			if(body.indexOf(original) == i)
			{
				String before = body.substring(0,i);
				String after = body.substring(i+original.length());
				body = before + replacement + after;
			}
		}
		return body;
		
	}*/
	public int previousSeparationToCursor(int cursorLocation)
	{
		String text = jta.getText();
		//check if we are inside the separator
		
		for(int i = cursorLocation - separator.length()/2; i >= 0; i--)
		{
			try
			{
				if(text.substring(i).indexOf(separator) == 0)
				{
					return i + separator.length() - 1;
				}
			}
			catch(StringIndexOutOfBoundsException ex)
			{
				break;
			}
		}
		return -1;
	}
	public int nextSeparationToCursor(int cursorLocation)
	{
		String text = jta.getText();
		for(int i = cursorLocation - separator.length()/2; i < text.length(); i++)
		{
			try
			{
				if(text.substring(i).indexOf(separator) == 0)
				{
					return i;
				}
			}
			catch(StringIndexOutOfBoundsException ex)
			{
				
			}
		}
		return text.length();
	}
	public String selectedWord(int caretLocation)
	{
		//p("jta.getText().substring("+(previousSpaceToCursor(caretLocation)+1)+","+nextSpaceToCursor(caretLocation)+")");
		int start = previousSeparationToCursor(caretLocation)+1;
		int end = nextSeparationToCursor(caretLocation);
		if(start >= end)
		{
			return "";
			
		}
		else return jta.getText().substring(start,end);
	}
	public class Suggestion
	{
		private String word;
		private int negativeIndex;
		public Suggestion(String word, int negativeIndex)
		{
			this.word = word;
			this.negativeIndex = negativeIndex;
			
		}
		public String getWord(){return word;}
		public int getNegativeIndex(){return negativeIndex;}
	}
	
}