/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.gui_essentials;

import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.Arrays;
import ljs.gui.looicanvas.LooiObject;
import ljs.gui.looicanvas.LooiCanvas;

/**
 * @SuppressWarnings("unchecked")
 * @author peter_000
 */
 @SuppressWarnings("deprecation")
public abstract class GuiComponent extends LooiObject
{
    private double x;
    private double y;
    private ArrayList<Rectangle> paintBoundaries = new ArrayList<Rectangle>()//every time the paint boundaries change, we must update the paint boundary
    {
        public boolean add(Rectangle r)
        {
            boolean ret = super.add(r);
            GuiComponent.this.updatePaintBoundary();;
            return ret;
        }
        public boolean remove(Rectangle r)
        {
            boolean ret = super.remove(r);
            GuiComponent.this.updatePaintBoundary();;
            return ret;
        }
    };
    public GuiComponent()
    {
        setPosition(0,0);
        //goToFront();
    }
    public GuiComponent(double x, double y)
    {
        setPosition(x,y);
        //goToFront();
    }
    @Override
    protected void looiPaint()
    {
        if(!isActive())
        {
            throw new LooiCanvas.CancelPaintException();
        }
    }
    public abstract boolean touchingMouse();
    public boolean touchingMouseAndInFront()
    {
        for(int i = 0; i < getNumComponents(); i++)
        {
            LooiObject l = getComponent(i);
            if(l instanceof GuiComponent)
            {
                GuiComponent gui = (GuiComponent)l;
                if(gui.touchingMouseAndInFront())
                {
                    return true;
                }
            }
        }
        if(!touchingMouse())
            return false;
        ArrayList<GuiComponent> candidates = new ArrayList<>();
        for(int i = 0; i < thisLooiCanvas().getNumActiveObjects(); i++)
        {
            
            //candidates.add(this);
            LooiObject currentLO;
            if((currentLO = thisLooiCanvas().getActiveObject(i)) instanceof GuiComponent)
            {
                GuiComponent currentGUIC = (GuiComponent)currentLO;
                if(currentGUIC.touchingMouse())
                {
                    candidates.add(currentGUIC);
                }
            }
            
        }
        GuiComponent mostNegativeLayer = this;
        for(GuiComponent g : candidates)
        {
            if(g.getLayer() < mostNegativeLayer.getLayer())
            {
                mostNegativeLayer = g;
            }
        }

        if(mostNegativeLayer == this)
            return true;
        return false;
    }
    public double getX()
    {
        return x;
    }
    public double getY()
    {
        return y;
    }
    public void setPosition(double x, double y)
    {
        if(x == getX() && y == getY())
            return;
        double deltaX = x - this.x;
        double deltaY = y - this.y;
        
        this.x = x;
        this.y = y;
        
        for(int i = 0; i < getNumComponents(); i++)
        {
            if(getComponent(i) instanceof GuiComponent)
            {
                GuiComponent g = (GuiComponent)getComponent(i);
                g.setPosition(g.getX() + deltaX,g.getY() + deltaY);
            }
        }
        updatePaintBoundary();
        
    }
    public void move(double xInc, double yInc)
    {
        setPosition(getX() + xInc,getY() + yInc);
    }
    public void updatePaintBoundary()
    {
        setPaintBoundary(getOverlap(paintBoundaries));
        for(int i = 0; i < getNumComponents(); i++)
        {
            if(getComponent(i) instanceof GuiComponent)
            {
                GuiComponent g = (GuiComponent)getComponent(i);
                g.updatePaintBoundary();
            }
        }
    }
    public void add(GuiComponent g)
    {
        super.add(g);
        g.setPosition(x+g.getX(),y+g.getY());
        if(g.getLayer() >= getLayer())
        {
            g.setLayer(getLayer()-1);
        }
        
        for(Rectangle r : paintBoundaries)
        {
            g.addPaintBoundary(r);
        }
        
    }
    public void remove(GuiComponent g)
    {
        super.remove(g);
        //g.setPosition(g.getX() - x,g.getY() - y);
        for(Rectangle r : paintBoundaries)
        {
            g.removePaintBoundary(r);
        }
    }
    public void setLayer(double layer)
    {
        double difference = layer - getLayer();
        super.setLayer(layer);
        
        for(int i = 0; i < getNumComponents(); i++)
        {
            getComponent(i).setLayer(getComponent(i).getLayer() + difference);
        }
    }
    
    protected void addPaintBoundary(Rectangle r)
    {
        paintBoundaries.add(r);
        for(int i = 0; i < getNumComponents(); i++)
        {
            LooiObject l = getComponent(i);
            if(l instanceof GuiComponent)
            {
                ((GuiComponent)l).addPaintBoundary(r);
            }
        }
        
    }
    protected void removePaintBoundary(Rectangle r)
    {
        paintBoundaries.remove(r);
        for(int i = 0; i < getNumComponents(); i++)
        {
            LooiObject l = getComponent(i);
            if(l instanceof GuiComponent)
            {
                ((GuiComponent)l).removePaintBoundary(r);
            }
        }
    }
    protected Rectangle getOverlap(ArrayList<Rectangle> rects)
    {
        if(rects.isEmpty())
        {
            return null;
        }
        
        RectangleShape overlap = new RectangleShape(rects.get(0)); 
        for(int i = 1; i < rects.size(); i++)
        {
            overlap = getOverlap(overlap,rects.get(i));
        }
        Rectangle r = new Rectangle(overlap.x,overlap.y,overlap.width,overlap.height,Background.BLACK_BACKGROUND);
        r.deactivate();
        return r;
    }
    protected RectangleShape getOverlap(RectangleShape a, Rectangle b)
    {
        double[] xVals = {a.x,a.x + a.width,b.getX(),b.getX() + b.getWidth()};
        double[] yVals = {a.y,a.y + a.height,b.getY(),b.getY() + b.getHeight()};
        Arrays.sort(xVals);
        Arrays.sort(yVals);
        return new RectangleShape(xVals[1],yVals[1],xVals[2] - xVals[1],yVals[2] - yVals[1]);
    }
    protected ArrayList<Rectangle> getPaintBoundaries()
    {
        return paintBoundaries;
    }
    private class RectangleShape
    {
        public final double x,y,width,height;
        public RectangleShape(double x, double y, double width, double height)
        {
            this.x = x;this.y = y; this.width = width; this.height = height;
        }
        public RectangleShape(Rectangle r)
        {
            this.x = r.getX();this.y = r.getY(); this.width = r.getWidth(); this.height = r.getHeight();
        }
    }
    
}
