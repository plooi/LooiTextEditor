package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Point;
/*
listen for mouse clicks
*/
public class MyMouseListener implements  MouseListener
{
    protected Gui gui;
    protected TextBoxModifier tbm;
    public MyMouseListener(Gui gui, TextBoxModifier tbm)
    {
        init(gui, tbm);
    }
    public void init(Gui gui, TextBoxModifier tbm)
    {
        this.gui = gui;
        this.tbm = tbm;
    }
    public void mouseClicked(MouseEvent e){}
    public void mouseEntered(MouseEvent e){}
    public void mouseExited(MouseEvent e){}
    public void mousePressed(MouseEvent e)
    {
        e.consume();
        MouseEventInterface mei = new MouseEventInterface()
        {
            public int getButton(){return e.getButton();}
            public int getClickCount(){return e.getClickCount();}
            public Point getPoint(){return e.getPoint();}
        };
        tbm.getKeyActions().execute(mei, tbm.getMyKeyListener().getControlShiftMode(), true);
    }
    public void mouseReleased(MouseEvent e)
    {
        e.consume();
        MouseEventInterface mei = new MouseEventInterface()
        {
            public int getButton(){return e.getButton();}
            public int getClickCount(){return e.getClickCount();}
            public Point getPoint(){return e.getPoint();}
        };
        tbm.getKeyActions().execute(mei, tbm.getMyKeyListener().getControlShiftMode(), false);
    }
}