/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.gui_essentials;

import java.awt.Color;
import java.awt.event.MouseEvent;
import ljs.gui.looicanvas.Point;

/**
 *
 * @author peter_000
 */
public class Slider extends Rectangle
{
    public static final double 
            DEFAULT_TRACK_HEIGHT = 3,
            DEFAULT_SLIDER_WIDTH = 10,
            DEFAULT_SLIDER_HEIGHT = 10,
            DEFAULT_MAX_SLIDER_HEIGHT = 20,
            DEFAULT_HORIZONTAL_MARGIN_FRACTION = .1,//.1 of width
            DEFAULT_STARTING_FRACTION = .5;
    public static final Color 
            DEFAULT_TRACK_COLOR = Color.LIGHT_GRAY,
            DEFAULT_SLIDER_COLOR = Color.BLACK;
    private double fraction;
    private double trackHeight = DEFAULT_TRACK_HEIGHT;
    private double horizontalMargin;
    private SliderObject sliderObject;
    private double sliderMinX;
    private double sliderMaxX;
    private Color sliderColor = DEFAULT_SLIDER_COLOR;
    private Color sliderColorPressed;
    private Color trackColor = DEFAULT_TRACK_COLOR;
    
    
    public Slider(double x, double y, double width, double height, Background background)
    {
        super(x,y,width,height,background);
        setHorizontalMargin(width * DEFAULT_HORIZONTAL_MARGIN_FRACTION);
        add(sliderObject = new SliderObject(DEFAULT_SLIDER_WIDTH,DEFAULT_SLIDER_HEIGHT,DEFAULT_MAX_SLIDER_HEIGHT));
        setSliderColorPressed(sliderColor.darker());
        setMinMax();
        slideToFraction(DEFAULT_STARTING_FRACTION);
    }
    
    public double getHorizontalMargin(){return horizontalMargin;}
    public double getTrackHeight(){return trackHeight;}
    public void setHorizontalMargin(double horizontalMargin)
    {
        this.horizontalMargin = horizontalMargin;
        setMinMax();
    }
    public void setTrackHeight(double trackHeight)
    {
        this.trackHeight = trackHeight;
        setMinMax();
    }
    public double getSliderMinX(){return sliderMinX;}
    public double getSliderMaxX(){return sliderMaxX;}
    public Color getSliderColor(){return sliderColor;}
    public void setSliderColor(Color sliderColor){this.sliderColor = sliderColor;}
    public Color getSliderColorPressed(){return sliderColorPressed;}
    public void setSliderColorPressed(Color c){sliderColorPressed = c;}
    public Color getTrackColor(){return trackColor;}
    public void setTrackColor(Color trackColor){this.trackColor = trackColor;}
    public SliderObject getSliderObject(){return sliderObject;}
    
    public void setPosition(double x, double y)
    {
        super.setPosition(x,y);
        setMinMax();
    }
    
    protected void setMinMax()
    {
        sliderMinX = getX() + getHorizontalMargin();
        sliderMaxX = getX() + getWidth() - getHorizontalMargin();
    }
    protected void looiStep()
    {
        super.looiStep();
        
        double totalDistance = sliderMaxX - sliderMinX;
        double sliderObjectX = sliderObject.getX();
        double sliderObjectProgress = sliderObjectX - sliderMinX;
        
        //sliderObject.setPosition(startX + distance * percentage/100,getY() + getHeight()/2);
        fraction = sliderObjectProgress/totalDistance;
    }
    protected void looiPaint()
    {
        super.looiPaint();
        setColor(trackColor);
        fillRect(getX() + getHorizontalMargin(),getY() + getHeight()/2 - getTrackHeight()/2,getWidth() - getHorizontalMargin()*2, getTrackHeight());
    }
    public void slideToFraction(double fraction)
    {
        setMinMax();
        if(fraction < 0)
            fraction = 0;
        else if(fraction > 1)
            fraction = 1;
        
        sliderObject.setPosition(fraction * (getSliderMaxX() - getSliderMinX()) + getSliderMinX(),sliderObject.getY());
        this.fraction = fraction;
    }
    public double getFraction(){return fraction;}
    
    public class SliderObject extends GuiComponent
    {
        private double width,height,maxHeight;
        private Point center;
        private Point[] points;
        private boolean isPressed = false;
        public SliderObject(double width, double height, double maxHeight)
        {
            super(Slider.this.getWidth()/2,Slider.this.getHeight()/2);
            //System.out.println(Slider.this.getX() + Slider.this.getWidth()+","+(Slider.this.getY() + Slider.this.getHeight()/2));
            this.width = width;
            this.height = height;
            this.maxHeight = maxHeight;
        }
        public double getWidth(){return width;}
        public double getHeight(){return height;}
        public double getMaxHeight(){return maxHeight;}
        public void setWidth(double d){width = d;}
        public void setHeight(double d){height = d;}
        public void setMaxHeight(double d){maxHeight = d;}
        
        protected void looiStep()
        {
            super.looiStep();
            if(mouseLeftPressed())
            {
                if(touchingMouseAndInFront())
                {
                    isPressed = true;
                }
            }
            if(mouseLeftReleased())
            {
                isPressed = false;
            }
            if(isPressed)
            {
                if(getInternalMouseX() < sliderMinX)
                {
                    setPosition(sliderMinX,Slider.this.getY() + Slider.this.getHeight()/2);
                }
                else if(getInternalMouseX() > sliderMaxX)
                {
                    setPosition(sliderMaxX,Slider.this.getY() + Slider.this.getHeight()/2);
                }
                else
                {
                    setPosition(getInternalMouseX(),Slider.this.getY() + Slider.this.getHeight()/2);
                }
            }
        }
        
        protected void looiPaint()
        {
            super.looiPaint();
            center = new Point(getX(),getY());
            points = findPoints();
            if(isPressed)
            {
                setColor(sliderColorPressed);
            }
            else
            {
                setColor(sliderColor);
            }
            
            fillPolygon(points);
        }
        protected Point[] findPoints()
        {
            Point leftUp = new Point(center.getX()-width/2,center.getY()-height/2);
            Point up = new Point(center.getX(),center.getY()-maxHeight/2);
            Point rightUp = new Point(center.getX()+width/2,center.getY()-height/2);
            
            Point leftDown = new Point(center.getX()-width/2,center.getY()+height/2);
            Point down = new Point(center.getX(),center.getY()+maxHeight/2);
            Point rightDown = new Point(center.getX()+width/2,center.getY()+height/2);
            
            return new Point[] {leftUp,up,rightUp,rightDown,down,leftDown};
        }

        @Override
        public boolean touchingMouse() 
        {
            return new Point(getInternalMouseX(),getInternalMouseY()).insideConvexSpace(points);
        }
    }
    
}
