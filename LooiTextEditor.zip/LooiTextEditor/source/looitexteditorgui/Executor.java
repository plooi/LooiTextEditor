package looitexteditorgui;
import static ljs.Obj.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.File;
import java.awt.Desktop;
import java.net.URI;
public class Executor
{
	private Gui gui;
	public Executor(Gui gui)
	{
		this.gui = gui;
	}
	public void execute()
	{
		new Thread(()->
		{
			Tab viewedTab = gui.getViewedTab();
			gui.setViewedTab(null);
			gui.getTextArea().setText("");
			p(gui.getTextArea().getText());
			if(viewedTab == null || !(viewedTab instanceof FileTab))
			{
				appendText("You must select a file before you can run the file.");
				return;
			}
			String viewedTabText = viewedTab.getText();
			String extension;
			try{extension = findExtension(viewedTabText);}catch(NoFileExtensionException e)
			{
				appendText("This file cannot run because it has no file extension.");
				return;
			}
			
			if(extension.equals("java"))
			{
				executeJava((FileTab)viewedTab);
			}
			else if (extension.equals("py"))
			{
				executePython((FileTab)viewedTab);
			}
			else if (extension.equals("c"))
			{
				executePython((FileTab)viewedTab);
			}
			else if (extension.equals("html"))
			{
				executeHTML((FileTab)viewedTab);
			}
			else if (extension.equals("cs"))
			{
				executeCSharp((FileTab)viewedTab);
			}
			else
			{
				appendText("This file has a file extension of ." + extension + ". This extension is either invalid or not supported. The supported file extensions are .java, .py, .c, .html, .cs");
				return;
			}
			//appendText("OKAY?");
			//appendText("OKAY?");
		}).start();
	}
	public String findExtension(String viewedTabText) throws NoFileExtensionException
	{
		int indexOfDot = viewedTabText.indexOf(".");
		if(indexOfDot == -1)throw new NoFileExtensionException();
		return viewedTabText.substring(indexOfDot + 1);
	}
	public static class NoFileExtensionException extends Exception{}
	public static class InvalidFileExtensionException extends Exception
	{
		public final String badExtension;
		public InvalidFileExtensionException(String badExtension)
		{
			this.badExtension = badExtension;
		}
	}
	private void executeHTML(FileTab viewedTab)
	{
		try
		{
			Desktop.getDesktop().browse(new URI(viewedTab.getPath().replace("\\","/")));
		}catch(Exception e){e.printStackTrace();}
	}
	private void executeC(FileTab viewedTab)
	{
		try
		{
			Runtime.getRuntime().exec("cmd del a.out",new String[0],new File(extractPath(viewedTab.getPath())));
			
			Process processCompile = Runtime.getRuntime().exec("gcc " + viewedTab.getPath());//https://stackoverflow.com/questions/12744253/how-to-call-a-java-program-from-another-java-program
			BufferedReader compileOutput = new BufferedReader(new InputStreamReader(processCompile.getErrorStream()));
			boolean error = false;
			RunTab rt = gui.getFileBar().viewNewRunTab(viewedTab.getText() + " COMPILE",processCompile);
			new Thread(()->
			{
				try
				{
					BufferedReader output = new BufferedReader(new InputStreamReader(processCompile.getInputStream()));
					String line;
					while((line = output.readLine()) != null)
					{
						synchronized(processCompile)
						{
							rt.appendText(line+"\n");
						}
					}
				}catch(Exception ex){ex.printStackTrace();}
			}).start();
			
			try
			{
				BufferedReader output = new BufferedReader(new InputStreamReader(processCompile.getErrorStream()));
				String line;
				while((line = output.readLine()) != null)
				{
					synchronized(processCompile)
					{
						error = true;
						rt.appendText(line+"\n");
					}
				}
			}catch(Exception ex){ex.printStackTrace();}
			
			
			if(error)
				return;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		try
		{
			Process processRun = Runtime.getRuntime().exec("a.out", new String[0], new File(extractPath(viewedTab.getPath())));
			
			RunTab rt = gui.getFileBar().viewNewRunTab(viewedTab.getText() + " RUN",processRun);
			
			new Thread(()->
			{
				try
				{
					BufferedReader output = new BufferedReader(new InputStreamReader(processRun.getInputStream()));
					String line;
					while((line = output.readLine()) != null)
					{
						synchronized(processRun)
						{
							rt.appendText(line+"\n");
						}
					}
				}catch(Exception ex){ex.printStackTrace();}
			}).start();
			new Thread(()->
			{
				try
				{
					BufferedReader output = new BufferedReader(new InputStreamReader(processRun.getErrorStream()));
					String line;
					while((line = output.readLine()) != null)
					{
						synchronized(processRun)
						{
							rt.appendText(line+"\n");
						}
					}
				}catch(Exception ex){ex.printStackTrace();}
			}).start();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
	private void executeCSharp(FileTab viewedTab)
	{
		try
		{
			//Runtime.getRuntime().exec("cmd del *.class /s",new String[0],new File(extractPath(viewedTab.getPath())));
			
			Process processCompile = Runtime.getRuntime().exec("csc " + viewedTab.getPath());//https://stackoverflow.com/questions/12744253/how-to-call-a-java-program-from-another-java-program
			BufferedReader compileOutput = new BufferedReader(new InputStreamReader(processCompile.getErrorStream()));
			boolean error = false;
			RunTab rt = gui.getFileBar().viewNewRunTab(viewedTab.getText() + " COMPILE",processCompile);
			new Thread(()->
			{
				try
				{
					BufferedReader output = new BufferedReader(new InputStreamReader(processCompile.getInputStream()));
					String line;
					while((line = output.readLine()) != null)
					{
						synchronized(processCompile)
						{
							rt.appendText(line+"\n");
						}
					}
				}catch(Exception ex){ex.printStackTrace();}
			}).start();
			
			try
			{
				BufferedReader output = new BufferedReader(new InputStreamReader(processCompile.getErrorStream()));
				String line;
				while((line = output.readLine()) != null)
				{
					synchronized(processCompile)
					{
						error = true;
						rt.appendText(line+"\n");
					}
				}
			}catch(Exception ex){ex.printStackTrace();}
			
			
			if(error)
				return;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		try
		{
			Process processRun = Runtime.getRuntime().exec(viewedTab.getText().substring(0,viewedTab.getText().length() - 3), new String[0], new File(extractPath(viewedTab.getPath())));
			
			RunTab rt = gui.getFileBar().viewNewRunTab(viewedTab.getText() + " RUN",processRun);
			
			new Thread(()->
			{
				try
				{
					BufferedReader output = new BufferedReader(new InputStreamReader(processRun.getInputStream()));
					String line;
					while((line = output.readLine()) != null)
					{
						synchronized(processRun)
						{
							rt.appendText(line+"\n");
						}
					}
				}catch(Exception ex){ex.printStackTrace();}
			}).start();
			new Thread(()->
			{
				try
				{
					BufferedReader output = new BufferedReader(new InputStreamReader(processRun.getErrorStream()));
					String line;
					while((line = output.readLine()) != null)
					{
						synchronized(processRun)
						{
							rt.appendText(line+"\n");
						}
					}
				}catch(Exception ex){ex.printStackTrace();}
			}).start();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	private void executeJava(FileTab viewedTab)
	{
		try
		{
			Runtime.getRuntime().exec("cmd del *.class /s",new String[0],new File(extractPath(viewedTab.getPath())));
			
			Process processCompile = Runtime.getRuntime().exec("javac " + viewedTab.getPath());//https://stackoverflow.com/questions/12744253/how-to-call-a-java-program-from-another-java-program
			BufferedReader compileOutput = new BufferedReader(new InputStreamReader(processCompile.getErrorStream()));
			boolean error = false;
			RunTab rt = gui.getFileBar().viewNewRunTab(viewedTab.getText() + " COMPILE",processCompile);
			new Thread(()->
			{
				try
				{
					BufferedReader output = new BufferedReader(new InputStreamReader(processCompile.getInputStream()));
					String line;
					while((line = output.readLine()) != null)
					{
						synchronized(processCompile)
						{
							rt.appendText(line+"\n");
						}
					}
				}catch(Exception ex){ex.printStackTrace();}
			}).start();
			
			try
			{
				BufferedReader output = new BufferedReader(new InputStreamReader(processCompile.getErrorStream()));
				String line;
				while((line = output.readLine()) != null)
				{
					synchronized(processCompile)
					{
						error = true;
						rt.appendText(line+"\n");
					}
				}
			}catch(Exception ex){ex.printStackTrace();}
			
			
			if(error)
				return;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		try
		{
			Process processRun = Runtime.getRuntime().exec("java " + viewedTab.getText().substring(0,viewedTab.getText().length() - 5), new String[0], new File(extractPath(viewedTab.getPath())));
			
			RunTab rt = gui.getFileBar().viewNewRunTab(viewedTab.getText() + " RUN",processRun);
			
			new Thread(()->
			{
				try
				{
					BufferedReader output = new BufferedReader(new InputStreamReader(processRun.getInputStream()));
					String line;
					while((line = output.readLine()) != null)
					{
						synchronized(processRun)
						{
							rt.appendText(line+"\n");
						}
					}
				}catch(Exception ex){ex.printStackTrace();}
			}).start();
			new Thread(()->
			{
				try
				{
					BufferedReader output = new BufferedReader(new InputStreamReader(processRun.getErrorStream()));
					String line;
					while((line = output.readLine()) != null)
					{
						synchronized(processRun)
						{
							rt.appendText(line+"\n");
						}
					}
				}catch(Exception ex){ex.printStackTrace();}
			}).start();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
	private void executePython(FileTab viewedTab)
	{
		
		try
		{
			Process processRun = Runtime.getRuntime().exec("python " + viewedTab.getText(), new String[0], new File(extractPath(viewedTab.getPath())));
			
			RunTab rt = gui.getFileBar().viewNewRunTab(viewedTab.getText() + " RUN",processRun);
			
			new Thread(()->
			{
				try
				{
					BufferedReader output = new BufferedReader(new InputStreamReader(processRun.getInputStream()));
					String line;
					while((line = output.readLine()) != null)
					{
						synchronized(processRun)
						{
							rt.appendText(line+"\n");
						}
					}
				}catch(Exception ex){ex.printStackTrace();}
			}).start();
			new Thread(()->
			{
				try
				{
					BufferedReader output = new BufferedReader(new InputStreamReader(processRun.getErrorStream()));
					String line;
					while((line = output.readLine()) != null)
					{
						synchronized(processRun)
						{
							rt.appendText(line+"\n");
						}
					}
				}catch(Exception ex){ex.printStackTrace();}
			}).start();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
	public void appendText(String text)
	{
		gui.getTextArea().setText(gui.getTextArea().getText() + text);
	}
	public String extractPath(String pathToFile)
	{
		int lastIndexOfBackslash = pathToFile.lastIndexOf("\\");
		if(lastIndexOfBackslash == -1)
		{
			return "\\";
		}
		else if(lastIndexOfBackslash == pathToFile.length() - 1)
		{
			return extractPath(pathToFile.substring(0,pathToFile.length() - 1));
		}
		else
		{
			return pathToFile.substring(0,lastIndexOfBackslash);
		}
	}
}