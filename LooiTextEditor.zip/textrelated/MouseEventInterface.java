package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.awt.Point;

/*
Defines the interface that is used to execute mouse events
*/
public interface MouseEventInterface
{
    int getButton();
    int getClickCount();
    Point getPoint();
    
    /*
    creates a new mouse event to help trick the computer into thinking that you actually have clicked the mouse
    */
    public static MouseEventInterface NEW(int button, int clickCount, Point point)
    {
        return new MouseEventInterface()
        {
            public int getButton(){return button;}
            public int getClickCount(){return clickCount;}
            public Point getPoint(){return point;}
        };
    }
}