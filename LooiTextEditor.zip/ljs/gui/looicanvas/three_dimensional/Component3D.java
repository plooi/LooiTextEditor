/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;

import java.awt.Color;
import java.io.Serializable;

/**
 *
 * @author peter_000
 */
public interface Component3D extends Serializable
{
    public void activate();
    public void deactivate();
    public void delete();
    public Point3D getCenter();
    public Color getColor();
}
