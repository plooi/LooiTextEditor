"""

\\"""
print("HI")
