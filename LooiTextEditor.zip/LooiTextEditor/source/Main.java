import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JFrame;
import javax.swing.JFileChooser;
import java.io.File;
import looitexteditorgui.Gui;

public class Main
{
	public static void main(String[] args)
	{
		new Gui(80,100);
	}
}