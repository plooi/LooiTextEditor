package textrelated;
import java.util.ArrayList;
/*
This is exactly the same as ArrayList<String> except
it can only hold a limited amount of data before it 
starts throwing away stuff.

Do not add or remove using any method other than add and remove!!!
*/
public class LimitedStringList extends ArrayList<String>
{
    protected int maxDataHold;
    protected int numData;
    public LimitedStringList()
    {
        initLimitedStringList();
    }
    public void initLimitedStringList()
    {
        maxDataHold = 250;
    }
    public boolean add(String s)
    {
        numData++;
        if(numData > maxDataHold)
        {
            remove(0);
        }
        return super.add(s);
    }
    public String remove(int i)
    {
        numData--;
        return super.remove(i);
    }
    public int getMaxDataHold(){return maxDataHold;}
    public void setMaxDataHold(int i){maxDataHold = i;}
}