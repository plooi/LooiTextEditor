package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.lang.Process;
import java.lang.Runtime;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import static textrelated.Util.*;
/*
Take the result and parse it and then pull the right strings in the TextBoxMethods class

Yes, the Parser actually gets to pull the strings
because the parser does hard work, it should get rewarded with some power. 

BTW programmer, parser's take method takes strings that still have the newlines
switched to the NEWLINE_REPLACE and method calls separated by DATA_SEP. Just
to let you know.
*/
public class Parser
{
    //INTERFACE
    public static char COMMAND_SEP = Interface.DATA_SEP;//what sparates between the commands 
    public static char ARG_SEP = (char)30; //what separates between the arguments
    public static final char NEWLINE_REPLACE = (char)(29);
    
    
    public ArrayList<String> take(String result){return _take(result);}
    
    //END INTERFACE
    
    
    
    protected Gui gui;
    protected TextBoxMethods tbm;
    
    public Parser(Gui gui, TextBoxMethods tbm)
    {
        init(gui, tbm);
    }
    public void init(Gui gui, TextBoxMethods tbm)
    {
        this.gui = gui;
        this.tbm = tbm;
    }
    public ArrayList<String> _take(String result)//TASK
    {
        ArrayList<ArrayList<String>> commandsSplit = parse(result);
        ArrayList<String> returnsIfAny = new ArrayList<>();
        try
        {
            for(ArrayList<String> command : commandsSplit)//for each command, do it. I shouldn't. DO IT! shhhhhhhyyyooooff. That's not the jedi way. It was only natural...
            {
                String thereturn = DO(command);
                if(thereturn != null)
                    returnsIfAny.add(result);
            }
            if(returnsIfAny.size() > 0)
                return returnsIfAny;
            else
                return null;
                
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }
    /*
    This method just jumps in without seatbelts and tries to
    execute the command. If it fails, it will throw the 
    corresponding runtime exception. That is why you should
    probably put all calls to the DO method inside try catch
    blocks.
    */
    public String DO(ArrayList<String> command)
    {
        String methodName = command.get(0);
        int index;
        switch(methodName)
        {
            case "indexOfLastNewLine":
                index = tbm.indexOfLastNewLine(Int(command.get(1)));
                return index+"";
            case "indexOfNextNewLine":
                index = tbm.indexOfNextNewLine(Int(command.get(1)));
                return index+"";
            case "nextSpace":
                index = tbm.nextSpace(Int(command.get(1)));
                return index+"";
            case "previousSpace":
                index = tbm.previousSpace(Int(command.get(1)));
                return index+"";
            case "upDownIndex":
                return tbm.upDownIndex(Int(command.get(1)), Boolean.parseBoolean(command.get(2)), Int(command.get(3))) +"";
            case "getIndent":
                return tbm.getIndent(Int(command.get(1))) + "";
            case "substring":
                return tbm.substring(Int(command.get(1)), Int(command.get(2)));
            
            //everything above is TASK
            
            case "insertText":
                tbm.insertText(normalString(command.get(2)), Int(command.get(1)));
                break;
            case "type":
                tbm.type(normalString(command.get(1)));
                break;
            case "setText":
                tbm.setText(normalString(command.get(1)));
                break;
            /*case "setTextHTML":
                tbm.setTextHTML(normalString(command.get(1)));
                break;*/
            case "setCaretPosition":
                tbm.setCaretPosition(Int(command.get(1)));
                break;
            case "setCaretPositionAsFarAsPossible":
                tbm.setCaretPositionAsFarAsPossible(Int(command.get(1)));
                break;
            case "donothing":
                break;
            case "del":
                tbm.del(Int(command.get(1)), Int(command.get(2)));
                break;
            case "replaceRange":
                tbm.replaceRange(Int(command.get(1)), Int(command.get(2)), normalString(command.get(3)));
                break;
            case "select":
                tbm.select(Int(command.get(1)), Int(command.get(2)));
                break;
            case "selectAsFarAsPossible":
                tbm.selectAsFarAsPossible(Int(command.get(1)), Int(command.get(2)));
                break;
            case "moveCaretPositionAsFarAsPossible":
                tbm.moveCaretPositionAsFarAsPossible(Int(command.get(1)));
                break;
            case "print":
                p(normalString(command.get(1)));
            default:
                throw new RuntimeException("Unsupported operation: " + methodName);
                
        }
        return null;
    }
    /*
    Returns an arraylist of commands. Each command is an array list where the 
    first element is the name of the method and each element after that is the
    arguments that should be put into the method.
    */
    public ArrayList<ArrayList<String>> parse(String result)
    {
        //p("RESULT: " + result);
        ArrayList<String> commandsAsStrings = split(result, "" + COMMAND_SEP);
        ArrayList<ArrayList<String>> commandsSplit = new ArrayList<>();
        for(String command : commandsAsStrings)
        {
            ArrayList<String> theSplitCommand = split(command, "" + ARG_SEP);
            commandsSplit.add(theSplitCommand);
        }
        return commandsSplit;
        
    }
    
    /*
    When I get a string, it will have many replacement characters.
    The replacement character that I have implemented right now is 
    the NEWLINE_REPLACE to replace new lines so that I only need 
    to worry about reading in one real line.
    This method takes characters such as NEWLINE_REPLACE and replaces
    them back to \n.
    */
    public String normalString(String codeString)
    {
        codeString = codeString.replace(NEWLINE_REPLACE, '\n');
        return codeString;
    }
    
    
    
    
    
    
    
    
    
    
}