/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.three_dimensional;
import java.awt.Color;
import java.util.ArrayList;
import ljs.gui.looicanvas.LooiObject;
import ljs.gui.looicanvas.LooiCanvas;
import ljs.gui.looicanvas.utilities.Supplier;

/**
 *
 * @author peter_000
 */
public class BlurrableObject3D extends LooiObject implements Component3D
{
    public static final Color TRANSPARENT_COLOR = new Color(0,0,0,0);
    private ArrayList<BlurLayer> layers = new ArrayList<>();
    private Supplier<View> view;
    private Point3D center = new Point3D(0,0,0);
    private boolean initialize = true;
    public BlurrableObject3D(Supplier<View> view)
    {
        super(LooiCanvas.getMainCanvas(),false);
        this.view = view;
        
    }
    public Supplier<View> getView()
    {
        return view;
    }
    public void setView(Supplier<View> view)
    {
        this.view = view;
    }
    public BlurLayer getBlurLayer(int index)
    {
        return layers.get(index);
    }
    public int getNumBlurLayers(){return layers.size();}
    public BlurLayer addBlurLayer(BlurLayer l)
    {
        layers.add(l);
        return l;
    }
    protected void looiStep()
    {
        if(initialize)
        {
            center = findCenter();
            initialize = false;
        }
        for(BlurLayer b : layers)
        {
            b.showOrHide();
        }
    }
    protected boolean needToInitialize()
    {
        return initialize;
    }
    public void activate()
    {
        super.activate();
    }
    
    public void deactivate()
    {
        super.deactivate();
        for(BlurLayer b : layers)
        {
            b.hide();
        }
    }
    protected Point3D findCenter()
    {
        double sumX = 0;
        double sumY = 0;
        double sumZ = 0;
        int totalPolygons = 0;
        for(BlurLayer b : layers)
        {
            for(LooiObject l : b)
            {
                if(l instanceof Component3D)
                {
                    Component3D c = (Component3D)l;
                    sumX += c.getCenter().getX();
                    sumY += c.getCenter().getY();
                    sumZ += c.getCenter().getZ();
                }
                
            }
            totalPolygons += b.size();
        }
        
        double avgX = sumX / totalPolygons;
        double avgY = sumY / totalPolygons;
        double avgZ = sumZ / totalPolygons;
        return new Point3D(avgX,avgY,avgZ);
    }
    public void delete()
    {
        super.delete();
        for(BlurLayer b : layers)
        {
            for(LooiObject l : b)
            {
                l.delete();
            }
        }
    }

    @Override
    public Point3D getCenter() 
    {
        return center;
    }
    public Color findAverageColor()
    {
        
        int totalR = 0;
        int totalG = 0;
        int totalB = 0;
        int totalQuadrilaterals = 0;
        for(BlurLayer bl : layers)
            {
                for(LooiObject l : bl)
                {
                    if(l instanceof Component3D)
                    {
                        Component3D c = (Component3D)l;
                        totalR += c.getColor().getRed();
                        totalG += c.getColor().getGreen();
                        totalB += c.getColor().getBlue();
                        totalQuadrilaterals++;
                    }
                    
                }
            }
        if(totalQuadrilaterals == 0)
            {
                return TRANSPARENT_COLOR;
            }
        int avgR = totalR / totalQuadrilaterals;
        int avgG = totalG / totalQuadrilaterals;
        int avgB = totalB / totalQuadrilaterals;
        return new Color(avgR,avgG,avgB);
    }
    
    public Color findAverageColorExcludingLayers(BlurLayer...exclude)
    {
        int totalR = 0;
        int totalG = 0;
        int totalB = 0;
        int totalQuadrilaterals = 0;
        layersIteration:
        for(int i = 0; i < layers.size(); i++)
            {
                
                BlurLayer bl = layers.get(i);
                for(BlurLayer check : exclude)
                {
                    if(bl == check)
                    {
                        continue layersIteration;
                    }
                }
                for(LooiObject l : bl)
                {
                    if(l instanceof Component3D)
                    {
                        Component3D c = (Component3D)l;
                        totalR += c.getColor().getRed();
                        totalG += c.getColor().getGreen();
                        totalB += c.getColor().getBlue();
                        totalQuadrilaterals++;
                    }
                    
                }
            }
        if(totalQuadrilaterals == 0)
            {
                return TRANSPARENT_COLOR;
            }
        int avgR = totalR / totalQuadrilaterals;
        int avgG = totalG / totalQuadrilaterals;
        int avgB = totalB / totalQuadrilaterals;
        return new Color(avgR,avgG,avgB);
    }
    public Color getColor()
    {
        return findAverageColor();
    }

}
