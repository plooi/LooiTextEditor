package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.io.File;
import state.*;
import textrelated.*;
import javax.swing.JScrollPane;
import java.awt.Point;

/*
This is the button that you press to select a file
that has already been loaded.

The FileButton is responsible for 
    loading the file's text into the text box
    saving the text box's text periodically
*/
public class FileButton extends RightClickButton
{
    //INTERFACE
    public void set(double x, double y, double w, double h)
    {
        setPosition(x, y);
        setDimensions(w, h);
    }
    public void setFile(File f)
    {
        myFile = f;
        changeTracker = new ChangeTracker(loadTextFile());
    }
    public File getFile(){return myFile;}
    public void addChange(String text){changeTracker.addChange(text);}
    public String getUndo(){return changeTracker.getUndo();}
    public String getRedo(){return changeTracker.getRedo();}
    public boolean getCanSaveViewPosition(){return canSaveViewPosition;}
    public void setCanSaveViewPosition(boolean b){canSaveViewPosition = b;}
    //END INTERFACE
    protected Gui gui;
    protected File myFile;
    protected boolean selected = false;
    protected ChangeTracker changeTracker;
    protected int fileX, fileY;//file window position saving
    protected boolean canSaveViewPosition = true;
    
    public FileButton(Gui gui, Background bg)
    {
        super(bg);
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
    }
    public void action()
    {
        if(!getFile().exists())
        {
            delete();
            return;
        }
        try
        {
            String text = loadTextFile();
            ((FileSelectionState)gui.getGuiStateManager().states().get("fileSelectionState")).setSelectedButton(this);
            gui.getTextBoxModifier().getMethods().setText(text);
            gui.getTextBoxModifier().getMethods().refresh();
            previousText = text;
            
            styleFileStuff();
            
            viewSavingStuff();
            
            windowStuff();
            
        }
        catch(Exception e)
        {
            //System.out.println("Bad");
        }
        
    }
    public void windowStuff()
    {
        WindowModifier.it.changeTitleFor(myFile.getName());
    }
    public void styleFileStuff()
    {
        StyleManager.it.setStyleDoc(myFile);
    }
    public void viewSavingStuff()
    {
        ((JScrollPane)gui.getTextBox().getJavaComponent()).getViewport().setViewPosition(new Point(fileX, fileY));
        sleep(.06);//THis sleeping is to help with large files, which take a long time just to load into the text box, and it takes a long time for the text box to grow to the proper size
        ((JScrollPane)gui.getTextBox().getJavaComponent()).getViewport().setViewPosition(new Point(fileX, fileY));
    }
    
    public String loadTextFile()
    {
        String[] textOfFile = loadText(myFile.getAbsolutePath());
        StringBuilder sb = new StringBuilder();
        for(String line : textOfFile)
        {
            sb.append(line);
            sb.append("\n");
        }
        return sb.toString();
    }
    public void select()
    {
        selected = true;
        
    }
    public void deselect()
    {
        selected = false;
    }
    
    public void looiStep()
    {
        super.looiStep();
        
        
        saving();
    }
    protected String previousText;
    public void saving()
    {
        String textNow = gui.getTextBoxModifier().getMethods().getText();
        if(selected && textNow != null && !textNow.equals(previousText))
        {
            //p("saving " + myFile);
            save(textNow);
            previousText = textNow;
            
        }
        if(selected && canSaveViewPosition)
        {
            Point p = ((JScrollPane)gui.getTextBox().getJavaComponent()).getViewport().getViewPosition();
            fileX = (int)p.getX();
            fileY = (int)p.getY();
        }
    }
    public void save(String toSave)
    {
        Object[] lines = splitLines(toSave);
        saveText(myFile.getAbsolutePath(), lines);
    }
    public Object[] splitLines(String toSplit)
    {
        ArrayList<String> theSplits = new ArrayList<>();
        
        int lastNewLine = -1;
        int i = 0;
        while(i < toSplit.length()+1)
        {
            if(i==toSplit.length() || toSplit.charAt(i) == '\n')
            {
                theSplits.add(toSplit.substring(lastNewLine+1, i));
                lastNewLine = i;
            }
            i++;
        }
        Object[] ret = new Object[theSplits.size()];
        for(i = 0; i < theSplits.size(); i++)
        {
            ret[i] = theSplits.get(i);
        }
        return ret;
    }
    public void rightClick()
    {
        FileButtonPopupMenu fbpm = ((FileSelectionState)gui.getGuiStateManager().states().get("fileSelectionState")).getPopupMenu();
        fbpm.activateOpen(this);
    }
    public void delete()
    {
        if(selected)
        {
            gui.getTextBoxModifier().getMethods().setText("");
            FileSelectionState.it.setSelectedButton(null);
        }
        ((FileSelectionState)gui.getGuiStateManager().states().get("fileSelectionState")).getFileTabHolder().close(myFile);
        super.delete();
    }
}
