package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.lang.Process;
import java.lang.Runtime;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import static textrelated.Util.*;
import guibarelem.FileButton;
import javax.swing.text.DefaultHighlighter;
import java.awt.Color;

//plitgetWordAt
/*roblem
The job of this class is to have all the methods that can run on the text box like
    refresh colors
    insert text
    copy
    paste
    all that stuff.
*/
public class TextBoxMethods
{
    //INTERFACE
    
    public static TextBoxMethods it;
    
    /*
    TEXT CHANGING METHODS
    
    these methods take normal text, not html code.
    
    In order to actually change the text on the screen, you must actually call refresh after you've done the text-changing methods
    */
    
    
    //Straight up inserts some text and does nothing else
    public void insertText(String text, int location){_insertText(text, location);}
    
    
    //As if you're typing some text. If you have something selected, it will go away.
    public void type(String text){_type(text);}
    
    //Sets the whole text in the TextPane to what you want
    public void setText(String text){_setText(text);}
    
    
    
    public void del(int start, int end){_replaceRange(start, end, "");}
    
    
    public void replaceRange(int start, int end, String replace){_replaceRange(start, end, replace);}
    
    public void undo()
    {
        FileButton fb = ((FileSelectionState)gui.getGuiStateManager().states().get("fileSelectionState")).getSelectedButton();
        if(fb != null)
            mtb.setText(fb.getUndo());
    }
    public void redo()
    {
        FileButton fb = ((FileSelectionState)gui.getGuiStateManager().states().get("fileSelectionState")).getSelectedButton();
        if(fb != null)
            mtb.setText(fb.getRedo());
    }
    
    //call this method if you want to update the colors
    public void refresh(){_refresh();}
    
    
    
    //These below are not text changing methods-------------------------------------------------
    public void setGuiBarMode(int mode)
    {
        gui.getGBMM().switchToMode(mode);
    }
    public void toggleGuiBarSize()
    {
        int mode = gui.getGBMM().getMode();
        if(mode == 1)mode = 2;
        else mode = 1;
        gui.getGBMM().switchToMode(mode);
    }
    public void setEditable(boolean b){mtb.setEditable(b);}
    public void setCaretPosition(int i){mtb.setCaretPosition(i);}
    public void setCaretPositionAsFarAsPossible(int i)
    {
        if(i < 0) i = 0;
        if(i > mtb.getTextLength())
            i= mtb.getTextLength();
        setCaretPosition(i);
    }
    public void select(int i, int j){mtb.setSelectionStart(i);mtb.setSelectionEnd(j);}
    public void selectAsFarAsPossible(int i, int j)
    {
        if(j < i)
            j = i;
        mtb.setSelectionStart(Math.max(i, 0));
        mtb.setSelectionEnd(Math.min(j, mtb.getTextLength()));
    }
    
    public void moveCaretPositionAsFarAsPossible(int i)
    {
        mtb.moveCaretPosition(Math.min(Math.max(i, 0), mtb.getTextLength()));
    }
    public void copy(){mtb.copy();}
    public void paste(){mtb.paste();}
    
    
    public void highlightAsFarAsPossible(int start, int end)
    {
        try
        {
            DefaultHighlighter.DefaultHighlightPainter highlighter = new DefaultHighlighter.DefaultHighlightPainter(getSpecialColor("highlight"));
            mtb.getPane().getHighlighter().addHighlight(start, end, highlighter);
        }
        catch(Exception e){}
    }
    public void clearHighlights()
    {
        try
        {
            mtb.getPane().getHighlighter().removeAllHighlights();
        }
        catch(Exception e){}
    }
    public void setBackgroundColor(Color c)
    {
        mtb.getPane().setBackground(c);
    }
    public void setCaretColor(Color c)
    {
        mtb.getPane().setCaretColor(c);
    }
    public void setFontSize(int i){gui.getTextBoxModifier().setFontSize(i);}
    
    //These below are return methods----------------------------------------------
    
    public int getCursorLineNumber()
    {
        int caretLoc = getCaretPosition();
        int lineNumber = 1;
        String text = getText();
        for(int i = 0; i < caretLoc; i++)
        {
            if(text.charAt(i) == '\n')
            {
                lineNumber++;
            }
        }
        return lineNumber;
    }
    public int getNumLines()
    {
        int lineNumber = 1;
        String text = getText();
        int end = text.length();
        for(int i = 0; i < end; i++)
        {
            if(text.charAt(i) == '\n')
            {
                lineNumber++;
            }
        }
        return lineNumber;
    }
    public int getFontSize(){return gui.getTextBoxModifier().getFontSize();}
    public String getWordAt(int loc){return _getWordAt(loc);}
    /*
    specialColor can be "highlight" or "background"
    */
    public Color getSpecialColor(String specialColor)
    {
        Color c = StyleManager.it.getPatternColors().get(specialColor);
        if(c == null)
            c = StyleManager.it.getPatternColors().get("default");
        return c;
    }
    
    public int getSelectionStart(){return mtb.getSelectionStart();}
    public int getSelectionEnd(){return mtb.getSelectionEnd();}
    public void setSelectionStart(int i){mtb.setSelectionStart(i);}
    public void setSelectionEnd(int i){mtb.setSelectionEnd(i);}
    
    //if \n is at startSearch, it will just return startSearch
    //returns -1 if there is none
    public int indexOfNextNewLine(int startSearch){return _indexOfNextNewLine(startSearch);}
    
    
    
    //if \n is at startSearch, it will NOT just return startSearch
    //returns -1 if there is none
    public int indexOfLastNewLine(int startSearch){return _indexOfLastNewLine(startSearch);}
    
    
    
    //returns the index of the next space. If there is none, then it returns the length of the text
    //I call it a space, but really I'm looking for the next non alphanumeric character
    public int nextSpace(int start, boolean skipAdjacentSpaces){return _nextSpace(start, skipAdjacentSpaces);}
    
    
    //returns the index of the previous space. If there is none, then it returns -1
    //I call it a space, but really I'm looking for the next non alphanumeric character
    public int previousSpace(int start, boolean skipAdjacentSpaces){return _previousSpace(start, skipAdjacentSpaces);}
    
    
    public int upDownIndex(int start, boolean tf_upDown, int lastIndexOverFromNewLine){return _upDownIndex(start, tf_upDown, lastIndexOverFromNewLine);}
    
    //Gets the substring of the displayed text
    public String substring(int s, int e){return _substring(s, e);}
    
    
    //Gets the amount of indent of the line with this index position
    public int getIndent(int index){return _getIndent(index);}
    
    
    public int getCaretPosition(){return mtb.getCaretPosition();}
    
    public int getTextLength(){return mtb.getTextLength();}
    
    public String getText(){return mtb.getText();}
    //END INTERFACE
    
    
    protected Gui gui;
    protected MyTextBox mtb;
    public TextBoxMethods(Gui gui)
    {
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        mtb = gui.getTextBox();
    }
    
    private void _type(String text)
    {
        int oldCaretPosition = mtb.getCaretPosition();
        int oldSelectionStart = mtb.getSelectionStart();
        
        if(mtb.getSelectionStart() != mtb.getSelectionEnd())//There is a selection
        {
            _replaceRange(mtb.getSelectionStart(), mtb.getSelectionEnd(), text);
            setCaretPosition(oldSelectionStart + text.length());
        }
        else
        {
            _insertText(text, mtb.getCaretPosition());
            setCaretPosition(oldCaretPosition + text.length());
        }
        
        
    }
    
    
    
    
    
    
    private void _refresh()
    {
        gui.getTextBoxModifier().getStyleManager().refresh();
    }
    
    private void _setText(String text)
    {
        mtb.setText(text);
        trackChange();
    }
    private void _replaceRange(int start, int end, String replace)
    {
        mtb.replaceRange(start, end, replace);
        trackChange();
    }
    private void _insertText(String text, int location)
    {
        mtb.insertString(text, location);
        trackChange();
    }
    private void trackChange()
    {
        FileButton fb = ((FileSelectionState)gui.getGuiStateManager().states().get("fileSelectionState")).getSelectedButton();
        if(fb != null)
            fb.addChange(getText());
    }
    
    
    
    
    
    /*
    What index will you end up on if you press up or down
    These indicies could be illegal. So watch out for that.
    */
    
    private int _upDownIndex(int start, boolean tf_upDown, int lastIndexOverFromNewLine)
    {
        String text = mtb.getText();
        //in
        int indexOfLastNewLine = indexOfLastNewLine(start);//DONE
        int distanceToLastNewLine = lastIndexOverFromNewLine == -1? start - indexOfLastNewLine : lastIndexOverFromNewLine;
        lastIndexOverFromNewLine = distanceToLastNewLine;//okay i know this doesn't do anything but this was in the original function where it did do something
        
        //saveText("Test.txt", new Object[]{indexOfLastNewLine,Math.random()});
        
        //check if we are on the first or last row... then just do nothing
        if(indexOfLastNewLine == -1 && tf_upDown)
            return start;
        
        if(indexOfNextNewLine(start) == -1 && !tf_upDown)
            return start;
        
        if(tf_upDown)//up arrow key
        {
            //okay the plan is to go to the previous previous newline, and then count up
            int lastLastNL = indexOfLastNewLine(indexOfLastNewLine);
            
            for(int i = lastLastNL + 1; i < text.length(); i++)//now we count up
            {
                if(text.charAt(i) == '\n')
                    return i;
                if(i == lastLastNL + distanceToLastNewLine)
                    return i;
            }
            return start;
        }
        else//down arrow key
        {
            int numNewLinesSeen = 0; //count the number of \n we pass
            int countFromNextNewLine = 0; //number of chars we pass after the next new line
            for(int i = start; i < text.length() +   1 /*this WILL iterate TO the length of the text*/; i++)//step forward until either you meet two new lines, OR until you go to one new line and then distanceToLastNewLine
            {
                if(numNewLinesSeen == 1)
                    countFromNextNewLine++;
                if(i == text.length() || text.charAt(i) == '\n')
                    numNewLinesSeen++;
                if(numNewLinesSeen == 2)//line below us is shorter than our caret's distance away from the left on the previous line
                    return i;
                if(countFromNextNewLine == distanceToLastNewLine)
                    return i;
            }
            return start;
        }
    }
    private int _getIndent(int location)
    {
        
        String text = mtb.getText();
        int i = location-1;
        int numConsecutiveSpaceCharsNextToNewLine = 0;
        while(i >= 0)
        {
            if(text.charAt(i) == '\n')
                break;
            if(Character.isSpaceChar(text.charAt(i)))
            {
                numConsecutiveSpaceCharsNextToNewLine++;
            }
            else if(text.charAt(i) != '\n')
                numConsecutiveSpaceCharsNextToNewLine = 0;
            
            
            i--;
        }
        //p(numConsecutiveSpaceCharsNextToNewLine);
        return numConsecutiveSpaceCharsNextToNewLine;
    }
    private String _substring(int start, int end)
    {
        return mtb.getText().substring(start, end);
    }
    
    private int _indexOfNextNewLine(int startSearch)
    {
        String text = mtb.getText();
        for(int i = startSearch; i < text.length(); i++)
        {
            if(text.charAt(i) == '\n')
                return i;
        }    
        return -1;
    }
    /*
    if \n is at startSearch, it will NOT just return startSearch
    returns -1 if there is none
    */
    private int _indexOfLastNewLine(int startSearch)
    {
        String text = mtb.getText();
        for(int i = startSearch-1; i > -1; i--)
        {
            if(text.charAt(i) == '\n')
            {
                return i;
            }
            
        }
        return -1;
    }
    
    
    /*
    returns the index of the next space. If there is none, then it returns the length of the text
    
     I call it a space, but really I'm looking for the next non alphanumeric character
    */
    private int _nextSpace(int start, boolean skipAdjacentSpaces)
    {
        
        String text = mtb.getText();
        int i = Math.max(start, 0);
        
        if(i >= text.length())return text.length();
        
        
        
        if(skipAdjacentSpaces)
        {
            boolean seenWordChar = false;
            while(i < text.length())
            {
                //p(text.charAt(i));
                if(isWordChar(text.charAt(i))) //it's a part of the word - set seenWordChar to true
                    seenWordChar = true;
                else   //it's not a letter or digit
                {
                    if(!Character.isSpaceChar(text.charAt(i)) && !(text.charAt(i) == '\n'))//it's punctuation
                        return i;
                    if(seenWordChar)//If we've already seen the start of the next word, and we've come across something that's not part of the word, declare that we've found the end of it
                        return i;
                }
                i++;
            }
            return text.length();
        }
        else
        {
            while(i < text.length())
            {
                if(!isWordChar(text.charAt(i))) 
                    return i;
                i++;
            }
            return text.length();
        }
        
    }
    
    /*
    returns the index of the previous space. If there is none, then it returns -1
    
    I call it a space, but really I'm looking for the next non alphanumeric character
    */
    private int _previousSpace(int start, boolean skipAdjacentSpaces)
    {
        String text = mtb.getText();
        int i = Math.max(start, 0);
        
        if(i == 0)return -1;
        
        
        if(skipAdjacentSpaces)
        {
            boolean seenWordChar = false;
            while(i >= 0)
            {
                if(isWordChar(text.charAt(i))) //it's a part of the word - set seenWordChar to true
                    seenWordChar = true;
                else   //it's not a letter or digit
                {
                    if(!Character.isSpaceChar(text.charAt(i)) && !(text.charAt(i) == '\n'))//it's punctuation
                        return i;
                    if(seenWordChar)//If we've already seen the start of the next word, and we've come across something that's not part of the word, declare that we've found the end of it
                        return i;
                }
                i--;
            }
            return -1;
        }
        else
        {
            while(i >= 0)
            {
                if(!isWordChar(text.charAt(i))) 
                    return i;
                i--;
            }
            return text.length();
        }
    }
    protected boolean isWordChar(char c)
    {
        return (Character.isLetterOrDigit(c) || c == '_');
    }
    
    public String _getWordAt(int loc)
    {
        String text = getText();
        require(loc >= 0 && loc <= text.length());
        
        int start = previousSpace(loc-1, false);
        int end = nextSpace(loc, false);
        if(start == end) return " ";
        return text.substring(start+1, end);
        
        /*if(loc == text.length() && text.charAt(loc-1) == ' ')return " ";
        if(loc == 0 && text.charAt(loc) == ' ')return " ";
        if(loc > 0 && loc < text.length() && text.charAt(loc) == ' ' && text.charAt(loc-1) == ' ') return " ";
        
        
        
        return text.substring(previousSpace(loc) + 1, nextSpace(loc));
        */
        /*int startSearchForEndsOfWord;
        if(loc == 0) startSearchForEndsOfWord = 0;
        else if(loc == text.length()) startSearchForEndsOfWord = loc - 1;
        else
        {
            if(!Character.isSpaceChar(text.charAt(loc)))
            {
                startSearchForEndsOfWord = loc;
            }
            else
            {
                startSearchForEndsOfWord = loc-1;
            }
        }
        
        
        int start, end;
        
        //search for end of word
        for(end = startSearchForEndsOfWord; end < text.length(); end++) if(!Character.isLetterOrDigit(text.charAt(end))) break;
        for(start = startSearchForEndsOfWord-1; start >= 0; start--) if(!Character.isLetterOrDigit(text.charAt(start)))break;
        start++;
        if((start == startSearchForEndsOfWord && end == startSearchForEndsOfWord) && startSearchForEndsOfWord != 0 && startSearchForEndsOfWord != text.length()) start--;
        
        //p("start: " + start + " end: " + end + " length: " + text.length());
        return text.substring(start, end);
        */
    }
}
