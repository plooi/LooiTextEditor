package looitexteditorgui;
import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;

public class ScrollManager extends LooiObject
{
	private double clickX;
	private double clickXScroll;
	private LTEFileBar fb;
	public ScrollManager(LTEFileBar fb)
	{
		this.fb = fb;
	}
	protected void looiStep()
	{
		if(mouseLeftPressed())
		{
			clickX = getInternalMouseX();
			clickXScroll = fb.getScrollX();
		}
		if(mouseLeftEngaged())
		{
			fb.setScrollX(clickXScroll - (getInternalMouseX() - clickX));
		}
		if(fb.getScrollX() > fb.getMaxScrollX())
			fb.setScrollX(fb.getMaxScrollX());
		if(fb.getScrollX() < fb.getMinScrollX())
			fb.setScrollX(fb.getMinScrollX());
	}
	
}