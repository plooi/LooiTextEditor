package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;
import state.*;

public class FileButtonPopupMenu extends PopupMenu<FileButton>
{
    protected FlatButton 
        close, 
        move
        ;
    protected Gui gui;
    public FileButtonPopupMenu(Gui gui)
    {
        init2(gui);
    }
    public void init2(Gui gui)
    {
        this.gui = gui;
        setDimensions(260, 100);
        setPosition(20, 0);
        add(close = new FlatButton(0,0,0,0, "Close", Background.LIGHT_GRAY_BACKGROUND)
        {
            public void action()
            {
                getCurrentData().delete();
                FileButtonPopupMenu.this.deactivate();
            }
            
        });
        add(move = new FlatButton(0,0,0,0, "Move to top", Background.LIGHT_GRAY_BACKGROUND)
        {
            public void action()
            {
                FileSelectionState.it.getFileTabHolder().moveToTop(getCurrentData());
                FileButtonPopupMenu.this.deactivate();
            }
            
        });
        add(move = new FlatButton(0,0,0,0, "Browse from here", Background.LIGHT_GRAY_BACKGROUND)
        {
            public void action()
            {
                String thePath = BrowsingFileButtonPopup.removeLastPathElement(getCurrentData().getFile().getAbsolutePath());
                ((BrowseState)gui.getGuiStateManager().states().get("browseState")).getFileBrowser().browse(thePath);
                FileButtonPopupMenu.this.deactivate();
            }
            
        });
    }
}