package state;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.util.HashMap;
import guibarelem.*;
import java.awt.Color;

public class MenuState implements GuiState
{
    protected Gui gui;
    protected TextBox title;
    protected ScrollBoxList buttonList;
    protected HashMap<String, Button> buttonListButtons;
    protected final double leftMarginOnButtonList;
    
    public MenuState(Gui gui)
    {
        leftMarginOnButtonList = 20;
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        buttonListButtons = new HashMap<>();
        title = makeTitle();
        
        
        buttonList = makeButtonList();
        makeButtons();
        
    }
    public void makeButtons()
    {
        makeListButton("Select File", Background.LIGHT_BLUE_BACKGROUND, 0);
        makeListButton("Change Font", Background.LIGHT_BLUE_BACKGROUND, 1);
        makeListButton("Hotkeys", Background.LIGHT_BLUE_BACKGROUND, 2);
        makeListButton("Style File", Background.LIGHT_BLUE_BACKGROUND, 3);
        
    }
    public TextBox makeTitle()
    {
        TextBox ret = new TextBox(10,10,280,60,"   Menu",false);
        ret.setBackground(Background.LIGHT_GRAY_BACKGROUND);
        ret.setFont(new Font("Courier", Font.PLAIN, 38));
        return ret;
    }
    public ScrollBoxList makeButtonList()
    {
        return new ScrollBoxList(10, 100, 280, 500, Background.DARK_GRAY_BACKGROUND)
        {
            {
                setLeftMargin(leftMarginOnButtonList);
            }
            protected ScrollBar createScrollBar()
            {
                return new ScrollBar()
                {
                    public void looiPaint(){}
                };
            }
        };
    }
    public void makeListButton(String text, Background b, int code)
    {
        Button button = makeTheActualListButton(text, b, code);
        buttonListButtons.put(text, button);
        buttonList.add(button);
    }
    public Button makeTheActualListButton(String text, Background b, int code)
    {
        return new Button(0, 0, 240, 50, text, b)
        {
            public void action()
            {
                listButtonAction(code);
            }
        };
    }
    protected void listButtonAction(int code)
    {
        switch(code)
        {
            case 0:
                gui.getGuiStateManager().setState("fileSelectionState");
                break;
            case 1:
                gui.getGuiStateManager().setState("fontSizeState");
                break;
            case 2:
                gui.getGuiStateManager().setState("hotkeyState");
                break;
            case 3:
                gui.getGuiStateManager().setState("styleFileState");
                break;
        }
    }
    public void open(Gui gui, String previousStateName)
    {
        title.activate();
        buttonList.activate();
    }
    public void close(Gui gui, String nextStateName)
    {
        title.deactivate();
        buttonList.deactivate();
    }
}