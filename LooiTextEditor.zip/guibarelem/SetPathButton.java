package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.awt.Color;
import java.io.File;
import javax.swing.JOptionPane;

public class SetPathButton extends FlatButton
{
    protected Gui gui;
    protected FileBrowser fileBrowser;
    public SetPathButton(Gui gui, FileBrowser fileBrowser)
    {
        super(10,80,280,45,"/.../.../...",new Background(new Color(150,150,250)));
        init(gui, fileBrowser);
    }
    public void init(Gui gui, FileBrowser fileBrowser)
    {
        this.gui = gui;
        this.fileBrowser = fileBrowser;
    }
    public void action()
    {
        String path = JOptionPane.showInputDialog(null, "Enter path:", fileBrowser.getCurrentPath());
        if(path != null)
        {
            fileBrowser.openDir(path);
        }
        
    }
    public boolean touchingMouseAndInFront(){return touchingMouse();}
    
    
}