package lte4;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import java.util.ArrayList;

/*
Just manages the size modes of the gui bar
*/
public class GuiBarModeManager
{
    //INTERFACE
    public void switchToMode(int mode)
    {
        if(mode == 1)
            gui.setGuiBarWidth(()->300);
        else if(mode == 2)
            gui.setGuiBarWidth(()->125);
        this.mode = mode;
    }
    public int getMode(){return mode;}
    public GuiBarModeManager(Gui gui)
    {
        init(gui);
    }
    
    //END INTERFACE
    private Gui gui;
    private int mode;
    
    public void init(Gui gui)
    {
        this.gui = gui;
    }
    
    
}
