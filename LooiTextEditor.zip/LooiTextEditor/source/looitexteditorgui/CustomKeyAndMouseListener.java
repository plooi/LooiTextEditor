package looitexteditorgui;
import static ljs.Obj.*;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import javax.swing.JTextArea;
import javax.swing.text.BadLocationException;

//not used
public class CustomKeyAndMouseListener implements KeyListener,MouseListener
{
	private Gui gui;
	private LTETextBox textArea;
	private JTextArea jta;
	private String tab = "    ";
	private boolean shift = false;
	private boolean control = false;
	public boolean controlDown(){return control;}
	public CustomKeyAndMouseListener(Gui gui, LTETextBox textArea)
	{
		this.gui = gui;
		this.textArea = textArea;
		jta = textArea.getJTextArea();
	}
	public void keyPressed(KeyEvent e)
	{
		if(textArea.getMode() == LTETextBox.CODING_MODE)
		{
			if(e.getKeyCode() == KeyEvent.VK_ENTER)
			{
				int lastNewLine = findLastNewLine(jta.getCaretPosition()-1);
				int afterTabs = findNextNonSpaceCharacter(lastNewLine+1);
				String tabsToCopy = jta.getText().substring(lastNewLine+1,Math.min(afterTabs,jta.getCaretPosition()));
				String beforeCaret = jta.getText().substring(0,jta.getCaretPosition());
				String afterCaret = jta.getText().substring(jta.getCaretPosition());
				boolean addingTab = false;
				if(jta.getText().length() > afterTabs && jta.getText().charAt(afterTabs) == '{')
				{
					tabsToCopy += tab;
					addingTab = true;
				}
				p(tabsToCopy.length());
				String newText = beforeCaret + "\n" +tabsToCopy + afterCaret;
				int oldCaretPosition = jta.getCaretPosition();
				int newCaretPosition = oldCaretPosition + 1 + tabsToCopy.length();
				jta.setText(newText);
				try{jta.setCaretPosition(newCaretPosition);}catch(Exception ex){}
				e.consume();
			}
			if(e.getKeyCode() == KeyEvent.VK_TAB)
			{
				if(!shift)
				{
					String beforeCaret = jta.getText().substring(0,jta.getCaretPosition());
					String afterCaret = jta.getText().substring(jta.getCaretPosition());
					String newText = beforeCaret + tab + afterCaret;
					int oldCaretPosition = jta.getCaretPosition();
					int newCaretPosition = oldCaretPosition + tab.length();
					jta.setText(newText);
					try{jta.setCaretPosition(newCaretPosition);}catch(Exception ex){}
				}
				else
				{
					try
					{
						int lastNewLine = findLastNewLine(jta.getCaretPosition()-1);
						if(jta.getText().substring(lastNewLine+1,lastNewLine+5).equals(tab))
						{
							String before = jta.getText().substring(0,lastNewLine+1);
							String after = jta.getText().substring(lastNewLine+5);
							int caretPos = jta.getCaretPosition();
							jta.setText(before+after);
							try{jta.setCaretPosition(lastNewLine+1 > caretPos - tab.length()? lastNewLine+1 : caretPos - tab.length());}catch(Exception ex){}
						}
					}
					catch(StringIndexOutOfBoundsException exc)
					{
						
					}
				}
				e.consume();
			}
			if(e.getKeyCode() == KeyEvent.VK_SHIFT)
			{
				shift = true;
			}
			/*if(e.getKeyCode() == KeyEvent.VK_U)
			{
				if(control)
				{
					gui.getTextArea().getSM().suggest();
					e.consume();
				}
				
			}*/
			
			
			
		}
		if(e.getKeyCode() == KeyEvent.VK_CONTROL)
		{
			control = true;
			gui.getSuggestionTab().setVisible(true);
		}
		if(e.getKeyCode() == KeyEvent.VK_Z)
		{
			if(control)
			{
				undo();
				e.consume();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_Y)
		{
			if(control)
			{
				redo();
				e.consume();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_SPACE)
		{
			if(control)
			{
				int lastCaretLocation = jta.getCaretPosition();
				String text = jta.getText();
				String before = text.substring(0,lastCaretLocation);
				String after = text.substring(lastCaretLocation);
				textArea.setText(before + " " + after);
				jta.setCaretPosition(lastCaretLocation + 1);
				e.consume();
			}
		}
		if(jta.getCaretPosition() != caretLocation)
		{
			lastCaretLocation = caretLocation;
			caretLocation = jta.getCaretPosition();
		}
		
	}
	public void undo()
	{
		gui.getViewedTab().undo();
	}
	public void redo()
	{
		gui.getViewedTab().redo();
	}
	public int findLastNewLine(int index)
    {
        for(int i = index; i >= 0; i--)
        {
            try
            {
                if(jta.getText(i,1).equals("\n"))
                {
                    return i;
                }
            }
            catch(BadLocationException e)
            {
                System.out.println("Impossible");
            }
            
        }
        return -1;
    }
	public int findNextNonSpaceCharacter(int startIndex)
	{
		for(int i = startIndex; i < jta.getText().length(); i++)
		{
			char currentChar = jta.getText().charAt(i);
			if(currentChar != ' ' && currentChar != '\t')
			{
				return i;
			}
		}
		return jta.getText().length();
	}
	public void keyReleased(KeyEvent e)
	{
		if(textArea.getMode() == LTETextBox.CODING_MODE)
		{
			if(e.getKeyCode() == KeyEvent.VK_SHIFT)
			{
				shift = false;
			}
			
		}
		if(e.getKeyCode() == KeyEvent.VK_CONTROL)
		{
			control = false;
			gui.getSuggestionTab().setVisible(false);
		}
		
	}
	private int lastCaretLocation = 0;
	private int caretLocation = 0;
	public void keyTyped(KeyEvent e){}
	public void mouseClicked(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mouseReleased(MouseEvent e)
	{
		/*if(dragging)
		{
			String text = jta.getText();
			String before = text.substring(0,jta.getCaretPosition());
			String after = text.substring(jta.getCaretPosition());
			jta.setText(before + selectedWord + after);
		}
		dragging = false;*/
	}
	public void mousePressed(MouseEvent e)
	{
		synchronized(this)
		{
			lastCaretLocation = caretLocation;
			caretLocation = jta.getCaretPosition();
			if(control)
			{
				String selectedWord = selectedWord(caretLocation);
				String text = jta.getText();
				String before = text.substring(0,lastCaretLocation);
				String after = text.substring(lastCaretLocation);
				jta.setText(before + selectedWord + after);
				jta.setCaretPosition(lastCaretLocation+selectedWord.length());
				caretLocation = lastCaretLocation+selectedWord.length();
				e.consume();
			}
		}
		
	}
	public int previousSpaceToCursor(int cursorLocation)
	{
		String text = jta.getText();
		for(int i = cursorLocation - 1; i >= 0; i--)
		{
			if(!SuggestionMaker.contains(SuggestionMaker.allowed_characters_in_word,text.charAt(i)))
			{
				return i;
			}
		}
		return -1;
	}
	public int nextSpaceToCursor(int cursorLocation)
	{
		String text = jta.getText();
		for(int i = cursorLocation - 1; i < text.length(); i++)
		{
			if(!SuggestionMaker.contains(SuggestionMaker.allowed_characters_in_word,text.charAt(i)))
			{
				return i;
			}
		}
		return text.length();
	}
	public String selectedWord(int caretLocation)
	{
		//p("jta.getText().substring("+(previousSpaceToCursor(caretLocation)+1)+","+nextSpaceToCursor(caretLocation)+")");
		int start = previousSpaceToCursor(caretLocation)+1;
		int end = nextSpaceToCursor(caretLocation);
		if(start >= end)
		{
			if(jta.getText().charAt(end) == ' ' || jta.getText().charAt(end) == '\t' || jta.getText().charAt(end) == '\n' )
			{
				return "";
			}
			else
			{
				return jta.getText().charAt(end)+"";
			}
			
		}
		else return jta.getText().substring(start,end);
	}
}