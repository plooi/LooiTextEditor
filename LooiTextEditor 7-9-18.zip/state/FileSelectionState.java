package state;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import guibarelem.*;
import java.io.File;
public class FileSelectionState implements GuiState
{
    public static FileSelectionState it;
    public FileTabHolder getFileTabHolder(){return fileTabHolder;}
    
    
    
    protected Gui gui;
    protected ReturnButton returnButton;
    protected OpenFileButton openFileButton;
    protected FileTabHolder fileTabHolder;
    protected FileButtonPopupMenu fbpm;
    protected FileButton selectedButton;
    public FileSelectionState(Gui gui)
    {
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        returnButton = new ReturnButton(gui);
        fileTabHolder = new FileTabHolder(gui);
        fileTabHolder.set(10, 100, 280, 550, Background.DARK_GRAY_BACKGROUND);
        openFileButton = new OpenFileButton(gui, fileTabHolder);
        fbpm = new FileButtonPopupMenu(gui);
    }
    public void open(Gui gui, String previousStateName)
    {
        returnButton.activate();
        fileTabHolder.activate();
        openFileButton.activate();
        allowButtonsToSaveLocation(false);
        setEditableAccordingly();
        allowButtonsToSaveLocation(true);
    }
    public void close(Gui gui, String nextStateName)
    {
        returnButton.deactivate();
        fileTabHolder.deactivate();
        openFileButton.deactivate();
        allowButtonsToSaveLocation(false);
        gui.getTextBoxModifier().getMethods().setEditable(false);
        allowButtonsToSaveLocation(true);
    }
    public FileButtonPopupMenu getPopupMenu(){return fbpm;}
    public void setSelectedButton(FileButton f)
    {
        if(selectedButton != null) selectedButton.deselect();
        selectedButton = f;
        if(selectedButton != null) selectedButton.select();
        allowButtonsToSaveLocation(false);
        setEditableAccordingly();
        allowButtonsToSaveLocation(true);
    }
    public void setEditableAccordingly()//btw, setting the textbox's editability causes the text box view to return to the top.
    {
        if(selectedButton != null) 
        {
            gui.getTextBoxModifier().getMethods().setEditable(true);
        }
        if(selectedButton == null)
        {
            gui.getTextBoxModifier().getMethods().setEditable(false);
        }
    }
    public FileButton getSelectedButton()
    {
        return selectedButton;
    }
    public void allowButtonsToSaveLocation(boolean allowOrNot)
    {
        for(File f : fileTabHolder.getOpenFilesAndTheirButtons().keySet())
        {
            fileTabHolder.getFileButton(f).setCanSaveViewPosition(allowOrNot);
        }
    }
}
