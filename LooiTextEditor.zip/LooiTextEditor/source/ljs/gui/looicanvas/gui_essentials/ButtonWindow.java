/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ljs.gui.looicanvas.gui_essentials;

import ljs.gui.looicanvas.LooiCanvas;
import ljs.gui.looicanvas.utilities.InputAction;

/**
 *
 * @author peter_000
 */
public class ButtonWindow extends Window
{
    public static final double 
            DEFAULT_X_POS_PERCENTAGE = 30,
            DEFAULT_Y_POS_PERCENTAGE = 35,
            DEFAULT_WIDTH_PERCENTAGE = 40,
            DEFAULT_HEIGHT_PERCENTAGE = 30,
            DEFAULT_BUTTON_WIDTH = 100,
            DEFAULT_BUTTON_HEIGHT = 50;
    public static final Background 
            DEFAULT_BACKGROUND = Background.WHITE_BACKGROUND,
            DEFAULT_BUTTON_BACKGROUND = Background.WHITE_BACKGROUND;
    
    
    private Button[] buttons;
    public ButtonWindow(String[] buttonTexts, InputAction<ButtonWindow>[] actions)
    {
        super(DEFAULT_X_POS_PERCENTAGE * LooiCanvas.getMainCanvas().getInternalWidth() / 100,
                DEFAULT_Y_POS_PERCENTAGE * LooiCanvas.getMainCanvas().getInternalHeight() / 100,
                DEFAULT_WIDTH_PERCENTAGE * LooiCanvas.getMainCanvas().getInternalWidth() / 100,
                DEFAULT_HEIGHT_PERCENTAGE * LooiCanvas.getMainCanvas().getInternalHeight() / 100,
                DEFAULT_BACKGROUND);
        
        if(buttonTexts.length != actions.length)
        {
            throw new RuntimeException("Button texts and actions must have the same length");
        }
        buttons = new Button[buttonTexts.length];
        double distanceBetweenButtonCenters = getWidth() / (buttons.length + 1);
        for(int i = 0; i < buttonTexts.length; i++)
        {
            InputAction<ButtonWindow> theAction = actions[i];
            buttons[i] = new Button((distanceBetweenButtonCenters * (i + 1)) - DEFAULT_BUTTON_WIDTH/2,getHeight() - DEFAULT_BUTTON_HEIGHT - 10,DEFAULT_BUTTON_WIDTH,DEFAULT_BUTTON_HEIGHT,buttonTexts[i],DEFAULT_BUTTON_BACKGROUND)
            {
                protected void action()
                {
                    theAction.act(ButtonWindow.this);
                }
                public void looiStep()
                {
                    super.looiStep();
                }
            };
        }
        for(Button b : buttons)
        {
            add(b);
        }
    }
    public Button[] getButtons(){return buttons;}
}
