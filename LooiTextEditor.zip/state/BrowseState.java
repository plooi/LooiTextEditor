package state;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import guibarelem.*;

public class BrowseState implements GuiState
{
    protected Gui gui;
    protected ReturnButton returnButton;
    protected FileBrowser fileBrowser;
    protected UpDirectoryBtn upDirectoryBtn;
    protected SetPathButton spb;
    
    public FileBrowser getFileBrowser(){return fileBrowser;}
    
    public BrowseState(Gui gui)
    {
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        returnButton = new ReturnButton(gui)
        {
            public void action()
            {
                gui.getGuiStateManager().setState("fileSelectionState");
            }
        };
        fileBrowser = new FileBrowser(gui);
        upDirectoryBtn = new UpDirectoryBtn(gui, fileBrowser);
        fileBrowser.set(10, 150, 280, 550, Background.DARK_GRAY_BACKGROUND);
        spb = new SetPathButton(gui, fileBrowser);
        
    }
    public void open(Gui gui, String previousStateName)
    {
        returnButton.activate();
        fileBrowser.activate();
        fileBrowser.openDir(fileBrowser.getCurrentPath());
        upDirectoryBtn.activate();
        spb.activate();
    }
    public void close(Gui gui, String nextStateName)
    {
        returnButton.deactivate();
        fileBrowser.deactivate();
        upDirectoryBtn.deactivate();
        spb.deactivate();
    }
    
    
    
}