package state;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.util.HashMap;
import guibarelem.*;
import java.awt.Color;

public class StyleFileState implements GuiState
{
    protected Gui gui;
    protected ReturnButton returnButton;
    protected StyleFileFileBrowser fileBrowser;
    
    
    public StyleFileState(Gui gui)
    {
        initStyleFileState(gui);
    }
    public void initStyleFileState(Gui gui)
    {
        this.gui = gui;
        returnButton = new ReturnButton(gui);
        fileBrowser = new StyleFileFileBrowser(gui);
    }
    public void open(Gui gui, String previousStateName)
    {
        returnButton.activate();
        fileBrowser.activate();
        fileBrowser.openDir(textrelated.StyleManager.styleFileFolder);
    }
    public void close(Gui gui, String nextStateName)
    {
        returnButton.deactivate();
        fileBrowser.deactivate();
    }
}