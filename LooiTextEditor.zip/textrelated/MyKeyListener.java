package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;

/*
listen for keystrokes
and
keep track of control and shift
*/
public class MyKeyListener implements  KeyListener
{
    
    //INTERFACE
    public static MyKeyListener it;
    public int getControlShiftMode(){return _getControlShiftMode();}
    
    //END INTERFACE
    
    
    
    protected Gui gui;
    protected TextBoxModifier tbm;
    
    public MyKeyListener(Gui gui, TextBoxModifier tbm)
    {
        init(gui, tbm);
    }
    public void init(Gui gui, TextBoxModifier tbm)
    {
        this.gui = gui;
        this.tbm = tbm;
    }
    public void keyTyped(KeyEvent ke){}
    public void keyPressed(KeyEvent ke)
    {
        updateMode(ke, true);
        ke.consume();
        KeyEventInterface kei = new KeyEventInterface()
        {
            public char getKeyChar(){return ke.getKeyChar();}
            public int getKeyCode(){return ke.getKeyCode();}
        };
        tbm.getKeyActions().execute(kei, getControlShiftMode(), true);
    }
    public void keyReleased(KeyEvent ke)
    {
        //p("k!!!!");
        updateMode(ke, false);
        ke.consume();
        KeyEventInterface kei = new KeyEventInterface()
        {
            public char getKeyChar(){return ke.getKeyChar();}
            public int getKeyCode(){return ke.getKeyCode();}
        };
        tbm.getKeyActions().execute(kei, getControlShiftMode(), false);
    }
    
    
    
    private boolean control, shift;
    private boolean alt;
    
    public void updateMode(KeyEvent ke, boolean tf_PressRelease)
    {
        if(tf_PressRelease == true)//press
        {
            if(ke.getKeyCode() == KeyEvent.VK_CONTROL)
            {
                control = true;
            }
            if(ke.getKeyCode() == KeyEvent.VK_SHIFT)
            {
                shift = true; 
            }
            if(ke.getKeyCode() == KeyEvent.VK_ALT)
            {
                alt = true;
            }
        }
        else//release
        {
            if(ke.getKeyCode() == KeyEvent.VK_CONTROL)
            {
                control = false;
            }
            if(ke.getKeyCode() == KeyEvent.VK_SHIFT)
            {
                shift = false;
            }
            if(ke.getKeyCode() == KeyEvent.VK_ALT)
            {
                alt = false;
            }
        }
        
        
    }
    public int _getControlShiftMode()
    {
        if(alt)
        {
            return KeyActions.ALT;
        }
        else if(control && shift)
        {
            return KeyActions.CONTROL_SHIFT;
        }
        else if(control)
        {
            return KeyActions.CONTROL;
        }
        else if(shift)
        {
            return KeyActions.SHIFT;
        }
        else
        {
            return KeyActions.NORMAL;
        }
    }
    
    public void resetModifiers()
    {
        this.control = false;
        shift = false;
        alt = false;
    }
    
    
    
    
    
    
    
    
    
}
