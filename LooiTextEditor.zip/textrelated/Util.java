package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.lang.Process;
import java.util.HashMap;
import java.lang.Runtime;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.io.File;
import java.awt.Color;
import java.util.HashSet;
import java.lang.StringBuilder;

/*
Random helpful methods
*/
public class Util
{
    public static ArrayList<String> split(String s, String delimeter)
    {
        ArrayList<String> ret = arrayList();
        while(true)
        {
            int index = s.indexOf(delimeter);
            if(index == -1)
            {
                ret.add(s);
                return ret;
            }
            ret.add(s.substring(0, index));
            s = s.substring(index + 1);
        }
    }
    
    //simple casting and parsing methods
    public static int Int(String s){return Integer.parseInt(s);}
    
    public static String show(String s)
    {
        StringBuilder s2 = new StringBuilder();
        for(int i = 0; i < s.length(); i++)
        {
            char c = s.charAt(i);
            if(c < 33 || c > 126)
                s2.append("{" + (int)c + "}");
            else
                s2.append(c);
        }
        return s2.toString();
    }
    public static String replaceRange(String s, int start, int end, String replace)
    {
        String b4 = s.substring(0, start);
        String aft = s.substring(end);
        return b4 + replace + aft;
    }
    
    
    
}