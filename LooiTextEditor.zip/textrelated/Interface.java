package textrelated;

import static ljs.Obj.*;
import ljs.gui.*;
import ljs.gui.looicanvas.*;
import state.*;
import lte4.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.lang.Process;
import java.lang.Runtime;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.BufferedWriter;
import java.lang.StringBuilder;


/*
Allow people to execute stuff using the external customizable program

The rules are that on each exec call, this program and the other program each exchange
only one line of text. Do not use new lines inside that one line as that may be interpreted
as more than one line and that will screw up the program. That is why we already implemeted
the secret codes like DATA_SEP and NEWLINE_REPLACE

The external program will be called on each key and mouse event.

This class only deals with outputting to the customizable program. 
The Parser class deals with its input to us.
*/
public class Interface
{
    //INTERFACE
    public void exec(boolean tf_KeyMouse, boolean tf_PressRelease, int mode, int code, int location, int selectionStart, int selectionEnd, String entireText)
    {
        //get the other program's output
        String res = execGetRes(tf_KeyMouse, tf_PressRelease, mode, code, location, selectionStart, selectionEnd, entireText);
        while(true)
        {
            //send res to parse
            ArrayList<String> returns = gui.getTextBoxModifier().getParser().take(res);
            if(returns == null)//the program didn't ask for anything, and I know this because parser returned null. 
                break;//So if we don't have to do anything, break out of the loop
            //if we get here, then that means that the program did ask for some info, so 
            res = returnOutGetRes(returns.get(0));//we only are able to return out the first thing. I don't want to have the program parse too much text.
            //then loop up back to the top and have the parse take the res again.
        }
        
    }
    public String getKeyBindingJavaProgram(){return keyBindingJavaProgram;}
    public void switchToKeyBindingJavaProgram(String newKeyBindingJavaProgram)
    {
        keyBindingJavaProgram = newKeyBindingJavaProgram;
        _switchToKeyBindingJavaProgram(newKeyBindingJavaProgram);
    }
    //END INTERFACE
    
    
    public static final int 
        NORMAL = 0,
        CONTROL = 1,
        SHIFT = 2,
        CONTROL_SHIFT = 3,
        SHIFT_CONTROL = 4;// for the mode parameter
    public static final char DATA_SEP = (char)(31); //used to separate like the location from like the mode
    public static final char NEWLINE_REPLACE = (char)(29);
    public static final String DEFAULT_KEY_BINDING_JAVA_PROGRAM = "Actions";
        
    protected Gui gui;
    
    public Interface(Gui gui)
    {
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        switchToKeyBindingJavaProgram(DEFAULT_KEY_BINDING_JAVA_PROGRAM);
    }
    
        
    protected String keyBindingJavaProgram; //if keyBindingJavaProgram = "Actions" then the file is called Actions.class
    
    protected Process doingThePipeWithTheOtherProgram = null;
    protected BufferedReader pipeReader = null;
    protected BufferedReader errorReader = null;
    protected BufferedWriter pipeWriter = null;
    protected Thread errorReaderThread = new Thread(()->
            {
                while(true)
                {
                    try
                    {
                        if(errorReader == null)
                        {
                            sleep(.3);
                            continue;
                        }
                        String read = errorReader.readLine();
                        if(read != null)
                            p(read);
                    }catch(Exception e){p("IOException: " + e);}
                }
            });;
    
    public void _switchToKeyBindingJavaProgram(String newKeyBindingJavaProgram)
    {
        if(!errorReaderThread.isAlive()) errorReaderThread.start();
        
        keyBindingJavaProgram = newKeyBindingJavaProgram;
        try
        {
            BufferedReader tempbr = pipeReader;
            BufferedReader temperr = errorReader;
            BufferedWriter tempbw = pipeWriter;
            Process tempProcess = doingThePipeWithTheOtherProgram;
            
            doingThePipeWithTheOtherProgram = Runtime.getRuntime().exec(new String[] {"java", keyBindingJavaProgram});
            pipeReader = new BufferedReader(new InputStreamReader(doingThePipeWithTheOtherProgram.getInputStream()));
            errorReader = new BufferedReader(new InputStreamReader(doingThePipeWithTheOtherProgram.getErrorStream()));
            pipeWriter = new BufferedWriter(new OutputStreamWriter(doingThePipeWithTheOtherProgram.getOutputStream()));
            
            
            if(tempProcess != null)
            {
                tempProcess.destroy();
                tempbr.close();
                temperr.close();
                tempbw.close();
            }
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
        
    }
    //return a value to the external program
    public String returnOutGetRes(String toReturnOut)
    {
        try
        {
            pipeWriter.write(toReturnOut);//writes
            pipeWriter.newLine();
            pipeWriter.flush();
            
            String result = pipeReader.readLine();//reads the response
            return result;
        }
        catch(Exception e)
        {
            p("YOU GOT AN ERROR! This is not a \"you are stupid\" error. This error may have happened because you have a compile time"+
            "or runtime error in you customizable action external java program");
            throw new RuntimeException(e);
        }
    }
    public String execGetRes(boolean tf_KeyMouse, boolean tf_PressRelease, int mode, int code, int location, int selectionStart, int selectionEnd, String entireText)
    {
        String keyMouse = tf_KeyMouse? "key" : "mouse";
        String pressRelease = tf_PressRelease? "press" : "release";
        String modeString;
        if(mode == NORMAL) modeString = "NORMAL";
        else if(mode == CONTROL) modeString = "CONTROL";
        else if(mode == SHIFT) modeString = "SHIFT";
        else if(mode == CONTROL_SHIFT) modeString = "CONTROL_SHIFT";
        else if(mode == SHIFT_CONTROL) modeString = "SHIFT_CONTROL";
        else throw new RuntimeException("You are bad!!!!");
        
        String codeString = Integer.toString(code);
        String locationString = Integer.toString(location);
        String selectionStartStr = Integer.toString(selectionStart);
        String selectionEndStr = Integer.toString(selectionEnd);
        String[] exec = array("java", keyBindingJavaProgram, keyMouse, pressRelease, modeString, codeString, locationString, entireText);
        
        StringBuilder sb = new StringBuilder(entireText.length() + 125);
        sb.append(keyMouse);
        sb.append(DATA_SEP);
        sb.append(pressRelease);
        sb.append(DATA_SEP);
        sb.append(modeString);
        sb.append(DATA_SEP);
        sb.append(codeString);
        sb.append(DATA_SEP);
        sb.append(locationString);
        sb.append(DATA_SEP);
        sb.append(selectionStartStr);
        sb.append(DATA_SEP);
        sb.append(selectionEndStr);
        //sb.append(DATA_SEP);
        //sb.append(entireText.replace("\n", NEWLINE_REPLACE+""));
        
        String output = sb.toString();
        //p("Output from Interface: " + output);
        try
        {
            pipeWriter.write(output);//writes
            pipeWriter.newLine();
            pipeWriter.flush();
            
            String result = pipeReader.readLine();//reads the response
            return result;
        }
        catch(Exception e)
        {
            p("YOU GOT AN ERROR! This is not a \"you are stupid\" error. This error may have happened because you have a compile time"+
            "or runtime error in you customizable action external java program");
            throw new RuntimeException(e);
        }
        
    }
}
