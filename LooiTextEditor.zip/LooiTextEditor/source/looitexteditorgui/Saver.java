package looitexteditorgui;
import static ljs.Obj.*;
import ljs.gui.*;
import java.lang.InterruptedException;
import java.util.ArrayList;
import java.io.File;
public class Saver extends Thread
{
	private long millisecondWait;
	private Gui gui;
	private boolean running = true;
	private String lastSaveText = null;
	private LTETextBox textArea;
	public Saver(Gui gui, long millisecondWait, LTETextBox textArea)
	{
		this.textArea = textArea;
		this.millisecondWait = millisecondWait;
		this.gui = gui;
	}
	public void run()
	{
		while(running)
		{
			synchronized(textArea)
			{
				try
				{
					if(!textArea.getText().equals(lastSaveText))
					{
						save();
						lastSaveText = textArea.getText();
					}
				}catch(Exception ex){ex.printStackTrace();}
			}
			try{Thread.sleep(millisecondWait);}catch(InterruptedException e){}
			
		}
		
	}
	public void save()
	{
		synchronized(textArea)
		{
			if(gui.getViewedTab() != null && gui.getViewedTab() instanceof FileTab)
			{
				ArrayList<String> lines = new ArrayList<>();
				String text = textArea.getText();
				while(true)
				{
					int newLineIndex = text.indexOf("\n");
					if(newLineIndex != -1)
					{
						lines.add(text.substring(0,newLineIndex));
						if(newLineIndex+1 <= text.length())
						{
							text = text.substring(newLineIndex+1,text.length());
						}
						else
						{
							break;
						}
					}
					else
					{
						lines.add(text);
						break;
					}
				}
				String[] linesArray = toStringArray(lines);
				if(((FileTab)gui.getViewedTab()).fileExists())
				{
					saveText(((FileTab)gui.getViewedTab()).getPath(),linesArray);
				}
				else
				{
					((FileTab)gui.getViewedTab()).delete();
				}
			}
		}
	}
}