package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.awt.Color;
import java.io.File;

/*
Create an object that displays all the opened files
*/
public class FileTabHolder extends ScrollBoxList implements StateSaver.Closeable
{
    //INTERFACE
    public void open(String file){open(new File(file));}
    public void open(File file){_addFile(file);}
    public void close(File file){_closeFile(file);}
    public void set(double x, double y, double width, double height, Background back)
    {
        setDimensions(width, height);
        setPosition(x, y);
        setBackground(back);
        getScrollBar().setPosition(getX() + getWidth() - getScrollBar().getWidth(), getScrollBar().getY());
    }
    public FileButton getFileButton(File f){return openFilesAndTheirButtons.get(f);}
    public void moveToTop(FileButton f){_moveToTop(f);}
    //END INTERFACE
    protected HashMap<File, FileButton> openFilesAndTheirButtons = new LinkedHashMap<>();
    protected Gui gui;
    
    public FileTabHolder(Gui gui)
    {
        super(0, 0, 100, 100, Background.WHITE_BACKGROUND);
        init(gui);
    }
    public void init(Gui gui)
    {
        this.gui = gui;
        initScrollBar();
        addToStateSaver();
        otherInit();
        
    }
    public void otherInit()
    {
        setSpacingBetweenItems(5);
    }
    public void addToStateSaver()
    {
        StateSaver.it.addCloseable(this);
    }
    public void initScrollBar()
    {
        getScrollBar().setDimensions(20, getScrollBar().getHeight());
    }
    public void loadPreviousState()
    {
        try
        {
            ArrayList<String> loaded = StateSaver.it.load("FileTabHolder");
            if(loaded == null || loaded.get(0).equals("*null")) 
                return;
            else
            {
                for(String fileName : loaded)
                {
                    /*File file = new File(fileName);
                    if(openFilesAndTheirButtons.keySet().contains(file)) return;
                    FileButton b = makeFileButton(file);
                    if(gui.getGuiStateManager().getCurrentState().equals("fileSelectionState"))
                    {
                        b.activate();
                    }
                    else
                    {
                        b.deactivate();
                    }
                    openFilesAndTheirButtons.put(file, b);
                    add(b);*/
                    open(fileName);
                }
            }
                
        }
        catch(Exception e)
        {
            //JOptionPane.showMessageDialog("Could not load previous hotkey file.");
        }
    }
    public void closeProgram()
    {
        ArrayList<Object> openFiles = arrayList();
        for(ScrollBoxObject scr : getScrollBoxObjects())
        {
            if(scr.thisComponent() instanceof FileButton)
                openFiles.add(((FileButton)scr.thisComponent()).getFile().getAbsolutePath());
        }
        StateSaver.it.save("FileTabHolder", openFiles);
    }
    private void _closeFile(File file)
    {
        FileButton fb = openFilesAndTheirButtons.get(file);
        if(fb == null)
            return;
        
        openFilesAndTheirButtons.remove(file);
        remove(fb);
        fb.delete();
    }
    private void _addFile(File file)
    {
        if(openFilesAndTheirButtons.keySet().contains(file)) return;
        FileButton b = makeFileButton(file);
        if(gui.getGuiStateManager().getCurrentState().equals("fileSelectionState"))
        {
            b.activate();
        }
        else
        {
            b.deactivate();
        }
        openFilesAndTheirButtons.put(file, b);
        add(b);
    }
    public FileButton makeFileButton(File f)
    {
        String name = f.getName();
        FileButton fb = new FileButton(gui, Background.LIGHT_GRAY_BACKGROUND);
        fb.set(0, 0, getWidth() - getLeftMargin() * 2 - getScrollBar().getWidth(), 50);
        fb.setText(name);
        fb.setFile(f);
        return fb;
    }
    
    protected boolean loadedPreviousState = false;
    public void looiStep()
    {
        if(!loadedPreviousState)
        {
            loadPreviousState();
            loadedPreviousState = true;
        }
        super.looiStep();
        updateDimensions();
        checkSelected();
    }
    public void checkSelected()
    {
        if(mouseLeftPressed())
        {
            if(touchingMouse())
            {
                select();
            }
            else
            {
                deselect();
            }
        }
    }
    public void updateDimensions()
    {
        setDimensions(getWidth(), getInternalHeight() - getY() - 30);
    }
    public void _moveToTop(FileButton f)
    {
        ScrollBoxObject correspondingSBO = null;
        for(ScrollBoxObject s : getScrollBoxObjects())
        {
            if(s.thisComponent() == f)
            {
                correspondingSBO = s;
                break;
            }
        }
        if(correspondingSBO == null) return;
        getScrollBoxObjects().remove(correspondingSBO);
        getScrollBoxObjects().add(0, correspondingSBO);
    }
}