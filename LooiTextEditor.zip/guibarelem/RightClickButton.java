package guibarelem;

import static ljs.Obj.*;
import ljs.gui.looicanvas.*;
import ljs.gui.looicanvas.gui_essentials.*;
import lte4.*;
import java.util.ArrayList;
import java.io.File;
import state.*;

/*
Just a button that you can right click.
*/
public abstract class RightClickButton extends BetterButton
{
    //INTERFACE
    public void set(double x, double y, double w, double h)
    {
        setPosition(x, y);
        setDimensions(w, h);
    }
    
    //END INTERFACE
    
    public RightClickButton(Background bg)
    {
        super(bg);
        intRCB();
    }
    public void intRCB()
    {
        
    }
    public abstract void action();
    private boolean lastMouseClickValid,isPressed,justPressed,justReleased;
    public void looiStep()
    {
        super.looiStep();
        
        isPressed = false;
        justPressed = false;
        justReleased = false;
        
        boolean mouseOnButton = touchingMouseAndInFront();//(getInternalMouseX() > getX() && getInternalMouseX() < getX()+getWidth() && getInternalMouseY() > getY() && getInternalMouseY() < getY()+getHeight());
        
        //check last click
        if(mouseRightPressed())
        {
            if(mouseOnButton)
            {
                lastMouseClickValid = true;
            }
            else
            {
                lastMouseClickValid = false;
            }
        }

        if(mouseOnButton)
        {
            if(mouseRightPressed())
            {
                justPressed = true;
            }
            if(mouseRightReleased() && lastMouseClickValid)
            {
                justReleased = true;
            }
            if(mouseRightEngaged() && lastMouseClickValid)
            {
                isPressed = true;
            }
        }
        if(justReleased)
        {
            rightClick();
        }
    }
    public abstract void rightClick();
}